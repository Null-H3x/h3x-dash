#!/usr/bin/env python3
"""
H3x-Dash — Automated Penetration Framework
Flask application core: routes, SSE streaming, API endpoints.
"""

import json
import queue
import threading
import uuid
from flask import Flask, render_template, request, jsonify, Response, stream_with_context, send_file
from pathlib import Path

from config import H3xConfig
from modules.nmap_engine import NmapEngine, PORT_PROFILES, TIMING_DESC, SCRIPT_PROFILES, SCRIPT_DESC
from modules.enum_engine import EnumEngine, TOOL_LABELS
from modules.msf_scanner import MsfScanner
from modules.preflight import PreflightChecker, validate_target
from modules.msf_engine import MsfEngine
from modules.cve_chain import CveChain
from modules.loot import LootManager

# ── App init ──────────────────────────────────────────────────────────────────

app = Flask(__name__)
app.secret_key = H3xConfig.SECRET_KEY
H3xConfig.init_dirs()

# ── Global engine instances ───────────────────────────────────────────────────

scan_engine  = NmapEngine()
enum_engine  = EnumEngine()
msf_engine   = MsfEngine()
cve_chain    = CveChain()
loot_manager = LootManager()

msf_scanner = MsfScanner()
msf_scanner.start()   # builds CVE index from local FS in background

# ── Pre-flight check on startup ───────────────────────────────────────────────
_preflight_results: dict = {}
def _run_preflight():
    global _preflight_results
    checker = PreflightChecker()
    _preflight_results = checker.summary()
    fails = _preflight_results['fail']
    warns = _preflight_results['warn']
    print(f'[H3x-Dash] Pre-flight: {_preflight_results["pass"]} pass, '
          f'{warns} warn, {fails} fail')
    for c in _preflight_results['checks']:
        icon = {'pass':'  ✓','warn':'  ⚠','fail':'  ✗'}.get(c['status'],'  ?')
        print(f'{icon} {c["name"]}: {c["message"]}')

import threading as _t
_t.Thread(target=_run_preflight, daemon=True, name='h3x-preflight').start()

# ── MSF auto-connect on startup ───────────────────────────────────────────────
# Spawns a background thread that retries every 10s until msfrpcd answers.
# Override host/port/pass via environment variables (see config.py).

msf_engine.start_auto_connect(
    host     = H3xConfig.MSF_HOST,
    port     = H3xConfig.MSF_PORT,
    password = H3xConfig.MSF_PASS,
    ssl      = H3xConfig.MSF_SSL,
)

# ── SSE queue registry ────────────────────────────────────────────────────────

_sse_queues: dict[str, queue.Queue] = {}
_sse_lock = threading.Lock()

def _get_queue(client_id: str) -> queue.Queue:
    with _sse_lock:
        if client_id not in _sse_queues:
            _sse_queues[client_id] = queue.Queue(maxsize=500)
        return _sse_queues[client_id]

def _drop_queue(client_id: str):
    with _sse_lock:
        _sse_queues.pop(client_id, None)


# ─────────────────────────────────────────────────────────────────────────────
#  PAGE ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/')
def dashboard():
    stats = {
        'hosts':    scan_engine.get_host_count(),
        'vulns':    scan_engine.get_vuln_count(),
        'sessions': msf_engine.get_session_count(),
        'scans':    scan_engine.get_scan_count(),
    }
    recent   = scan_engine.get_recent_activity()
    msf_conn = msf_engine.is_connected()
    return render_template('dashboard.html', stats=stats, recent=recent, msf_conn=msf_conn)


@app.route('/scan')
def scan():
    return render_template('scan.html',
        port_profiles=PORT_PROFILES,
        timing_desc=TIMING_DESC,
        script_profiles=SCRIPT_PROFILES,
        script_desc=SCRIPT_DESC,
    )


@app.route('/exploit')
def exploit():
    hosts = scan_engine.get_hosts_with_ports()
    msf_conn = msf_engine.is_connected()
    return render_template('exploit.html', hosts=hosts, msf_conn=msf_conn)


@app.route('/enumerate')
def enumerate_page():
    hosts    = scan_engine.get_hosts_with_ports()
    tools    = EnumEngine.available_tools()
    status   = enum_engine.get_status()
    findings = enum_engine.get_findings_flat()
    return render_template('enumerate.html',
        hosts=hosts, tools=tools, status=status,
        findings=findings, tool_labels=TOOL_LABELS)


@app.route('/modules')
def modules_page():
    return render_template('modules.html', stats=msf_scanner.stats())


@app.route('/loot')
def loot():
    reports  = loot_manager.list_reports()
    sessions = msf_engine.list_sessions()
    return render_template('loot.html', reports=reports, sessions=sessions)


# ─────────────────────────────────────────────────────────────────────────────
#  SCAN API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/scan/start', methods=['POST'])
def api_scan_start():
    data      = request.json or {}
    client_id = data.get('client_id') or str(uuid.uuid4())
    q         = _get_queue(client_id)

    def on_output(line: str):
        try:
            q.put_nowait({'type': 'output', 'data': line})
        except queue.Full:
            pass

    def on_complete(hosts, meta):
        try:
            q.put_nowait({'type': 'complete', 'host_count': len(hosts), 'meta': meta})
        except queue.Full:
            pass

    # Validate target before any subprocess runs
    target = data.get('target', '').strip()
    ok, msg = validate_target(target)
    if not ok:
        return jsonify({'status': 'error', 'message': f'Invalid target: {msg}'}), 400

    started = scan_engine.start_scan(data, on_output=on_output, on_complete=on_complete)
    if not started:
        return jsonify({'status': 'error', 'message': 'Scan already running'}), 409

    return jsonify({'status': 'started', 'client_id': client_id})


@app.route('/api/scan/stop', methods=['POST'])
def api_scan_stop():
    scan_engine.stop_scan()
    return jsonify({'status': 'stopped'})


@app.route('/api/scan/status')
def api_scan_status():
    return jsonify(scan_engine.get_status())


@app.route('/api/scan/results')
def api_scan_results():
    return jsonify(scan_engine.get_results())


@app.route('/api/scan/history')
def api_scan_history():
    return jsonify({
        'history': scan_engine.get_recent_activity(),
        'stats': {
            'hosts':    scan_engine.get_host_count(),
            'vulns':    scan_engine.get_vuln_count(),
            'sessions': msf_engine.get_session_count(),
            'scans':    scan_engine.get_scan_count(),
        }
    })


@app.route('/api/scan/stream')
def api_scan_stream():
    client_id = request.args.get('client_id', 'default')
    q         = _get_queue(client_id)

    def generate():
        try:
            while True:
                try:
                    event = q.get(timeout=25)
                    yield f"data: {json.dumps(event)}\n\n"
                    if event.get('type') in ('complete', 'error'):
                        break
                except queue.Empty:
                    yield f"data: {json.dumps({'type': 'heartbeat'})}\n\n"
        finally:
            _drop_queue(client_id)

    return Response(
        stream_with_context(generate()),
        mimetype='text/event-stream',
        headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'},
    )


# ─────────────────────────────────────────────────────────────────────────────
#  CVE CHAIN API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/cve/suggest', methods=['POST'])
def api_cve_suggest():
    data  = request.json or {}
    ip    = data.get('ip')
    hosts = scan_engine.get_hosts_with_ports()
    host  = next((h for h in hosts if h.get('ip') == ip), None)
    if not host:
        return jsonify({'suggestions': []})
    suggestions = cve_chain.suggest(host, host.get('ports', []))
    return jsonify({'suggestions': suggestions})


@app.route('/api/cve/all')
def api_cve_all():
    hosts = scan_engine.get_hosts_with_ports()
    results = {}
    for host in hosts:
        ip = host.get('ip')
        results[ip] = cve_chain.suggest(host, host.get('ports', []))
    return jsonify(results)


# ─────────────────────────────────────────────────────────────────────────────
#  METASPLOIT API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/msf/connect', methods=['POST'])
def api_msf_connect():
    data   = request.json or {}
    result = msf_engine.connect(
        host     = data.get('host',     H3xConfig.MSF_HOST),
        port     = int(data.get('port', H3xConfig.MSF_PORT)),
        password = data.get('password', H3xConfig.MSF_PASS),
        ssl      = data.get('ssl',      H3xConfig.MSF_SSL),
    )
    return jsonify(result)


@app.route('/api/msf/disconnect', methods=['POST'])
def api_msf_disconnect():
    msf_engine.disconnect()
    return jsonify({'status': 'disconnected'})


@app.route('/api/msf/status')
def api_msf_status():
    return jsonify({
        'connected':  msf_engine.is_connected(),
        'version':    msf_engine.get_version(),
        'sessions':   msf_engine.get_session_count(),
        'last_error': msf_engine.get_last_error(),
    })


@app.route('/api/msf/search', methods=['POST'])
def api_msf_search():
    data    = request.json or {}
    modules = msf_engine.search(data.get('query', ''))
    return jsonify({'modules': modules})


@app.route('/api/msf/run', methods=['POST'])
def api_msf_run():
    data   = request.json or {}
    result = msf_engine.run_exploit(
        module  = data.get('module'),
        options = data.get('options', {}),
        payload = data.get('payload'),
    )
    return jsonify(result)


@app.route('/api/msf/sessions')
def api_msf_sessions():
    return jsonify({'sessions': msf_engine.list_sessions()})


@app.route('/api/msf/session/cmd', methods=['POST'])
def api_msf_session_cmd():
    data   = request.json or {}
    result = msf_engine.session_command(
        session_id = str(data.get('session_id')),
        command    = data.get('command', ''),
    )
    return jsonify(result)


# ─────────────────────────────────────────────────────────────────────────────
#  LOOT API
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
#  ENUMERATE API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/enum/start', methods=['POST'])
def api_enum_start():
    data      = request.json or {}
    client_id = data.get('client_id') or str(uuid.uuid4())
    q         = _get_queue(client_id)
    hosts     = [h for h in scan_engine.get_hosts_with_ports()
                 if h.get('ip') in data.get('ips', [h.get('ip')])]
    if not hosts:
        hosts = scan_engine.get_hosts_with_ports()

    def on_output(line):
        try: q.put_nowait({'type': 'output', 'data': line})
        except: pass

    def on_finding(f):
        try: q.put_nowait({'type': 'finding', 'finding': f})
        except: pass

    def on_complete(findings):
        count = sum(len(v) for v in findings.values())
        try: q.put_nowait({'type': 'complete', 'finding_count': count})
        except: pass

    started = enum_engine.start_enum(hosts, data,
                on_output=on_output, on_finding=on_finding, on_complete=on_complete)
    if not started:
        return jsonify({'status': 'error', 'message': 'Enumeration already running'}), 409
    return jsonify({'status': 'started', 'client_id': client_id, 'host_count': len(hosts)})


@app.route('/api/enum/stream')
def api_enum_stream():
    client_id = request.args.get('client_id', 'default')
    q         = _get_queue(client_id)

    def generate():
        try:
            while True:
                try:
                    event = q.get(timeout=25)
                    yield f"data: {json.dumps(event)}\n\n"
                    if event.get('type') in ('complete', 'error'):
                        break
                except queue.Empty: yield f"data: {json.dumps({'type':'heartbeat'})}\n\n"
        finally:
            _drop_queue(client_id)

    return Response(stream_with_context(generate()),
        mimetype='text/event-stream',
        headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})


@app.route('/api/enum/status')
def api_enum_status():
    return jsonify(enum_engine.get_status())


@app.route('/api/enum/findings')
def api_enum_findings():
    ip = request.args.get('ip')
    if ip:
        return jsonify({'findings': enum_engine.get_findings_for_host(ip)})
    return jsonify({'findings': enum_engine.get_findings_flat()})


@app.route('/api/enum/tools')
def api_enum_tools():
    return jsonify({'tools': EnumEngine.available_tools()})


@app.route('/api/loot/generate', methods=['POST'])
def api_loot_generate():
    data   = request.json or {}
    report = loot_manager.generate_report(
        scan_results = scan_engine.get_results(),
        sessions     = msf_engine.list_sessions(),
        fmt          = data.get('format', 'html'),
    )
    return jsonify(report)


@app.route('/api/loot/reports')
def api_loot_list():
    return jsonify({'reports': loot_manager.list_reports()})


@app.route('/api/loot/download/<filename>')
def api_loot_download(filename):
    report_dir = H3xConfig.REPORT_DIR.resolve()
    # Reject any path components that could escape the reports directory
    if '/' in filename or '\\' in filename or '..' in filename:
        return jsonify({'error': 'Invalid filename'}), 400
    safe_path = (report_dir / filename).resolve()
    try:
        safe_path.relative_to(report_dir)   # raises ValueError if outside
    except ValueError:
        return jsonify({'error': 'Path traversal rejected'}), 400
    if not safe_path.exists():
        return jsonify({'error': 'File not found'}), 404
    try:
        return send_file(safe_path, as_attachment=True)
    except PermissionError:
        return jsonify({'error': 'Permission denied reading report file'}), 403


# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
#  PRE-FLIGHT API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/preflight')
def api_preflight():
    """Return cached startup pre-flight results, or run fresh if not ready."""
    if _preflight_results:
        return jsonify(_preflight_results)
    checker = PreflightChecker()
    return jsonify(checker.summary())


@app.route('/api/preflight/refresh', methods=['POST'])
def api_preflight_refresh():
    """Force a fresh pre-flight check."""
    checker = PreflightChecker()
    result  = checker.summary()
    global _preflight_results
    _preflight_results = result
    return jsonify(result)


# ─────────────────────────────────────────────────────────────────────────────
#  MSF MODULE SCANNER API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/modules/search')
def api_modules_search():
    q     = request.args.get('q', '').strip()
    mtype = request.args.get('type', '').strip()
    limit = request.args.get('limit', 100, type=int) or 100
    if not q:
        return jsonify({'modules': [], 'count': 0, 'stats': msf_scanner.stats()})
    results = msf_scanner.search(q, mtype=mtype, limit=limit)
    return jsonify({'modules': results, 'count': len(results),
                    'stats': msf_scanner.stats()})


@app.route('/api/modules/cve/<cve>')
def api_modules_by_cve(cve):
    modules = msf_scanner.by_cve(cve)
    return jsonify({'cve': cve, 'modules': modules, 'count': len(modules)})


@app.route('/api/modules/match', methods=['POST'])
def api_modules_match():
    """Match a list of enum findings to locally installed MSF modules."""
    findings = (request.json or {}).get('findings', [])
    matched  = msf_scanner.match_findings(findings)
    return jsonify({'matches': matched, 'cve_count': len(matched)})


@app.route('/api/modules/stats')
def api_modules_stats():
    return jsonify(msf_scanner.stats())


@app.route('/api/modules/rescan', methods=['POST'])
def api_modules_rescan():
    msf_scanner.trigger_rescan()
    return jsonify({'status': 'rescan started'})


if __name__ == '__main__':
    print("""
  ██╗  ██╗██████╗ ██╗  ██╗      ██████╗  █████╗ ███████╗██╗  ██╗
  ██║  ██║╚════██╗╚██╗██╔╝      ██╔══██╗██╔══██╗██╔════╝██║  ██║
  ███████║ █████╔╝ ╚███╔╝ █████╗██║  ██║███████║███████╗███████║
  ██╔══██║ ╚═══██╗ ██╔██╗ ╚════╝██║  ██║██╔══██║╚════██║██╔══██║
  ██║  ██║██████╔╝██╔╝ ██╗      ██████╔╝██║  ██║███████║██║  ██║
  ╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
  // AUTOMATED PENETRATION FRAMEWORK // AUTHORIZED USE ONLY //
    """)
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
