"""
H3x-Dash CveChain
Maps Nmap service/port data to known CVEs and Metasploit modules.
Local lookup — no external API required for base operation.
"""

# ── CVE / MSF mapping table ───────────────────────────────────────────────────
# Format: service_key -> list of (CVE | None, MSF module | None, description, severity)

CVE_MAP: dict[str, list[tuple]] = {

    'smb': [
        ('CVE-2017-0144', 'exploit/windows/smb/ms17_010_eternalblue',
         'EternalBlue SMBv1 RCE — WannaCry / NotPetya vector', 'CRITICAL'),
        ('CVE-2017-0145', 'exploit/windows/smb/ms17_010_psexec',
         'EternalRomance / EternalSynergy SMBv1 RCE', 'CRITICAL'),
        ('CVE-2020-0796', 'exploit/windows/smb/cve_2020_0796_smbghost',
         'SMBGhost — SMBv3 Compression RCE (pre-auth)', 'CRITICAL'),
        ('CVE-2021-34527', None,
         'PrintNightmare — Windows Print Spooler RCE / LPE', 'CRITICAL'),
        (None, 'auxiliary/scanner/smb/smb_ms17_010',
         'MS17-010 EternalBlue scanner (non-destructive check)', 'INFO'),
        (None, 'auxiliary/scanner/smb/smb_enumshares',
         'SMB share enumeration', 'INFO'),
        (None, 'auxiliary/scanner/smb/smb_enumusers',
         'SMB user enumeration', 'INFO'),
        (None, 'auxiliary/scanner/smb/smb_login',
         'SMB brute-force login', 'HIGH'),
    ],

    'rdp': [
        ('CVE-2019-0708', 'exploit/windows/rdp/cve_2019_0708_bluekeep_rce',
         'BlueKeep — RDP pre-auth RCE (unauthenticated)', 'CRITICAL'),
        ('CVE-2012-0002', 'exploit/windows/rdp/ms12_020_maxchannelids',
         'MS12-020 RDP MaxChannelIDs DoS', 'HIGH'),
        ('CVE-2019-1182', None,
         'DejaBlue — RDP RCE (Windows 10 / Server 2019)', 'CRITICAL'),
        (None, 'auxiliary/scanner/rdp/rdp_scanner',
         'RDP service detection / NLA check', 'INFO'),
    ],

    'ftp': [
        ('CVE-2011-2523', 'exploit/unix/ftp/vsftpd_234_backdoor',
         'vsftpd 2.3.4 backdoor — instant root shell', 'CRITICAL'),
        ('CVE-2010-4221', 'exploit/linux/ftp/proftp_telnet_iac',
         'ProFTPD 1.3.2rc3 Telnet IAC buffer overflow RCE', 'HIGH'),
        (None, 'auxiliary/scanner/ftp/ftp_login',
         'FTP brute-force login', 'HIGH'),
        (None, 'auxiliary/scanner/ftp/anonymous',
         'FTP anonymous access check', 'MEDIUM'),
    ],

    'ssh': [
        ('CVE-2023-38408', None,
         'OpenSSH ssh-agent remote code execution', 'CRITICAL'),
        ('CVE-2018-15473', None,
         'OpenSSH username enumeration (timing oracle)', 'MEDIUM'),
        ('CVE-2016-6515', None,
         'OpenSSH PAM login DoS via excessive authentication', 'MEDIUM'),
        (None, 'auxiliary/scanner/ssh/ssh_login',
         'SSH brute-force login', 'HIGH'),
        (None, 'auxiliary/scanner/ssh/ssh_enumusers',
         'SSH username enumeration', 'MEDIUM'),
    ],

    'http': [
        ('CVE-2021-41773', 'exploit/multi/http/apache_normalize_path_rce',
         'Apache 2.4.49 path traversal / RCE', 'CRITICAL'),
        ('CVE-2021-42013', 'exploit/multi/http/apache_normalize_path_rce',
         'Apache 2.4.50 path traversal bypass / RCE', 'CRITICAL'),
        ('CVE-2017-5638', 'exploit/multi/http/struts2_content_type_ognl',
         'Apache Struts2 Content-Type OGNL RCE', 'CRITICAL'),
        ('CVE-2019-11043', 'exploit/multi/http/php_fpm_path_info',
         'PHP-FPM PATH_INFO buffer overflow RCE (Nginx configs)', 'CRITICAL'),
        ('CVE-2014-6271', 'exploit/multi/http/apache_mod_cgi_bash_env_exec',
         'Shellshock — Apache mod_cgi bash env RCE', 'CRITICAL'),
        ('CVE-2022-22965', 'exploit/multi/http/spring4shell',
         'Spring4Shell — Spring Framework RCE', 'CRITICAL'),
        (None, 'auxiliary/scanner/http/http_version',
         'HTTP banner / version detection', 'INFO'),
        (None, 'auxiliary/scanner/http/dir_scanner',
         'HTTP directory brute-force', 'INFO'),
    ],

    'telnet': [
        ('CVE-2011-4862', 'exploit/freebsd/telnet/telnet_encrypt_keyid',
         'BSD telnetd encrypt option buffer overflow', 'CRITICAL'),
        (None, 'auxiliary/scanner/telnet/telnet_login',
         'Telnet brute-force login', 'HIGH'),
        (None, None, 'Telnet transmits credentials in cleartext', 'HIGH'),
    ],

    'mssql': [
        (None, 'auxiliary/scanner/mssql/mssql_login',
         'MSSQL brute-force login', 'HIGH'),
        (None, 'exploit/windows/mssql/mssql_payload',
         'MSSQL xp_cmdshell payload execution (requires SA)', 'CRITICAL'),
        (None, 'auxiliary/scanner/mssql/mssql_hashdump',
         'MSSQL password hash dump', 'HIGH'),
        (None, 'auxiliary/admin/mssql/mssql_enum',
         'MSSQL enumeration — databases, users, configs', 'INFO'),
    ],

    'mysql': [
        ('CVE-2012-2122', 'auxiliary/scanner/mysql/mysql_authbypass_hashdump',
         'MySQL auth bypass via timing attack', 'HIGH'),
        (None, 'auxiliary/scanner/mysql/mysql_login',
         'MySQL brute-force login', 'HIGH'),
        (None, 'auxiliary/scanner/mysql/mysql_hashdump',
         'MySQL user password hash dump', 'HIGH'),
        (None, 'auxiliary/scanner/mysql/mysql_writable_dirs',
         'MySQL writable directory check (FILE privilege)', 'MEDIUM'),
    ],

    'vnc': [
        (None, 'auxiliary/scanner/vnc/vnc_none_auth',
         'VNC no-authentication check', 'CRITICAL'),
        (None, 'auxiliary/scanner/vnc/vnc_login',
         'VNC brute-force login', 'HIGH'),
    ],

    'snmp': [
        (None, 'auxiliary/scanner/snmp/snmp_enum',
         'SNMP community string enumeration (v1/v2c)', 'HIGH'),
        (None, 'auxiliary/scanner/snmp/snmp_enumshares',
         'SNMP share enumeration', 'MEDIUM'),
        (None, 'auxiliary/scanner/snmp/snmp_login',
         'SNMP community string brute-force', 'HIGH'),
        ('CVE-2017-6736', None,
         'Cisco IOS SNMP remote code execution', 'CRITICAL'),
    ],

    'redis': [
        (None, 'exploit/linux/redis/redis_replication_cmd_exec',
         'Redis unauthenticated RCE via replication', 'CRITICAL'),
        ('CVE-2022-0543', 'exploit/linux/redis/redis_lua_sandbox_escape',
         'Redis Lua sandbox escape (Debian/Ubuntu packages)', 'CRITICAL'),
        (None, None,
         'Redis unauthenticated access — check for no-auth config', 'CRITICAL'),
    ],

    'elasticsearch': [
        ('CVE-2014-3120', 'exploit/multi/elasticsearch/search_groovy_script',
         'Elasticsearch dynamic script RCE (< 1.3.8)', 'CRITICAL'),
        ('CVE-2015-1427', 'exploit/multi/elasticsearch/script_mvel_rce',
         'Elasticsearch Groovy sandbox bypass RCE (< 1.6.1)', 'CRITICAL'),
        (None, None,
         'Elasticsearch unauthenticated access — check for open cluster', 'HIGH'),
    ],

    'mongodb': [
        (None, 'auxiliary/gather/mongodb_js_inject_collection_enum',
         'MongoDB JS injection / collection enumeration', 'MEDIUM'),
        (None, None,
         'MongoDB unauthenticated access — no-auth default config', 'CRITICAL'),
    ],

    'ldap': [
        (None, 'auxiliary/gather/ldap_query',
         'LDAP anonymous bind / directory enumeration', 'HIGH'),
        (None, 'auxiliary/scanner/ldap/ldap_login',
         'LDAP brute-force login', 'HIGH'),
    ],

    'psql': [
        (None, 'auxiliary/scanner/postgres/postgres_login',
         'PostgreSQL brute-force login', 'HIGH'),
        ('CVE-2019-9193', None,
         'PostgreSQL COPY FROM/TO PROGRAM RCE (superuser required)', 'HIGH'),
        (None, 'auxiliary/scanner/postgres/postgres_hashdump',
         'PostgreSQL password hash dump', 'HIGH'),
    ],

    'oracle': [
        (None, 'auxiliary/scanner/oracle/oracle_login',
         'Oracle DB brute-force login (requires oracle_client)', 'HIGH'),
        (None, 'auxiliary/admin/oracle/oraenum',
         'Oracle DB enumeration', 'INFO'),
    ],

    'rpcbind': [
        (None, 'auxiliary/scanner/misc/sunrpc_portmapper',
         'RPC portmapper service enumeration', 'INFO'),
        (None, None, 'rpcbind exposed — check for NFS mounts', 'MEDIUM'),
    ],

    'nfs': [
        (None, 'auxiliary/scanner/nfs/nfsmount',
         'NFS mount enumeration — check for world-readable exports', 'HIGH'),
    ],

    'smtp': [
        (None, 'auxiliary/scanner/smtp/smtp_enum',
         'SMTP user enumeration via VRFY / EXPN / RCPT', 'MEDIUM'),
        (None, 'auxiliary/scanner/smtp/smtp_relay',
         'SMTP open relay check', 'HIGH'),
    ],

    'backdoor': [
        (None, 'exploit/multi/handler',
         'Port 4444 — likely an active backdoor or reverse shell listener', 'CRITICAL'),
    ],
}

# ── Port → service key mapping ────────────────────────────────────────────────

PORT_TO_SERVICE: dict[int, str] = {
    21:    'ftp',
    22:    'ssh',
    23:    'telnet',
    25:    'smtp',
    53:    'dns',
    80:    'http',
    110:   'smtp',
    111:   'rpcbind',
    135:   'rpcbind',
    139:   'smb',
    161:   'snmp',
    389:   'ldap',
    443:   'http',
    445:   'smb',
    512:   'ssh',
    513:   'ssh',
    514:   'ssh',
    631:   'http',
    1433:  'mssql',
    1521:  'oracle',
    2049:  'nfs',
    3306:  'mysql',
    3389:  'rdp',
    4444:  'backdoor',
    5432:  'psql',
    5900:  'vnc',
    6379:  'redis',
    8080:  'http',
    8443:  'http',
    9200:  'elasticsearch',
    27017: 'mongodb',
}

# Service name aliases (from Nmap banners → internal key)
SERVICE_ALIAS: dict[str, str] = {
    'microsoft-ds':   'smb',
    'netbios-ssn':    'smb',
    'ms-wbt-server':  'rdp',
    'domain':         'dns',
    'ftp-data':       'ftp',
    'pop3':           'smtp',
    'imap':           'smtp',
    'postgresql':     'psql',
    'http-proxy':     'http',
    'ssl/http':       'http',
    'https':          'http',
    'http-alt':       'http',
}

SEVERITY_ORDER = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3, 'INFO': 4}


# ── CveChain ──────────────────────────────────────────────────────────────────

class CveChain:

    def suggest(self, host: dict, ports: list) -> list:
        """Return sorted list of CVE/MSF suggestions for a host's open ports."""
        seen        = set()
        suggestions = []

        for port_info in ports:
            port_num = port_info.get('port')
            service  = (port_info.get('service') or '').lower().strip()
            version  = port_info.get('version', '')

            # Build lookup keys: try Nmap service name first, then port number
            keys = []
            normalized = SERVICE_ALIAS.get(service, service)
            if normalized and normalized in CVE_MAP:
                keys.append(normalized)
            port_svc = PORT_TO_SERVICE.get(port_num)
            if port_svc and port_svc not in keys and port_svc in CVE_MAP:
                keys.append(port_svc)

            for key in keys:
                for cve, msf_module, desc, severity in CVE_MAP.get(key, []):
                    uid = f"{cve or ''}{msf_module or ''}{port_num}"
                    if uid in seen:
                        continue
                    seen.add(uid)
                    suggestions.append({
                        'port':        port_num,
                        'service':     service or key,
                        'version':     version,
                        'cve':         cve,
                        'msf_module':  msf_module,
                        'description': desc,
                        'severity':    severity,
                        'host_ip':     host.get('ip', '') if host else '',
                    })

        suggestions.sort(key=lambda x: SEVERITY_ORDER.get(x['severity'], 99))
        return suggestions
