"""
H3x-Dash MsfEngine
Thread-safe wrapper around pymetasploit3's MsfRpcClient.
Includes socket pre-check, SSL auto-detection, and background
reconnect loop so H3x-Dash keeps trying until msfrpcd is up.

Start msfrpcd (no SSL) before launching H3x-Dash:
    msfrpcd -P msfrpc -S -f
"""
import socket
import threading
import time


# How long to wait for a TCP connection to msfrpcd (seconds)
_CONNECT_TIMEOUT = 5

# Seconds between auto-reconnect attempts
_RETRY_INTERVAL  = 10


def _port_open(host: str, port: int, timeout: float = _CONNECT_TIMEOUT) -> bool:
    """Quick TCP reachability check — avoids hanging the whole app."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


class MsfEngine:

    def __init__(self):
        self._client    = None
        self._connected = False
        self._version   = None
        self._lock      = threading.Lock()
        self._retry_thr = None        # background reconnect thread
        self._stop_retry = threading.Event()
        self._last_error = None       # last connection error string

    # ── Connection ────────────────────────────────────────────────────────────

    def connect(self, host='127.0.0.1', port=55553, password='msfrpc', ssl=False) -> dict:
        try:
            from pymetasploit3.msfrpc import MsfRpcClient
        except ImportError:
            return {
                'status':  'error',
                'message': 'pymetasploit3 not installed — run: pip install pymetasploit3',
            }

        # ── 1. TCP reachability check ─────────────────────────────────────────
        if not _port_open(host, port):
            msg = (
                f'Cannot reach {host}:{port} — '
                'is msfrpcd running?  Start it with: '
                'msfrpcd -P msfrpc -S -f'
            )
            with self._lock:
                self._connected = False
                self._last_error = msg
            return {'status': 'error', 'message': msg}

        # ── 2. Try to authenticate ────────────────────────────────────────────
        #    pymetasploit3 uses requests under the hood; when msfrpcd was started
        #    with -S (no SSL) we must pass ssl=False explicitly AND the library
        #    must not override it.  We try no-SSL first, then SSL as a fallback.
        attempts = [(False, 'no-SSL'), (True, 'SSL')]
        if ssl:
            attempts = [(True, 'SSL'), (False, 'no-SSL')]

        last_exc = None
        for use_ssl, label in attempts:
            try:
                client  = MsfRpcClient(
                    password,
                    server = host,
                    port   = port,
                    ssl    = use_ssl,
                )
                version = client.core.version      # ping — raises if auth fails
                with self._lock:
                    self._client    = client
                    self._version   = version
                    self._connected = True
                    self._last_error = None
                print(f'[H3x-Dash] MSF RPC connected ({label}) — {version}')
                return {'status': 'connected', 'version': version}
            except Exception as exc:
                last_exc = exc
                continue

        msg = f'Auth failed ({host}:{port}): {last_exc}'
        with self._lock:
            self._connected  = False
            self._client     = None
            self._last_error = msg
        return {'status': 'error', 'message': msg}

    def disconnect(self):
        self._stop_retry.set()          # kill retry thread if running
        with self._lock:
            self._client    = None
            self._connected = False
            self._version   = None

    def is_connected(self) -> bool:
        return self._connected and self._client is not None

    def get_version(self) -> str | None:
        return self._version

    def get_last_error(self) -> str | None:
        return self._last_error

    def get_session_count(self) -> int:
        return len(self.list_sessions())

    # ── Auto-reconnect ────────────────────────────────────────────────────────

    def start_auto_connect(self, host='127.0.0.1', port=55553,
                           password='msfrpc', ssl=False):
        """
        Spawn a background thread that keeps trying to connect until it
        succeeds.  Safe to call multiple times — only one thread runs.
        """
        if self._retry_thr and self._retry_thr.is_alive():
            return  # already running

        self._stop_retry.clear()
        self._retry_thr = threading.Thread(
            target   = self._reconnect_loop,
            args     = (host, port, password, ssl),
            daemon   = True,
            name     = 'h3x-msf-autoconnect',
        )
        self._retry_thr.start()

    def _reconnect_loop(self, host, port, password, ssl):
        attempt = 0
        while not self._stop_retry.is_set():
            if self.is_connected():
                # Already up — just health-check every _RETRY_INTERVAL seconds
                try:
                    _ = self._client.core.version
                except Exception:
                    with self._lock:
                        self._connected = False
                        self._client    = None
                    print('[H3x-Dash] MSF RPC connection lost — retrying...')
                self._stop_retry.wait(_RETRY_INTERVAL)
                continue

            attempt += 1
            print(f'[H3x-Dash] MSF RPC connect attempt {attempt} '
                  f'({host}:{port}) ...')
            result = self.connect(host=host, port=port,
                                  password=password, ssl=ssl)
            if result['status'] == 'connected':
                print(f'[H3x-Dash] MSF RPC online — {result.get("version","")}')
                # Stay in loop to health-check, but slow down
                self._stop_retry.wait(_RETRY_INTERVAL)
            else:
                print(f'[H3x-Dash] MSF RPC unavailable — '
                      f'{result.get("message","")}  '
                      f'(retry in {_RETRY_INTERVAL}s)')
                self._stop_retry.wait(_RETRY_INTERVAL)

    # ── Module search ─────────────────────────────────────────────────────────

    def search(self, query: str) -> list:
        if not self.is_connected():
            return []
        try:
            raw = self._client.modules.search(query)
            return [
                {
                    'fullname':    m.get('fullname', ''),
                    'type':        m.get('type', ''),
                    'rank':        m.get('rank', ''),
                    'description': m.get('description', ''),
                }
                for m in (raw or [])[:50]
            ]
        except Exception as e:
            return [{'error': str(e)}]

    # ── Exploit execution ─────────────────────────────────────────────────────

    def run_exploit(self, module: str, options: dict, payload: str = None) -> dict:
        if not self.is_connected():
            return {'status': 'error', 'message': 'Not connected to Metasploit RPC'}
        if not module:
            return {'status': 'error', 'message': 'No module specified'}

        log = []
        def L(line=''): log.append(line)

        try:
            # ── Pre-flight info ───────────────────────────────────────────────
            L(f'MODULE   : {module}')
            L(f'TARGET   : {options.get("RHOSTS","?")} : {options.get("RPORT","?")}')
            L(f'PAYLOAD  : {payload or "(module default)"}')
            extra = {k: v for k, v in (options or {}).items()
                     if k not in ('RHOSTS', 'RPORT', 'LHOST', 'LPORT')}
            if extra:
                L(f'OPTIONS  : {extra}')
            lhost = options.get('LHOST', '')
            lport = options.get('LPORT', '')
            if lhost:
                L(f'HANDLER  : {lhost} : {lport}')
            L()

            # ── Load module and set options ───────────────────────────────────
            L('[*] Loading module...')
            exploit = self._client.modules.use('exploit', module)

            # Log module metadata
            try:
                L(f'[*] Rank      : {exploit.rank}')
                L(f'[*] Targets   : {len(exploit.targets)}')
            except Exception:
                pass

            L('[*] Setting options...')
            for k, v in (options or {}).items():
                exploit[k] = v
                L(f'    {k} => {v}')

            # ── Session baseline before launch ────────────────────────────────
            sessions_before = {s['id'] for s in self.list_sessions()}
            L()
            L(f'[*] Sessions before launch : {len(sessions_before)}')
            L('[*] Executing...')

            # ── Execute ───────────────────────────────────────────────────────
            if payload:
                p      = self._client.modules.use('payload', payload)
                result = exploit.execute(payload=p)
            else:
                result = exploit.execute()

            job_id = result.get('job_id', '?')
            uuid   = result.get('uuid', '?')
            L()
            L(f'[+] Exploit dispatched')
            L(f'    Job ID  : {job_id}')
            L(f'    UUID    : {uuid}')

            # ── Poll for new sessions (up to 10s) ─────────────────────────────
            L()
            L('[*] Polling for new sessions (10s)...')
            new_sessions = []
            for tick in range(5):
                time.sleep(2)
                current = self.list_sessions()
                new_sessions = [s for s in current if s['id'] not in sessions_before]
                if new_sessions:
                    break

            if new_sessions:
                L(f'[+] {len(new_sessions)} NEW SESSION(S) OPENED:')
                for s in new_sessions:
                    L(f'    [{s["id"]}] {s["type"].upper()} | {s["target"]} | {s["user"]} | {s["platform"]} {s["arch"]}')
            else:
                all_sessions = self.list_sessions()
                if all_sessions:
                    L(f'[-] No new sessions — {len(all_sessions)} existing session(s) still active')
                else:
                    L('[-] No sessions opened — exploit may still be running or target is not vulnerable')
                    L(f'    Check MSF job status: jobs -j {job_id}')

            return {
                'status':   'launched',
                'result':   '\n'.join(log),
                'job_id':   job_id,
                'sessions': new_sessions,
            }

        except Exception as e:
            L()
            L(f'[ERROR] {e}')
            return {'status': 'error', 'message': str(e), 'result': '\n'.join(log)}

    # ── Session management ────────────────────────────────────────────────────

    def list_sessions(self) -> list:
        if not self.is_connected():
            return []
        try:
            raw = self._client.sessions.list or {}
            return [
                {
                    'id':       str(sid),
                    'type':     info.get('type', ''),
                    'target':   info.get('target_host', ''),
                    'user':     info.get('username', ''),
                    'platform': info.get('platform', ''),
                    'arch':     info.get('arch', ''),
                    'info':     info.get('info', ''),
                    'tunnel':   info.get('tunnel_local', ''),
                }
                for sid, info in raw.items()
            ]
        except Exception:
            return []

    def session_command(self, session_id: str, command: str) -> dict:
        if not self.is_connected():
            return {'status': 'error', 'message': 'Not connected'}
        try:
            session = self._client.sessions.session(session_id)
            session.write(command + '\n')
            time.sleep(1.5)
            output = session.read()
            return {'status': 'ok', 'output': output or ''}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
