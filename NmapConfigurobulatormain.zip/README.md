# Nmap Configurobulator v1.01

> *Because "nmap -sS 192.168.1.0/24" is technically correct, but this is more fun.*

A professional-grade network reconnaissance scanner and topology visualizer built on nmap. Runs a fully configurable scan through an interactive terminal UI, streams live results, and produces a self-contained D3.js HTML report that looks like something a cyberpunk sysadmin would hang on their wall.

---

## What it does

1. You launch it. A large, neon-coloured banner appears.
2. It walks you through nine configuration steps without judgment.
3. It runs nmap, streaming every discovered port and host in real time.
4. It produces a timestamped `.html` file with an interactive network topology graph, risk-flagged ports, device classification, and three scrollable panels of host intelligence.
5. You open the HTML in a browser. You feel like a professional.
6. Your friends think you're a hacker (You're not). Your boss thinks you're a wizard (You are).

---

## Requirements

| Thing | Version | Notes |
|-------|---------|-------|
| Python | ≥ 3.9 | stdlib only — zero pip install required |
| nmap | ≥ 7.x | the actual scanning is nmap's problem |
| OS | Linux / macOS | PTY-based; WSL2 works |
| Privileges | root or sudo | required for SYN scan and OS detection |

---

## Installation

```bash
git clone https://github.com/Null-H3x/nmap-configurobulator.git
cd nmap-configurobulator
```

That's it. No virtualenv. No requirements.txt. No `pip install something-that-breaks-in-six-months`.

---

## Usage

### Interactive mode *(recommended)*
```bash
sudo python3 nmap-configurobulator.py
```
Launches the nine-step configurator. Neon colours included.

### CLI mode *(for when you know what you want)*
```bash
# Standard subnet scan
sudo python3 nmap-configurobulator.py 192.168.1.0/24

# Balanced scan — top 100 ports, banner grabbing
sudo python3 nmap-configurobulator.py 192.168.1.0/24 --ports top100 --scripts banner

# Single host, full port range, default scripts
sudo python3 nmap-configurobulator.py 192.168.1.95 --ports full --scripts default

# Hostname target
sudo python3 nmap-configurobulator.py scanme.nmap.org --ports top100

# No root — TCP connect scan, no OS detection
python3 nmap-configurobulator.py 192.168.1.0/24 --no-sudo

# Save reports to a specific directory
sudo python3 nmap-configurobulator.py 192.168.1.0/24 --out-dir ~/reports
```

---

## Configuration options

### Timing templates

Timing templates are named after their personality, not an arbitrary integer.

| Flag | Name | Description |
|------|------|-------------|
| T1 | Sneaky Ninja | Extremely slow. IDS evasion. You have time. |
| T2 | Polite Brit | Slow. Courteous. Apologetic about the intrusion. |
| T3 | Boringly Average | Default nmap timing. Reliable. Unremarkable. |
| T4 | Antagonistic | Fast. Reliable on LAN. Recommended. |
| T5 | Roid Rage | Maximum speed. May drop packets. No regrets. |

### Port scope

| Profile | Coverage | Notes |
|---------|----------|-------|
| `top20` | ~30 high-value ports | Fast. Good first pass. |
| `top100` | Ports 1–1024 + common high ports | Balanced. |
| `full` | 1–65535 | Thorough. Slow. Use on specific hosts only. |

> **Note:** `--host-timeout` is automatically disabled for full scans. A 5-minute timeout during a 65535-port scan causes nmap to abandon hosts before writing port data to the XML. This is a known nmap behaviour, not a bug in your decision-making.

### NSE Script profiles

| Profile | What it runs | Speed |
|---------|-------------|-------|
| `none` | Nothing | Instant |
| `banner` | Port banner grabbing | Fast |
| `default` | nmap default scripts + banner | Medium |
| `safe` | Safe category scripts | Slow — runs 30s pre-scan broadcast NSE |
| `vuln` | Vulnerability scripts + default + banner | Slow |
| `full` | vuln + auth + discovery + default + banner | Very slow |

> `safe` sounds harmless but it runs broadcast pre-scan scripts that write large `<prescript>` blocks to the XML *before* any host data. On networks with firewalls this can look like no hosts were found. Use `banner` instead for most subnet scans.

---

## HTML report

Each scan produces a `topology_<target>_<timestamp>.html` file. It is fully self-contained — open it in any browser, no server required.

```
topology_192.168.1.0_24_20260403_162037.html
```

### What's in the report

**Graph canvas** — D3.js force-directed topology. Nodes are draggable. Zoom and pan with scroll. Click any node to inspect it.

**Sidebar** — Click a node to see: IP, MAC address, vendor, OS (with confidence %), uptime, open ports with risk colouring, and NSE script output.

**Three bottom panels:**

| Panel | Colour | Content |
|-------|--------|---------|
| No response | Grey | Every IP in the target range that didn't answer |
| Up — no open ports | Amber | Hosts confirmed alive but nothing found in scanned range |
| Up — open ports | Green | Hosts with at least one open port |

### Device classification

| Type | Colour | Detected by |
|------|--------|------------|
| Gateway | 🟠 Orange | OS keywords, .1/.254, SNMP/Telnet ports |
| Switch | 🟣 Purple | Catalyst/Nexus/Procurve OS strings |
| Server | 🟢 Green | Linux/Unix OS or HTTP+SSH without RDP |
| Workstation | 🔵 Blue | Windows OS or RDP/NetBIOS ports |
| IoT | 🟡 Amber | Embedded OS or MQTT/RTSP ports |
| Unknown | ⚫ Grey | Everything else |
| Scanner | 🩷 Pink | You. The machine that ran the scan. |

### Port risk colours

| Colour | Risk | Example ports |
|--------|------|--------------|
| 🔴 Red | Danger | Telnet (23), FTP (21), SMB (445), RDP (3389), MSSQL (1433), Redis (6379) |
| 🟡 Amber | Warning | SMTP (25), POP3 (110), MSRPC (135), SNMP (161), NFS (2049) |
| 🟢 Green | Info | SSH (22), HTTP (80), HTTPS (443), DNS (53) |

---

## Technical notes

### Why PTY instead of subprocess PIPE

nmap detects whether its stdout is a TTY. When it's a pipe, glibc switches to 4–8 KB block buffering — events stop arriving until the buffer fills, which looks exactly like a hang. A PTY slave looks like a real terminal, so glibc line-buffers and every newline flushes immediately.

### The SIGHUP problem

Closing the PTY master file descriptor while nmap is still running sends `SIGHUP` to nmap, killing it before it can finish writing the XML file. This tool keeps the PTY master open and draining in a single unified loop for the entire lifetime of the nmap process. The master is closed only after `proc.wait()` confirms nmap has exited.

### Proxy ARP ghost filtering

Some routers respond to ARP for every IP on the subnet (proxy ARP), causing nmap to report all 254 addresses as live. The filter identifies ghosts by their round-trip time: responses arriving in under 200 microseconds with no open ports and no MAC address are the router answering for non-existent devices. Real LAN hosts take at least 300μs.

### hosthint recovery

nmap writes `<hosthint>` elements early in the scan (when a host is confirmed alive) but only writes the full `<host>` element after all scanning including NSE completes. If a scan is interrupted during a long NSE phase, the tool recovers host IPs and port data from the live PTY stream that was captured in the monitor — the topology will be populated even though the XML is technically incomplete.

### Responsive scaling

The HTML report uses a JavaScript `computeFontPx()` function that calculates root font size from viewport width before first render. All layout dimensions are in `rem`, so the report scales proportionally from a 1280px laptop to a 3840px 4K display without media query breakpoints.

---

## Error handling

All error output is prefixed with:

```
Internal Error Code: XD-MBYG04K-URS3LF
```

This is intentional. It communicates the appropriate level of functionality.

---

## Known behaviours

- **`--script=full` on a /24 takes a long time.** This is expected. Go make coffee. Consider your life choices. Come back.
- **254 grey bubbles in the graph.** Your router uses proxy ARP. The ghost filter should catch these automatically.
- **0 hosts found despite the monitor showing ports.** The XML was truncated during NSE. The hosthint recovery will surface the host with port data injected from the live stream. Re-run with a lighter script profile for complete XML output.
- **"Parallel DNS resolution of 256 hosts" takes 2 minutes.** That's nmap, not this tool. Add `--dns-servers 8.8.8.8` in Extra Args if it bothers you.

---

## What it does not do

- Scan networks you don't own or don't have written permission to test
- Make the coffee
- Fix whatever it finds
- Take back late-night texts

---

## Legal

This tool is designed for use on networks you own or have explicit written authorisation to test. Unauthorised network scanning may violate computer fraud and abuse laws in your jurisdiction. The authors accept no responsibility for what you do with it.

The error code (`XD-MBYG04K-URS3LF`) is not a real internal tracking system. Probably?

---

## License

Free use

---

*Built with nmap, Python, D3.js, caffeine, and an unreasonable number of Unicode box-drawing characters.*
