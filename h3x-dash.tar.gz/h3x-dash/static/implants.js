/* ─────────────────────────────────────────────────────────────────────────
   implants.js — Hak5 / Spectrum module front-end.
   Talks to /api/implants/* and /api/wireless/*. Degrades gracefully: if the
   backend or a device is unreachable the UI shows the failure instead of
   breaking. All state lives server-side (file-backed registry).
   ───────────────────────────────────────────────────────────────────────── */
(function () {
'use strict';

let PRODUCTS = [];           // catalog (from tree nodes)
let TREE = [];               // product nodes with .instances
const expanded = {};         // product_id -> bool

/* ── utils ──────────────────────────────────────────────────────────────── */
function ts() { return new Date().toISOString().slice(11, 19); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function logTo(id, cls, msg) {
  const el = document.getElementById(id); if (!el) return;
  el.innerHTML += `\n<span class="${cls}">[${ts()}] ${esc(msg)}</span>`;
  el.scrollTop = el.scrollHeight;
}
const ilog = (m, c = 't-ok') => logTo('inv-terminal', c, m);
const wlog = (m, c = 't-info') => logTo('w-terminal', c, m);
const llog = (m, c = 't-info') => logTo('loot-terminal', c, m);

async function api(url, opts) {
  const r = await fetch(url, Object.assign({ headers: { 'Content-Type': 'application/json' } }, opts));
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}
function tierBadge(t) {
  return t === 'full' ? '<span class="badge badge-green">FULL REMOTE</span>'
    : t === 'managed' ? '<span class="badge badge-warning">SSH MANAGED</span>'
    : '<span class="badge badge-muted">AUTHOR ONLY</span>';
}

/* ── tabs ───────────────────────────────────────────────────────────────── */
window.hxSwitch = function (tab) {
  ['inventory', 'payloads', 'loot', 'wireless'].forEach(t =>
    document.getElementById('view-' + t).classList.toggle('hidden', t !== tab));
  document.querySelectorAll('.subtab').forEach(b =>
    b.classList.toggle('active', b.dataset.tab === tab));
  if (tab === 'wireless') hxRecon(true);
};

/* ── inventory tree ─────────────────────────────────────────────────────── */
async function loadTree() {
  try {
    const d = await api('/api/implants/tree');
    TREE = d.tree || [];
    PRODUCTS = TREE.map(p => ({ id: p.id, name: p.name }));
    renderTree();
    renderStats(d.stats || {});
    fillProductFilter();
  } catch (e) {
    document.getElementById('tree').innerHTML =
      '<div class="text-red" style="padding:1.5rem">inventory load failed: ' + esc(e.message) + '</div>';
  }
}
function renderStats(s) {
  const set = (id, v) => { const el = document.getElementById(id); if (el && v !== undefined) el.textContent = v; };
  set('stat-products', s.products);
  set('stat-online', s.online);
  set('stat-total', s.instances);
}
function dot(online) {
  if (online === true) return '<span class="status-dot pulse"></span>';
  if (online === false) return '<span class="status-dot red"></span>';
  return '<span class="status-dot orange"></span>';   // unknown / not yet validated
}
function renderTree() {
  const root = document.getElementById('tree');
  root.innerHTML = TREE.map(p => {
    const open = !!expanded[p.id];
    const children = (p.instances || []).map(i => `
      <div class="tree-inst" data-id="${i.id}">
        ${dot(i.online)}
        <span class="inst-id" title="click to rename" onclick="hxEditInst('${i.id}', this)">${esc(i.device_id)}</span>
        <span class="text-muted" style="font-size:11px">${esc(i.host || '(no host)')}${i.port ? ':' + i.port : ''}</span>
        <span class="ml-auto flex gap-1">
          <button class="btn btn-cyan btn-sm" onclick="hxValidate('${i.id}')">VALIDATE</button>
          ${p.tier !== 'author'
            ? `<button class="btn btn-violet btn-sm" onclick="hxAct('${i.id}','deploy')">DEPLOY</button>`
            : `<button class="btn btn-green btn-sm" onclick="hxAct('${i.id}','author')">AUTHOR</button>`}
          ${p.tier === 'full' ? `<button class="btn btn-red btn-sm" onclick="hxAct('${i.id}','fire')">FIRE</button>` : ''}
          <button class="btn btn-cyan btn-sm" onclick="hxAct('${i.id}','loot')">LOOT</button>
          <button class="btn btn-red btn-sm" onclick="hxRemoveInst('${i.id}')">✕</button>
        </span>
      </div>`).join('');
    return `
      <div class="tree-product">
        <div class="tree-prod-row" onclick="hxToggle('${p.id}')">
          <span class="tree-toggle">${open ? '－' : '＋'}</span>
          <span class="tree-prod-name">${esc(p.name)}</span>
          <span class="badge ${p.cap_badge}">${esc(p.capability)}</span>
          ${tierBadge(p.tier)}
          <span class="ml-auto tree-prod-meta">${p.online}/${p.total} online · ${esc(p.transport_label)}</span>
        </div>
        <div class="tree-children ${open ? '' : 'collapsed'}">
          ${children || '<div class="tree-inst text-muted">no instances yet</div>'}
          <div class="tree-addrow"><button class="btn btn-sm" onclick="hxAddInst('${p.id}')">＋ add instance</button></div>
        </div>
      </div>`;
  }).join('');
}
window.hxToggle = function (pid) { expanded[pid] = !expanded[pid]; renderTree(); };

window.hxAddInst = async function (pid) {
  try {
    const d = await api('/api/implants/instance', { method: 'POST', body: JSON.stringify({ product_id: pid }) });
    expanded[pid] = true;
    ilog('added instance ' + d.instance.device_id + ' — rename it for the operator');
    await loadTree();
  } catch (e) { ilog('add failed: ' + e.message, 't-err'); }
};
window.hxRemoveInst = async function (id) {
  try { await api('/api/implants/instance/' + id, { method: 'DELETE' }); ilog('removed instance'); await loadTree(); }
  catch (e) { ilog('remove failed: ' + e.message, 't-err'); }
};
window.hxEditInst = function (id, el) {
  const cur = el.textContent;
  const input = document.createElement('input');
  input.className = 'inst-id-input'; input.value = cur;
  el.replaceWith(input); input.focus(); input.select();
  let done = false;
  async function commit() {
    if (done) return; done = true;
    const v = input.value.trim();
    if (v && v !== cur) {
      try { await api('/api/implants/instance/' + id, { method: 'PATCH', body: JSON.stringify({ device_id: v }) }); ilog('renamed → ' + v); }
      catch (e) { ilog('rename failed: ' + e.message, 't-err'); }
    }
    await loadTree();
  }
  input.addEventListener('blur', commit);
  input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); if (e.key === 'Escape') { done = true; loadTree(); } });
};
window.hxValidate = async function (id) {
  ilog('validating callback…', 't-info');
  try {
    const v = await api('/api/implants/instance/' + id + '/validate', { method: 'POST' });
    const r = v.result || v;
    if (r.status === 'ok') ilog(`${r.device_id} → reachable · ${r.detail} · ${r.latency_ms}ms`, 't-ok');
    else if (r.status === 'manual') ilog(`${r.device_id} → ${r.detail}`, 't-warn');
    else ilog(`${r.device_id} → UNREACHABLE · ${r.detail}`, 't-err');
    await loadTree();
  } catch (e) { ilog('validate failed: ' + e.message, 't-err'); }
};
window.hxAct = function (id, action) {
  // Deploy/fire/loot/author are wired to the loot/credentials pipeline in a
  // later phase; for now they log intent so the operator can dry-run the flow.
  const inst = (TREE.flatMap(p => p.instances)).find(i => i.id === id) || {};
  const verbs = {
    deploy: ['t-info', `[deploy] payload push to ${inst.device_id} (${inst.transport_label || ''}) — wiring in next phase`],
    fire:   ['t-warn', `[fire] trigger ${inst.device_id} — watch MSF sessions for callback`],
    loot:   ['t-ok',   `[loot] pull from ${inst.device_id} → validate first via Loot Ingestion`],
    author: ['t-info', `[author] open DuckyScript 3.0 editor for ${inst.device_id}`],
  };
  const [c, m] = verbs[action] || ['t-dim', action];
  ilog(m, c);
};

/* ── payload library (filter by compatible product) ─────────────────────── */
function fillProductFilter() {
  const sel = document.getElementById('payload-product');
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = '<option value="">All products</option>' +
    PRODUCTS.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  sel.value = cur;
}
window.hxRenderPayloads = async function () {
  const q = (document.getElementById('payload-search').value || '').trim();
  const pf = document.getElementById('payload-product').value;
  try {
    const d = await api('/api/implants/payloads?' + new URLSearchParams({ product: pf, q }).toString());
    const rows = d.payloads || [];
    const set = document.getElementById('stat-payloads'); if (set) set.textContent = d.total_all != null ? d.total_all : rows.length;
    document.getElementById('payload-tbody').innerHTML = rows.length ? rows.map(p => `
      <tr>
        <td class="text-cyan">${esc(p.name)}</td>
        <td>${(p.product_names || []).map(n => `<span class="pill">${esc(n.replace('WiFi ', ''))}</span>`).join(' ')}</td>
        <td><span class="badge badge-info">${esc(p.lang)}</span></td>
        <td class="text-muted">${esc(p.attack)}</td>
        <td class="text-green" style="font-size:11px">${esc(p.cm)}</td>
        <td><button class="btn btn-violet btn-sm">STAGE</button> <button class="btn btn-cyan btn-sm">VIEW</button></td>
      </tr>`).join('')
      : '<tr><td colspan="6" class="text-muted" style="text-align:center;padding:1.5rem">no payloads match filter</td></tr>';
  } catch (e) {
    document.getElementById('payload-tbody').innerHTML =
      '<tr><td colspan="6" class="text-red" style="padding:1rem">load failed: ' + esc(e.message) + '</td></tr>';
  }
};

/* ── loot ingestion (connect-validate gate) ─────────────────────────────── */
window.hxClearLoot = function () {
  document.getElementById('loot-terminal').innerHTML = '<span class="t-dim">// cleared //</span>';
  document.getElementById('btn-ingest').disabled = true;
};
window.hxValidateAll = async function () {
  document.getElementById('loot-terminal').innerHTML = '<span class="t-info">[validate] checking callbacks before ingest…</span>';
  try {
    const d = await api('/api/implants/validate-all', { method: 'POST' });
    let ok = 0;
    (d.results || []).forEach(r => {
      if (r.status === 'ok') { ok++; llog(`[connect] ${r.device_id} → reachable · ${r.detail} · ${r.latency_ms}ms`, 't-ok'); }
      else if (r.status === 'manual') llog(`[connect] ${r.device_id} → ${r.detail}`, 't-warn');
      else llog(`[connect] ${r.device_id} → UNREACHABLE · ${r.detail}`, 't-err');
    });
    llog(`[validate] ${ok}/${(d.results || []).length} sources validated — ingest ${ok ? 'ENABLED' : 'blocked'}`, 't-info');
    document.getElementById('btn-ingest').disabled = ok === 0;
    await loadTree();
  } catch (e) { llog('validate failed: ' + e.message, 't-err'); }
};
window.hxIngest = async function () {
  llog('[ingest] pulling from validated sources…', 't-info');
  try {
    const d = await api('/api/implants/ingest', { method: 'POST' });
    (d.steps || []).forEach(s => llog(s.msg, s.cls || 't-info'));
  } catch (e) { llog('ingest failed: ' + e.message, 't-err'); }
};

/* ── wireless / spectrum ────────────────────────────────────────────────── */
async function loadWirelessConfig() {
  try {
    const d = await api('/api/wireless/config');
    const tpl = document.getElementById('ep-template');
    if (tpl) tpl.innerHTML = (d.templates || []).map(t => `<option ${t === (d.evil_portal || {}).template ? 'selected' : ''}>${esc(t)}</option>`).join('');
    const ep = d.evil_portal || {};
    if (ep.ssid) document.getElementById('ep-ssid').value = ep.ssid;
    if (ep.redirect) document.getElementById('ep-redirect').value = ep.redirect;
    if (Array.isArray(ep.capture_fields)) {
      document.getElementById('ep-f-user').checked = ep.capture_fields.includes('username');
      document.getElementById('ep-f-pass').checked = ep.capture_fields.includes('password');
      document.getElementById('ep-f-email').checked = ep.capture_fields.includes('email');
      document.getElementById('ep-f-mfa').checked = ep.capture_fields.includes('mfa');
    }
    document.getElementById('ep-cleartext').checked = !!ep.cleartext_log;
    document.getElementById('ep-https').checked = !!ep.https;
  } catch (e) { /* leave defaults */ }
}
window.hxRecon = async function (silent) {
  try {
    const d = await api('/api/wireless/recon');
    document.getElementById('w-aps').textContent = `${d.ap_24}/${d.ap_5g}`;
    document.getElementById('w-clients').textContent = d.clients;
    document.getElementById('w-hs').textContent = d.handshakes;
    document.getElementById('w-online').textContent = d.online ? 'ONLINE' : 'OFFLINE';
    document.getElementById('w-online').className = 'stat-val ' + (d.online ? 'green' : 'red');
    document.getElementById('w-status').innerHTML = d.online
      ? '<span class="status-dot pulse"></span> PineAP reachable'
      : '<span class="status-dot red"></span> Pineapple offline — add/validate it in Inventory';
    const aps = d.aps || [];
    document.getElementById('ap-tbody').innerHTML = aps.map(a => `
      <tr>
        <td class="text-cyan">${esc(a.ssid)}</td>
        <td class="text-muted mono">${esc(a.bssid)}</td>
        <td><span class="badge ${a.band === '5G' ? 'badge-violet' : 'badge-info'}">${esc(a.band)}</span></td>
        <td>${a.channel}</td>
        <td><span class="badge ${a.enc === 'WPA3' ? 'badge-green' : 'badge-warning'}">${esc(a.enc)}</span></td>
        <td>${a.clients}</td>
        <td>${a.handshake ? '<span class="badge badge-green">CAPTURED</span>' : '<span class="text-muted">—</span>'}</td>
      </tr>`).join('');
    const sel = document.getElementById('dh-target');
    if (sel) sel.innerHTML = aps.map(a => `<option value="${esc(a.bssid)}">${esc(a.ssid)} (${esc(a.bssid)}) · ${esc(a.band)} ch${a.channel}</option>`).join('');
    if (!silent) wlog(`recon: ${d.ap_count} APs (${d.ap_24}×2.4 / ${d.ap_5g}×5G), ${d.clients} clients, ${d.handshakes} handshakes`);
  } catch (e) { wlog('recon failed: ' + e.message, 't-err'); }
};
window.hxArmPortal = async function () {
  const fields = [];
  if (document.getElementById('ep-f-user').checked) fields.push('username');
  if (document.getElementById('ep-f-pass').checked) fields.push('password');
  if (document.getElementById('ep-f-email').checked) fields.push('email');
  if (document.getElementById('ep-f-mfa').checked) fields.push('mfa');
  const body = {
    ssid: document.getElementById('ep-ssid').value,
    template: document.getElementById('ep-template').value,
    redirect: document.getElementById('ep-redirect').value,
    capture_fields: fields,
    cleartext_log: document.getElementById('ep-cleartext').checked,
    https: document.getElementById('ep-https').checked,
  };
  try { const d = await api('/api/wireless/evil-portal', { method: 'POST', body: JSON.stringify(body) }); wlog(d.message, d.live ? 't-ok' : 't-warn'); }
  catch (e) { wlog('evil portal failed: ' + e.message, 't-err'); }
};
window.hxStopPortal = async function () {
  try { await api('/api/wireless/evil-portal/stop', { method: 'POST' }); wlog('evil portal stopped', 't-warn'); }
  catch (e) { wlog('stop failed: ' + e.message, 't-err'); }
};
window.hxStartDeauth = async function () {
  const t = document.getElementById('dh-target');
  const body = {
    target_bssid: t.value,
    client: document.getElementById('dh-client').value,
    band: document.getElementById('dh-band').value,
    bursts: document.getElementById('dh-bursts').value,
    capture: document.getElementById('dh-capture').value,
  };
  try { const d = await api('/api/wireless/deauth', { method: 'POST', body: JSON.stringify(body) }); wlog(d.message, d.live ? 't-ok' : 't-warn'); }
  catch (e) { wlog('deauth failed: ' + e.message, 't-err'); }
};
window.hxStopDeauth = async function () {
  try { await api('/api/wireless/deauth/stop', { method: 'POST' }); wlog('deauth harvest stopped', 't-warn'); }
  catch (e) { wlog('stop failed: ' + e.message, 't-err'); }
};
window.hxExportHs = async function () {
  try { const d = await api('/api/wireless/export-handshakes', { method: 'POST' }); wlog(d.message, 't-ok'); }
  catch (e) { wlog('export failed: ' + e.message, 't-err'); }
};

/* ── boot ───────────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {
  loadTree();
  hxRenderPayloads();
  loadWirelessConfig();
  hxRecon(true);
});
})();
