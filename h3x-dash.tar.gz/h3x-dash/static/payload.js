/* ─────────────────────────────────────────────────────────────────────────
   payload.js — Payload flow front-end: Inventory → Arm → Deploy.
   ───────────────────────────────────────────────────────────────────────── */
(function () {
'use strict';

let TREE = [];                  // payload-class product nodes
let PRODUCTS = [];              // [{id,name,transport,default_port}]
let PAYLOADS_ALL = [];          // payload catalog (decorated)
const expanded = {};

/* ── utils ──────────────────────────────────────────────────────────────── */
function ts() { return new Date().toISOString().slice(11, 19); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function logTo(id, cls, msg) {
  const el = document.getElementById(id); if (!el) return;
  el.innerHTML += `\n<span class="${cls}">[${ts()}] ${esc(msg)}</span>`;
  el.scrollTop = el.scrollHeight;
}
const plog = (m, c = 't-ok') => logTo('p-term', c, m);
const dlog = (m, c = 't-ok') => logTo('dep-term', c, m);

async function api(url, opts) {
  const r = await fetch(url, Object.assign({ headers: { 'Content-Type': 'application/json' } }, opts));
  const body = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(body.error || ('HTTP ' + r.status));
  return body;
}
function tierBadge(t) {
  return t === 'full' ? '<span class="badge badge-green">FULL REMOTE</span>'
    : t === 'managed' ? '<span class="badge badge-warning">SSH MANAGED</span>'
    : '<span class="badge badge-muted">AUTHOR ONLY</span>';
}
function dot(o) {
  return o === true ? '<span class="status-dot pulse"></span>'
    : o === false ? '<span class="status-dot red"></span>'
    : '<span class="status-dot orange"></span>';
}

/* ── tabs ───────────────────────────────────────────────────────────────── */
window.pTab = function (t) {
  ['p-inv', 'p-arm', 'p-deploy'].forEach(x =>
    document.getElementById('view-' + x).classList.toggle('hidden', x !== t));
  document.querySelectorAll('.subtab').forEach(b =>
    b.classList.toggle('active', b.dataset.tab === t));
  if (t === 'p-arm') { fillArmSelects(); armAckChanged(); }
  if (t === 'p-deploy') { renderArmed(); }
};

/* ── inventory tree ─────────────────────────────────────────────────────── */
async function loadTree() {
  try {
    const d = await api('/api/implants/tree?class=payload');
    TREE = d.tree || [];
    PRODUCTS = TREE.map(p => ({ id: p.id, name: p.name, transport: p.transport, default_port: null }));
    renderTree();
    const s = d.stats || {};
    document.getElementById('ps-prod').textContent = s.products ?? '—';
    document.getElementById('ps-on').textContent   = s.online   ?? '—';
    document.getElementById('ps-tot').textContent  = s.instances ?? '—';
    document.getElementById('ps-armed').textContent = s.armed   ?? '—';
    fillAddProduct();
  } catch (e) {
    document.getElementById('tree-p').innerHTML =
      '<div class="text-red" style="padding:1.5rem">load failed: ' + esc(e.message) + '</div>';
  }
}
function renderTree() {
  const root = document.getElementById('tree-p');
  root.innerHTML = TREE.map(p => {
    const open = !!expanded[p.id];
    const children = (p.instances || []).map(i => {
      const armed = i.armed_payload
        ? `<span class="badge badge-warning" title="armed">ARMED · ${esc(i.armed_payload)}</span>` : '';
      return `<div class="tree-inst">
        ${dot(i.online)}
        <span class="inst-id" onclick="pEditInst('${i.id}', this)">${esc(i.device_id)}</span>
        <span class="text-muted" style="font-size:11px">${esc(i.host || '(no host)')}${i.port ? ':' + i.port : ''}</span>
        ${armed}
        <span class="ml-auto flex gap-1">
          <button class="btn btn-cyan btn-sm" onclick="pValidate('${i.id}')">VALIDATE</button>
          <button class="btn btn-violet btn-sm" onclick="pGoArmWith('${i.id}')">→ ARM</button>
          <button class="btn btn-red btn-sm" onclick="pRemove('${i.id}')">✕</button>
        </span>
      </div>`;
    }).join('');
    return `<div class="tree-product">
      <div class="tree-prod-row" onclick="pToggle('${p.id}')">
        <span class="tree-toggle">${open ? '－' : '＋'}</span>
        <span class="tree-prod-name">${esc(p.name)}</span>
        <span class="badge ${p.cap_badge}">${esc(p.capability)}</span>
        ${tierBadge(p.tier)}
        <span class="ml-auto tree-prod-meta">${p.online}/${p.total} online · ${p.armed} armed · ${esc(p.transport_label)}</span>
      </div>
      <div class="tree-children ${open ? '' : 'collapsed'}">
        ${children || '<div class="tree-inst text-muted">no instances — use CONNECT &amp; ADD above</div>'}
      </div>
    </div>`;
  }).join('');
}
window.pToggle = function (pid) { expanded[pid] = !expanded[pid]; renderTree(); };
window.pRemove = async function (id) {
  if (!confirm('Remove this instance from inventory?')) return;
  try { await api('/api/implants/instance/' + id, { method: 'DELETE' }); plog('removed instance', 't-warn'); await loadTree(); }
  catch (e) { plog('remove failed: ' + e.message, 't-err'); }
};
window.pEditInst = function (id, el) {
  const cur = el.textContent;
  const inp = document.createElement('input');
  inp.className = 'inst-id-input'; inp.value = cur;
  el.replaceWith(inp); inp.focus(); inp.select();
  let done = false;
  async function commit() {
    if (done) return; done = true;
    const v = inp.value.trim();
    if (v && v !== cur) {
      try { await api('/api/implants/instance/' + id, { method: 'PATCH', body: JSON.stringify({ device_id: v }) }); plog('renamed → ' + v); }
      catch (e) { plog('rename failed: ' + e.message, 't-err'); }
    }
    await loadTree();
  }
  inp.addEventListener('blur', commit);
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') inp.blur(); if (e.key === 'Escape') { done = true; loadTree(); } });
};
window.pValidate = async function (id) {
  plog('validating callback…', 't-info');
  try {
    const v = await api('/api/implants/instance/' + id + '/validate', { method: 'POST' });
    const r = v.result;
    const cls = r.status === 'ok' ? 't-ok' : r.status === 'manual' ? 't-warn' : 't-err';
    plog(`${r.device_id} → ${r.detail}${r.latency_ms ? ' · ' + r.latency_ms + 'ms' : ''}`, cls);
    await loadTree();
  } catch (e) { plog('validate failed: ' + e.message, 't-err'); }
};
window.pGoArmWith = function (id) { pTab('p-arm'); setTimeout(() => { const s = document.getElementById('arm-inst'); if (s) { s.value = id; armRefresh(); } }, 50); };

/* ── connect-to-add ─────────────────────────────────────────────────────── */
function fillAddProduct() {
  const sel = document.getElementById('add-product');
  if (!sel) return;
  sel.innerHTML = TREE.map(p => `<option value="${p.id}" data-tr="${p.transport}" data-port="${p.default_port || ''}">${esc(p.name)}</option>`).join('');
  addPrefill();
}
window.addPrefill = function () {
  const sel = document.getElementById('add-product');
  const opt = sel.options[sel.selectedIndex]; if (!opt) return;
  const tr = opt.dataset.tr;
  document.getElementById('add-port').value = opt.dataset.port || (tr === 'ssh' ? 22 : tr === 'wifi' ? 80 : '');
  document.getElementById('add-host').placeholder = tr === 'usb' ? '(usb)' : '';
  document.getElementById('add-user').value = tr === 'ssh' ? 'root' : '';
  document.getElementById('add-status').textContent =
    tr === 'usb' ? 'USB device — added without callback validation.' : 'callback validated before add';
};
window.clearAdd = function () {
  ['add-host', 'add-port', 'add-user', 'add-name', 'add-notes'].forEach(id => document.getElementById(id).value = '');
  addPrefill();
};
window.connectAndAdd = async function () {
  const body = {
    product_id: document.getElementById('add-product').value,
    host:       document.getElementById('add-host').value.trim() || undefined,
    port:       parseInt(document.getElementById('add-port').value, 10) || undefined,
    username:   document.getElementById('add-user').value,
    device_id:  document.getElementById('add-name').value.trim() || undefined,
    notes:      document.getElementById('add-notes').value,
  };
  plog(`connecting to ${body.host || '(usb)'}…`, 't-info');
  try {
    const d = await api('/api/implants/connect-add', { method: 'POST', body: JSON.stringify(body) });
    if (d.status === 'added') {
      const v = d.validation || {};
      plog(`added ${d.instance.device_id} — ${v.detail || ''}${v.latency_ms ? ' · ' + v.latency_ms + 'ms' : ''}`, 't-ok');
      clearAdd(); await loadTree();
    } else {
      plog(`add failed: ${d.validation?.detail || 'unreachable'}`, 't-err');
    }
  } catch (e) { plog('add failed: ' + e.message, 't-err'); }
};

/* ── ARM ────────────────────────────────────────────────────────────────── */
async function fillArmSelects() {
  const insts = TREE.flatMap(p => (p.instances || []).map(i => ({ ...i, _product: p })));
  document.getElementById('arm-inst').innerHTML =
    insts.length
      ? insts.map(i => `<option value="${i.id}">${esc(i.device_id)}  —  ${esc(i._product.name)}</option>`).join('')
      : '<option value="">(no instances — add one in Inventory)</option>';
  await armRefresh();
}
window.armRefresh = async function () {
  const id = document.getElementById('arm-inst').value;
  const insts = TREE.flatMap(p => (p.instances || []).map(i => ({ ...i, _product: p })));
  const inst = insts.find(x => x.id === id);
  if (!inst) {
    document.getElementById('arm-payload').innerHTML = '';
    document.getElementById('arm-meta').textContent = '—';
    document.getElementById('arm-pay-meta').textContent = '—';
    return;
  }
  try {
    const d = await api('/api/implants/payloads?product=' + encodeURIComponent(inst._product.id));
    const pays = d.payloads || [];
    document.getElementById('arm-payload').innerHTML = pays.length
      ? pays.map(p => `<option>${esc(p.name)}</option>`).join('')
      : '<option value="">(no compatible payloads)</option>';
    PAYLOADS_ALL = pays;
    document.getElementById('arm-meta').innerHTML =
      `Product: <span class="text-cyan">${esc(inst._product.name)}</span> · `
      + `Transport: ${esc(inst._product.transport_label)} · ${tierBadge(inst._product.tier)} · `
      + `Host: <span class="text-cyan">${esc(inst.host || '(usb)')}${inst.port ? ':' + inst.port : ''}</span>`
      + (inst.armed_payload ? ` · <span class="badge badge-warning">ARMED · ${esc(inst.armed_payload)}</span>` : '');
    const cur = document.getElementById('arm-payload').value;
    const pm = pays.find(x => x.name === cur);
    document.getElementById('arm-pay-meta').innerHTML = pm
      ? `Lang: <span class="text-cyan">${esc(pm.lang)}</span> · ATT&CK: <span class="text-muted">${esc(pm.attack)}</span> · Countermeasure: <span class="text-green">${esc(pm.cm)}</span>`
      : '<span class="text-muted">no payload selected</span>';
    armAckChanged();
  } catch (e) { plog('payload list failed: ' + e.message, 't-err'); }
};
/* Arm tab: One-Click Install is gated on (a) a selected instance,
   (b) a selected compatible payload, and (c) the liability ack on the Arm
   tab itself. On click, the install fires directly (server-side compat check
   + ack-enforcement on the deploy endpoint still apply). The page then
   advances to the Deploy tab so the install log + armed-instances table
   are visible to the operator. */
window.armAckChanged = function () {
  const id  = document.getElementById('arm-inst')    && document.getElementById('arm-inst').value;
  const pay = document.getElementById('arm-payload') && document.getElementById('arm-payload').value;
  const ack = document.getElementById('arm-ack')     && document.getElementById('arm-ack').checked;
  const btn = document.getElementById('btn-install');
  if (btn) btn.disabled = !(id && pay && ack);
  const status = document.getElementById('install-status');
  if (status) {
    status.textContent = !id  ? 'select an instance'
                       : !pay ? 'select a compatible payload'
                       : !ack ? 'acknowledge the statement above to enable'
                              : 'ready to install';
  }
};

window.armInstallNow = async function () {
  const id   = document.getElementById('arm-inst').value;
  const pay  = document.getElementById('arm-payload').value;
  const ack  = document.getElementById('arm-ack').checked;
  if (!id || !pay) { plog('select an instance and a compatible payload first', 't-err'); return; }
  if (!ack)        { plog('liability acknowledgement is required', 't-err'); return; }

  const btn = document.getElementById('btn-install'); if (btn) btn.disabled = true;

  // Advance to the Deploy tab so the streaming install log is visible there.
  pTab('p-deploy');
  dlog(`[ack] liability acknowledged at ${ts()}`, 't-info');

  try {
    const d = await api('/api/implants/instance/' + id + '/arm',
                        { method: 'POST', body: JSON.stringify({ payload: pay }) });
    (d.steps || []).forEach(s => dlog(s.msg, s.cls || 't-info'));
    await loadTree();
    await renderArmed();
    // Reset the Arm tab for the next operation: ack must be re-checked.
    const ackBox = document.getElementById('arm-ack'); if (ackBox) ackBox.checked = false;
    armAckChanged();
  } catch (e) {
    dlog('install failed: ' + e.message, 't-err');
    if (btn) btn.disabled = false;
  }
};

/* Deploy tab: post-install state — armed/deployed instances + the streaming
   install log. The MARK DEPLOYED action still flows through /deploy (which
   enforces ack=true server-side), so we pass ack:true here since the operator
   already acknowledged on the Arm tab to install the payload in the first
   place. MARK RETURNED disarms + clears state. */
async function renderArmed() {
  const tbody = document.getElementById('deploy-tbody'); if (!tbody) return;
  try {
    const d = await api('/api/implants/armed');
    const armed = d.armed || [];
    tbody.innerHTML = armed.length ? armed.map(i => `
      <tr>
        <td class="text-cyan">${esc(i.device_id)}</td>
        <td class="text-muted">${esc(i.product_name)}</td>
        <td><span class="badge badge-warning">${esc(i.armed_payload)}</span></td>
        <td><input type="text" placeholder="target host / SSID / room…" id="dn-${i.id}" value="${esc(i.deploy_target || '')}"></td>
        <td>${i.deployed
            ? '<span class="badge badge-violet">DEPLOYED · ' + esc(i.deployed_at || '') + '</span>'
            : '<span class="badge badge-warning">ARMED · ready to plug in</span>'}</td>
        <td class="flex gap-1">
          ${i.deployed
            ? `<button class="btn btn-green btn-sm" onclick="pMarkReturned('${i.id}')">MARK RETURNED</button>`
            : `<button class="btn btn-red btn-sm"   onclick="pMarkDeployed('${i.id}')">MARK DEPLOYED</button>`}
          <button class="btn btn-sm" onclick="pDisarm('${i.id}')">DISARM</button>
        </td>
      </tr>`).join('')
      : '<tr><td colspan="6" class="text-muted" style="text-align:center;padding:1rem">no armed instances yet — stage an install on the Arm tab</td></tr>';
  } catch (e) { dlog('armed list failed: ' + e.message, 't-err'); }
}
window.renderArmed = renderArmed;

window.pDisarm = async function (id) {
  try { await api('/api/implants/instance/' + id + '/disarm', { method: 'POST' }); dlog('disarmed', 't-warn'); await loadTree(); await renderArmed(); }
  catch (e) { dlog('disarm failed: ' + e.message, 't-err'); }
};
window.pMarkDeployed = async function (id) {
  const note = (document.getElementById('dn-' + id) || {}).value || '';
  try {
    const d = await api('/api/implants/instance/' + id + '/deploy', { method: 'POST', body: JSON.stringify({ target: note, ack: true }) });
    if (d.status === 'deployed') dlog(`[deploy] ${d.instance.device_id} (${d.instance.armed_payload}) → ${note || '(no target)'}`, 't-warn');
    else dlog(`[deploy] denied: ${d.reason}`, 't-err');
    await renderArmed();
  } catch (e) { dlog('deploy failed: ' + e.message, 't-err'); }
};
window.pMarkReturned = async function (id) {
  try {
    const d = await api('/api/implants/instance/' + id + '/return', { method: 'POST' });
    if (d.status === 'returned') dlog(`[recall] ${d.instance.device_id} returned — disarmed`, 't-ok');
    await loadTree(); await renderArmed();
  } catch (e) { dlog('return failed: ' + e.message, 't-err'); }
};

document.addEventListener('DOMContentLoaded', loadTree);
})();
