"""
H3x-Dash MsfEngine
Thread-safe wrapper around pymetasploit3's MsfRpcClient.
Includes socket pre-check, SSL auto-detection, and background
reconnect loop so H3x-Dash keeps trying until msfrpcd is up.

Start msfrpcd (no SSL) before launching H3x-Dash:
    msfrpcd -P msfrpc -S -f
"""
import socket
import threading
import time


# How long to wait for a TCP connection to msfrpcd (seconds)
_CONNECT_TIMEOUT = 5

# Seconds between auto-reconnect attempts
_RETRY_INTERVAL  = 10


def _port_open(host: str, port: int, timeout: float = _CONNECT_TIMEOUT) -> bool:
    """Quick TCP reachability check — avoids hanging the whole app."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


class MsfEngine:

    def __init__(self):
        self._client    = None
        self._connected = False
        self._version   = None
        self._lock         = threading.Lock()
        self._exploit_lock = threading.Lock()   # prevents concurrent exploit launches
        self._retry_thr = None        # background reconnect thread
        self._stop_retry = threading.Event()
        self._last_error = None       # last connection error string

    # ── Connection ────────────────────────────────────────────────────────────

    def connect(self, host='127.0.0.1', port=55553, password='msfrpc', ssl=False) -> dict:
        try:
            from pymetasploit3.msfrpc import MsfRpcClient
        except ImportError:
            return {
                'status':  'error',
                'message': (
                    'pymetasploit3 not installed. Install on Kali: '
                    'sudo apt-get install python3-pymetasploit3  '
                    '(or pip install pymetasploit3 --break-system-packages '
                    'if the apt package is unavailable in your Kali version)'
                ),
            }

        # ── 1. TCP reachability check ─────────────────────────────────────────
        if not _port_open(host, port):
            msg = (
                f'Cannot reach {host}:{port} — '
                'is msfrpcd running?  Start it with: '
                'msfrpcd -P msfrpc -S -f'
            )
            with self._lock:
                self._connected = False
                self._last_error = msg
            return {'status': 'error', 'message': msg}

        # ── 2. Try to authenticate ────────────────────────────────────────────
        #    pymetasploit3 uses requests under the hood; when msfrpcd was started
        #    with -S (no SSL) we must pass ssl=False explicitly AND the library
        #    must not override it.  We try no-SSL first, then SSL as a fallback.
        attempts = [(False, 'no-SSL'), (True, 'SSL')]
        if ssl:
            attempts = [(True, 'SSL'), (False, 'no-SSL')]

        last_exc = None
        for use_ssl, label in attempts:
            try:
                client  = MsfRpcClient(
                    password,
                    server = host,
                    port   = port,
                    ssl    = use_ssl,
                )
                version = client.core.version      # ping — raises if auth fails
                with self._lock:
                    self._client    = client
                    self._version   = version
                    self._connected = True
                    self._last_error = None
                print(f'[H3x-Dash] MSF RPC connected ({label}) — {version}')
                return {'status': 'connected', 'version': version}
            except Exception as exc:
                last_exc = exc
                continue

        msg = f'Auth failed ({host}:{port}): {last_exc}'
        with self._lock:
            self._connected  = False
            self._client     = None
            self._last_error = msg
        return {'status': 'error', 'message': msg}

    def _client_ref(self):
        """
        Snapshot self._client under the lock and return it.
        Callers use the returned reference for RPC calls — safe because even
        if disconnect() sets self._client = None on another thread, the
        snapshot still holds the original object reference.
        Returns None if not connected.
        """
        with self._lock:
            return self._client if self._connected else None

    def disconnect(self):
        self._stop_retry.set()          # kill retry thread if running
        with self._lock:
            self._client    = None
            self._connected = False
            self._version   = None

    def is_connected(self) -> bool:
        return self._connected and self._client is not None

    def get_version(self) -> str | None:
        return self._version

    def get_last_error(self) -> str | None:
        return self._last_error

    def get_session_count(self) -> int:
        return len(self.list_sessions())

    # ── Auto-reconnect ────────────────────────────────────────────────────────

    def start_auto_connect(self, host='127.0.0.1', port=55553,
                           password='msfrpc', ssl=False):
        """
        Spawn a background thread that keeps trying to connect until it
        succeeds.  Safe to call multiple times — only one thread runs.
        """
        if self._retry_thr and self._retry_thr.is_alive():
            return  # already running

        self._stop_retry.clear()
        self._retry_thr = threading.Thread(
            target   = self._reconnect_loop,
            args     = (host, port, password, ssl),
            daemon   = True,
            name     = 'h3x-msf-autoconnect',
        )
        self._retry_thr.start()

    def _reconnect_loop(self, host, port, password, ssl):
        attempt = 0
        while not self._stop_retry.is_set():
            if self.is_connected():
                # Already up — just health-check every _RETRY_INTERVAL seconds
                try:
                    _c = self._client_ref()
                    if _c is None:
                        raise RuntimeError('client is None')
                    _ = _c.core.version
                except Exception:
                    with self._lock:
                        self._connected = False
                        self._client    = None
                    print('[H3x-Dash] MSF RPC connection lost — retrying...')
                self._stop_retry.wait(_RETRY_INTERVAL)
                continue

            attempt += 1
            print(f'[H3x-Dash] MSF RPC connect attempt {attempt} '
                  f'({host}:{port}) ...')
            result = self.connect(host=host, port=port,
                                  password=password, ssl=ssl)
            if result['status'] == 'connected':
                print(f'[H3x-Dash] MSF RPC online — {result.get("version","")}')
                # Stay in loop to health-check, but slow down
                self._stop_retry.wait(_RETRY_INTERVAL)
            else:
                print(f'[H3x-Dash] MSF RPC unavailable — '
                      f'{result.get("message","")}  '
                      f'(retry in {_RETRY_INTERVAL}s)')
                self._stop_retry.wait(_RETRY_INTERVAL)

    # ── Module search ─────────────────────────────────────────────────────────

    def search(self, query: str) -> list:
        client = self._client_ref()
        if client is None:
            return []
        try:
            raw = client.modules.search(query)
            return [
                {
                    'fullname':    m.get('fullname', ''),
                    'type':        m.get('type', ''),
                    'rank':        m.get('rank', ''),
                    'description': m.get('description', ''),
                }
                for m in (raw or [])[:50]
            ]
        except Exception as e:
            return [{'error': str(e)}]

    # ── Exploit execution ─────────────────────────────────────────────────────

    def run_exploit(self, module: str, options: dict, payload: str = None) -> dict:
        client = self._client_ref()
        if client is None:
            return {'status': 'error', 'message': 'Not connected to Metasploit RPC'}
        if not module:
            return {'status': 'error', 'message': 'No module specified'}

        # Prevent concurrent exploit launches on the same RPC connection.
        # Use non-blocking acquire — if already running, reject immediately.
        if not self._exploit_lock.acquire(blocking=False):
            return {'status': 'error',
                    'message': 'An exploit is already running — wait for it to complete'}
        try:
            return self._run_exploit_inner(client, module, options, payload)
        finally:
            self._exploit_lock.release()

    def _run_exploit_inner(self, client, module: str, options: dict,
                           payload: str = None) -> dict:

        log = []
        def L(line=''): log.append(line)

        try:
            # ── Pre-flight info ───────────────────────────────────────────────
            L(f'MODULE   : {module}')
            L(f'TARGET   : {options.get("RHOSTS","?")} : {options.get("RPORT","?")}')
            L(f'PAYLOAD  : {payload or "(module default)"}')
            extra = {k: v for k, v in (options or {}).items()
                     if k not in ('RHOSTS', 'RPORT', 'LHOST', 'LPORT')}
            if extra:
                L(f'OPTIONS  : {extra}')
            lhost = options.get('LHOST', '')
            lport = options.get('LPORT', '')
            if lhost:
                L(f'HANDLER  : {lhost} : {lport}')
            L()

            # ── Parse module type and name from full path ────────────────────
            # Full path format: 'exploit/windows/smb/ms17_010_eternalblue'
            # pymetasploit3 modules.use(type, name) where name does NOT include type prefix.
            # We also support auxiliary/, post/ modules — not just exploits.
            _VALID_TYPES = ('exploit', 'auxiliary', 'post', 'payload', 'evasion')
            _mod_parts   = (module or '').split('/')
            _mod_type    = _mod_parts[0] if _mod_parts and _mod_parts[0] in _VALID_TYPES else 'exploit'
            _mod_name    = '/'.join(_mod_parts[1:]) if len(_mod_parts) > 1 else module

            # ── Load module and set options ───────────────────────────────────
            L(f'[*] Loading module... ({_mod_type})')
            exploit = client.modules.use(_mod_type, _mod_name)

            # pymetasploit3 returns a falsy value (not an exception) when the
            # module path doesn't resolve on the msfrpcd side. Without this
            # guard, `exploit[k] = v` below explodes as the cryptic
            # "'bool' object is not subscriptable" with no useful context.
            if not exploit or not hasattr(exploit, 'options'):
                L(f'[ERROR] Module not loaded: {module}')
                L(f'  msfrpcd did not return a usable module for '
                  f'type "{_mod_type}" path "{_mod_name}".')
                L(f'  Verify it exists:  msfconsole -q -x "use {module}; exit"')
                return {'status': 'error',
                        'message': f'Module not found or failed to load: {module}',
                        'result': '\n'.join(log)}

            try:
                L(f'[*] Rank      : {exploit.rank}')
                L(f'[*] Targets   : {len(exploit.targets)}')
            except Exception:
                pass

            # ── Route options to the correct module ──────────────────────────
            # LHOST/LPORT and other reverse-handler settings are PAYLOAD
            # datastore options — setting them on the exploit module raises
            # "Invalid option 'LHOST'".  We split options into two buckets:
            #   exploit_opts  → set on the exploit module (RHOSTS, RPORT, ...)
            #   payload_opts  → set on the payload object  (LHOST, LPORT, ...)
            _PAYLOAD_OPTS = {
                'LHOST', 'LPORT', 'EXITFUNC', 'EXITONSESSION',
                'ReverseListenerBindAddress', 'ReverseListenerBindPort',
                'ReverseListenerCommTimeout', 'ReverseAllowProxy',
                'StagerRetryCount', 'StagerRetryWait', 'PrependMigrate',
            }
            exploit_opts = {}
            payload_opts = {}
            for k, v in (options or {}).items():
                if v in (None, ''):
                    continue
                (payload_opts if k in _PAYLOAD_OPTS else exploit_opts)[k] = v

            L('[*] Setting exploit options...')
            for k, v in exploit_opts.items():
                try:
                    exploit[k] = v
                    L(f'    {k} => {v}')
                except Exception as opt_err:
                    L(f'    [!] skipped {k}: {opt_err}')

            # ── Session baseline ──────────────────────────────────────────────
            sessions_before = {s['id'] for s in self.list_sessions()}
            L()
            L(f'[*] Sessions before launch : {len(sessions_before)}')

            # ── Aux / post modules cannot deliver payloads ────────────────────
            # smb_login, ssh_login, vnc_login, snmp_enum, etc. are scanners —
            # they run, write results to the job console, and never produce a
            # session no matter what LHOST/LPORT you attach. Pretending they
            # can leads to "Exploit dispatched · no session" confusion.
            # Strip any payload here, drop payload-only options, and tell the
            # operator clearly that this is a scan, not an exploit.
            if _mod_type in ('auxiliary', 'post'):
                if payload or payload_opts:
                    L(f'[!] {_mod_type} module \u2014 payload "'
                      f'{payload or "(unspec)"}" ignored.')
                    L(f'    Auxiliary and post modules do not deliver payloads;')
                    L(f'    no session will result. The module runs as a scanner')
                    L(f'    and writes findings to the MSF job console.')
                    if 'smb' in _mod_name.lower():
                        L(f'    For actual SMB exploitation, try:')
                        L(f'      exploit/windows/smb/ms17_010_eternalblue  (Win7/2008 R2)')
                        L(f'      exploit/windows/smb/psexec                (with creds)')
                    elif 'ssh' in _mod_name.lower():
                        L(f'    For SSH post-auth code execution, try:')
                        L(f'      exploit/multi/ssh/sshexec                 (with creds)')
                    payload      = None
                    payload_opts = {}

            L('[*] Executing...')

            # ── Execute ───────────────────────────────────────────────────────
            if payload:
                p = client.modules.use('payload', payload)
                # Same falsy-return guard as the exploit module above —
                # mistyped or non-existent payloads silently return False
                # and `p[k] = v` would otherwise raise the bool-subscript error.
                if not p or not hasattr(p, 'options'):
                    L(f'[ERROR] Payload not loaded: {payload}')
                    L(f'  msfrpcd did not return a usable payload module.')
                    L(f'  Check the name:  msfconsole -q -x '
                      f'"search payload/{payload.rsplit("/", 1)[-1]}; exit"')
                    return {'status': 'error',
                            'message': f'Payload not found: {payload}',
                            'result': '\n'.join(log)}
                # LHOST/LPORT belong here — on the payload, not the exploit.
                # Default LPORT to 4444 if an LHOST was given without one.
                if 'LHOST' in payload_opts and 'LPORT' not in payload_opts:
                    payload_opts['LPORT'] = 4444
                    L('    LPORT => 4444  (default \u2014 none specified)')
                L('[*] Setting payload options...')
                for k, v in payload_opts.items():
                    try:
                        p[k] = v
                        L(f'    {k} => {v}')
                    except Exception as pe:
                        L(f'    [!] skipped {k}: {pe}')
                result = exploit.execute(payload=p)
            else:
                if payload_opts:
                    L(f'[!] {", ".join(payload_opts)} given but no payload '
                      f'specified \u2014 a reverse handler needs an explicit payload.')
                    L('    Falling back to the module default payload.')
                result = exploit.execute()

            # exploit.execute() returns a dict on success; some failure modes
            # in pymetasploit3 hand back a bool. Guard the .get() calls.
            if not isinstance(result, dict):
                L(f'[ERROR] msfrpcd returned {type(result).__name__} '
                  f'(expected dict). Module rejected the run.')
                L(f'  Common causes: required option missing, target arch '
                  f'mismatch, or RPORT/service unreachable.')
                return {'status': 'error',
                        'message': f'execute() returned {type(result).__name__}',
                        'result': '\n'.join(log)}

            job_id = result.get('job_id', '?')
            uuid   = result.get('uuid', '?')
            label  = 'Scanner' if _mod_type in ('auxiliary', 'post') else 'Exploit'
            L()
            L(f'[+] {label} dispatched')
            L(f'    Job ID  : {job_id}')
            L(f'    UUID    : {uuid}')
            if _mod_type in ('auxiliary', 'post'):
                L(f'    Note: {_mod_type} modules write results to the MSF job')
                L(f'    console \u2014 watch `jobs -i {job_id}` in msfconsole or')
                L(f'    poll module output via the MSF RPC console APIs.')

            # ── Session detection is handled client-side ─────────────────────
            # The browser polls /api/msf/sessions every 2s and diffs against
            # the session set it captured before launch (see exploit.html).
            # No server-side thread needed.

            return {
                'status':  'launched',
                'result':  '\n'.join(log),
                'job_id':  job_id,
                'sessions': [],   # populated async — check /api/msf/sessions
            }

        except Exception as e:
            L()
            L(f'[ERROR] {e}')
            return {'status': 'error', 'message': str(e), 'result': '\n'.join(log)}

    # ── Session management ────────────────────────────────────────────────────

    def list_sessions(self) -> list:
        client = self._client_ref()
        if client is None:
            return []
        try:
            raw = client.sessions.list or {}
            return [
                {
                    'id':       str(sid),
                    'type':     info.get('type', ''),
                    'target':   info.get('target_host', ''),
                    'user':     info.get('username', ''),
                    'platform': info.get('platform', ''),
                    'arch':     info.get('arch', ''),
                    'info':     info.get('info', ''),
                    'tunnel':   info.get('tunnel_local', ''),
                }
                for sid, info in raw.items()
            ]
        except Exception:
            return []

    def session_command(self, session_id: str, command: str) -> dict:
        client = self._client_ref()
        if client is None:
            return {'status': 'error', 'message': 'Not connected to Metasploit RPC'}
        try:
            session = client.sessions.session(session_id)
            session.write(command + '\n')
            time.sleep(1.5)
            output = session.read()
            return {'status': 'ok', 'output': output or ''}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
