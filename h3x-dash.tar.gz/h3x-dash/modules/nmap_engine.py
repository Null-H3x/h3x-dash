"""
H3x-Dash NmapEngine
Wraps Nmap-Configurobulator.py as a stateful, threaded scan manager.
The Configurobulator is loaded via importlib so we don't need to rename
the file — just drop it alongside app.py.
"""
import threading
import importlib.util
import sys
import builtins
from datetime import datetime
from pathlib import Path

from config import H3xConfig

# ── Load Configurobulator ─────────────────────────────────────────────────────

_CFGPATH = Path(__file__).parent.parent / 'Nmap-Configurobulator.py'
_cfgmod  = None

def _load_configurobulator():
    global _cfgmod
    if _cfgmod is not None:
        return True
    if not _CFGPATH.exists():
        return False
    try:
        spec = importlib.util.spec_from_file_location('nmap_configurobulator', _CFGPATH)
        mod  = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _cfgmod = mod
        return True
    except Exception as e:
        print(f'[H3x-Dash] Configurobulator load error: {e}')
        return False

_load_configurobulator()

# ── Exported constants (with fallbacks) ───────────────────────────────────────

PORT_RISK = getattr(_cfgmod, 'PORT_RISK', {
    21: ('ftp', 'danger'), 22: ('ssh', 'info'), 23: ('telnet', 'danger'),
    25: ('smtp', 'warning'), 53: ('dns', 'info'), 80: ('http', 'info'),
    139: ('netbios', 'danger'), 161: ('snmp', 'warning'), 389: ('ldap', 'warning'),
    443: ('https', 'info'), 445: ('smb', 'danger'), 1433: ('mssql', 'danger'),
    3306: ('mysql', 'warning'), 3389: ('rdp', 'danger'), 5432: ('psql', 'warning'),
    5900: ('vnc', 'warning'), 6379: ('redis', 'danger'), 8080: ('http-alt', 'info'),
    9200: ('elasticsearch', 'danger'), 27017: ('mongodb', 'danger'),
})

PORT_PROFILES = getattr(_cfgmod, 'PORT_PROFILES', {
    'driveby':  '21-25,53,80,110-111,135,139,161,389,443,445,1433,1521,3306,3389,5432,5900,6379,8080,8443,9200,27017',
    'spyglass': '1-1024,1433,1521,3306,3389,5432,5900,6379,8080,8443,9200,27017',
    'full':     '1-65535',
})

TIMING_DESC = getattr(_cfgmod, 'TIMING_DESC', {
    'T1': 'Sneaky Ninja     — very slow, IDS evasion',
    'T2': 'Polite Brit      — slow, low bandwidth',
    'T3': 'Boringly Average — default nmap timing',
    'T4': 'Antagonistic     — fast, reliable on LAN  (recommended)',
    'T5': 'Roid Rage        — maximum speed, may drop packets',
})

SCRIPT_PROFILES = getattr(_cfgmod, 'SCRIPT_PROFILES', {
    'none': [], 'banner': ['banner'], 'default': ['default', 'banner'],
    'safe': ['safe', 'banner'], 'vuln': ['vuln', 'default', 'banner'],
    'full': ['vuln', 'auth', 'discovery', 'default', 'banner'],
})

SCRIPT_DESC = getattr(_cfgmod, 'SCRIPT_DESC', {
    'none':    'No scripts — fastest',
    'banner':  'Banner grab only',
    'default': 'Default + banner',
    'safe':    'Safe scripts',
    'vuln':    'Vulnerability scan',
    'full':    'Full suite — very slow',
})


# ── State machine ─────────────────────────────────────────────────────────────

class ScanState:
    IDLE     = 'idle'
    RUNNING  = 'running'
    COMPLETE = 'complete'
    ERROR    = 'error'


# ── NmapEngine ────────────────────────────────────────────────────────────────

class NmapEngine:
    def __init__(self):
        self._state   = ScanState.IDLE
        self._hosts   = []      # parsed host dicts
        self._meta    = {}      # scan metadata
        self._history = []      # past scan summaries
        self._lock    = threading.Lock()
        self._thread  = None
        self._stop_ev = threading.Event()

    # ── Public API ────────────────────────────────────────────────────────────

    def start_scan(self, params: dict, on_output=None, on_complete=None) -> bool:
        """Launch a background scan. Returns False if one is already running."""
        with self._lock:
            if self._state == ScanState.RUNNING:
                return False
            self._state = ScanState.RUNNING
            self._stop_ev.clear()

        self._thread = threading.Thread(
            target  = self._run,
            args    = (params, on_output, on_complete),
            daemon  = True,
            name    = 'h3x-nmap-scan',
        )
        self._thread.start()
        return True

    def stop_scan(self):
        self._stop_ev.set()

    def get_status(self) -> dict:
        return {
            'state':      self._state,
            'host_count': len(self._hosts),
            'meta':       self._meta,
        }

    def get_results(self) -> dict:
        return {'hosts': self._hosts, 'meta': self._meta}

    def get_hosts_with_ports(self) -> list:
        return [h for h in self._hosts if h.get('ports')]

    def get_host_count(self)  -> int: return len(self._hosts)
    def get_scan_count(self)  -> int: return len(self._history)

    def get_vuln_count(self) -> int:
        return sum(
            1 for h in self._hosts
            for p in h.get('ports', [])
            if p.get('risk') == 'danger'
        )

    def get_recent_activity(self) -> list:
        return list(reversed(self._history[-10:]))

    # ── Internal scan runner ──────────────────────────────────────────────────

    @staticmethod
    def _is_relevant(raw: str) -> bool:
        """Filter noisy Configurobulator output — only pass meaningful findings."""
        import re as _re
        line = _re.sub(r'\x1b\[[0-9;]*[mGKHF]', '', raw).strip()
        if not line:
            return False
        if line.startswith('[H3x-Dash]'):
            return True
        lo = line.lower()
        if 'nmap scan report' in lo:
            return True
        if _re.search(r'\d+/(tcp|udp)', lo):
            return True
        if ('host' in lo or 'hosts' in lo) and ('up' in lo or 'down' in lo):
            return True
        if 'elapsed' in lo or ('done' in lo and 'nmap' in lo):
            return True
        if any(x in lo for x in ('[error]', '[!]', 'error:', 'warning:', 'failed')):
            return True
        if line.startswith('|'):
            return True
        if lo.startswith(('mac address', 'os details', 'running:', 'service info:')):
            return True
        if any(line.startswith(x) for x in ('[+]', '[*]', '[\u2713]')):
            return True
        return False

    def _run(self, params: dict, on_output, on_complete):
        def emit(line: str, force: bool = False):
            if on_output and (force or self._is_relevant(line)):
                on_output(line)

        try:
            if _cfgmod is None:
                raise RuntimeError(
                    'Nmap-Configurobulator.py not found. '
                    f'Expected at: {_CFGPATH}'
                )

            # Build Config object from dashboard params
            cfg              = _cfgmod.Config()
            cfg.target       = params.get('target', '')
            cfg.timing       = params.get('timing',       H3xConfig.DEFAULT_TIMING)
            cfg.port_profile = params.get('port_profile', H3xConfig.DEFAULT_PORTS)
            cfg.scripts      = params.get('scripts',      H3xConfig.DEFAULT_SCRIPTS)
            cfg.use_sudo     = params.get('use_sudo',     True)
            cfg.out_dir      = str(H3xConfig.NMAP_DIR)
            cfg.extra_args   = params.get('extra_args', [])

            emit(f'[H3x-Dash] Target       : {cfg.target}')
            emit(f'[H3x-Dash] Port profile : {cfg.port_profile}')
            emit(f'[H3x-Dash] Timing       : {cfg.timing}')
            emit(f'[H3x-Dash] NSE scripts  : {cfg.scripts}')

            _cfgmod.preflight_check(cfg)

            # Capture all print() output from Configurobulator
            _orig_print = builtins.print
            def _capture(*args, **kw):
                line = ' '.join(str(a) for a in args)
                emit(line)
                _orig_print(*args, **kw)

            builtins.print = _capture
            try:
                xml_str, nmap_cmd, monitor = _cfgmod.run_nmap(cfg)
                hosts, meta, down_ips, no_port_ips = _cfgmod.parse_nmap_xml(xml_str, cfg.target)

                # Enrich hosthint-recovered hosts with PTY-captured port data
                if monitor.discovered_ports:
                    for h in hosts:
                        if h.get('_from_hint'):
                            live = monitor.discovered_ports.get(h['ip'], [])
                            if live:
                                h['ports'] = sorted(live, key=lambda p: p['port'])

                hosts = _cfgmod.inject_local_host(hosts, cfg.target)
                nodes, links = _cfgmod.build_topology(hosts) if hosts else ([], [])

                meta['command']     = nmap_cmd
                meta['down_ips']    = down_ips
                meta['no_port_ips'] = no_port_ips
                meta['target']      = cfg.target

            finally:
                builtins.print = _orig_print

            with self._lock:
                self._hosts = nodes
                self._meta  = meta
                self._state = ScanState.COMPLETE
                self._history.append({
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'target':    cfg.target,
                    'hosts':     len(nodes),
                    'command':   nmap_cmd,
                    'state':     'complete',
                })

            emit(f'[H3x-Dash] Scan complete — {len(nodes)} host(s) found.')
            if on_complete:
                on_complete(nodes, meta)

        except Exception as exc:
            with self._lock:
                self._state          = ScanState.ERROR
                self._meta['error']  = str(exc)
                self._history.append({
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'target':    params.get('target', '?'),
                    'hosts':     0,
                    'state':     'error',
                    'error':     str(exc),
                })
            emit(f'[H3x-Dash][ERROR] {exc}')
            if on_output:
                on_output(f'[ERROR] {exc}')
