"""
auto_chain.py — Closed-loop "land a stable shell" orchestrator.

This is the post-validate automation the operator asked for, expressed as a
state machine that is driven entirely by the flexible resolver + the
information-gained feedback loop — NOT by hardcoded per-module ladders:

    recommend ──► run ──► shell check ─┬─ alive ─► persist ─► STOP (success)
        ▲                              │
        │                             dead/quiet/no-session
        │                              │
        └──── re-arm ◄── gather information ◄┘

Termination is information-driven, so it can't loop forever and isn't a fixed
recipe:
  • success      — a session confirmed alive and persisted
  • halted       — a verdict says the target is NOT vulnerable (no retry helps)
  • needs_input  — the recommended plan needs an operator-supplied option
                   (e.g. TARGETURI) that automation can't invent
  • exhausted    — re-arming produced a plan we already tried (no NEW information
                   to act on), or the attempt cap was hit

The orchestrator is pure control-flow: it calls an `engine` object that provides
recommend_plan / run_plan / confirm_session / persist_session / list_sessions.
That keeps it fully unit-testable with a scripted mock engine (audit_auto_chain).
"""
from __future__ import annotations

import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable


def plan_signature(plan: dict) -> tuple:
    """A hashable identity for a plan — used to detect 'no new information'."""
    opts = plan.get('options') or {}
    return (
        plan.get('connection_mode'),
        plan.get('payload'),
        plan.get('target_index'),
        tuple(sorted((str(k), str(v)) for k, v in opts.items())),
    )


def _session_id_from_result(result: dict) -> str | None:
    sessions = result.get('sessions') or []
    if sessions:
        return str(sessions[0].get('id'))
    return None


def run_auto_chain(engine, module: str, environment: dict, *,
                   max_attempts: int = 5,
                   session_wait: float = 0.0,
                   emit: Callable[[dict], None] | None = None) -> dict[str, Any]:
    """
    Drive the recommend→run→check→persist/re-arm loop until a stable shell lands
    or the chain terminates for an information-driven reason.

    `engine` must provide:
      recommend_plan(module, environment) -> plan
      run_plan(module, plan, environment) -> run result (with information_gained)
      confirm_session(sid) -> {alive, dead, output, ...}
      persist_session(sid) -> {persisted, ...}
      list_sessions() -> [ {id, ...} ]   (for late-session polling)
    """
    emit = emit or (lambda ev: None)
    tried: set = set()
    history: list[dict] = []

    def _emit(phase, **kw):
        ev = {'phase': phase, **kw}
        try:
            emit(ev)
        except Exception:
            pass
        return ev

    _emit('start', module=module, rhost=environment.get('rhost', ''),
          max_attempts=max_attempts)

    for attempt in range(1, max_attempts + 1):
        # ── RECOMMEND (re-armed by all insights gathered so far) ─────────────
        plan = engine.recommend_plan(module, environment)
        _emit('recommend', attempt=attempt,
              mode=plan.get('connection_mode'), payload=plan.get('payload'),
              target_index=plan.get('target_index'),
              rationale=plan.get('rationale', []),
              applied_insights=plan.get('applied_insights', []))

        # Halt: a prior verdict said NOT vulnerable.
        if plan.get('stop'):
            _emit('halt', reason='not_vulnerable', attempt=attempt)
            return {'status': 'halted', 'reason': 'not_vulnerable',
                    'attempts': history, 'attempt_count': attempt - 1}

        # Needs operator input the automation can't invent.
        if plan.get('information_needed'):
            _emit('needs_input', attempt=attempt,
                  need=plan['information_needed'])
            return {'status': 'needs_input',
                    'need': plan['information_needed'],
                    'attempts': history, 'attempt_count': attempt - 1}

        # No NEW information — re-arm produced a plan we already ran.
        sig = plan_signature(plan)
        if sig in tried:
            _emit('exhausted', reason='no_new_information', attempt=attempt)
            return {'status': 'exhausted', 'reason': 'no_new_information',
                    'attempts': history, 'attempt_count': attempt - 1}
        tried.add(sig)

        # ── RUN ──────────────────────────────────────────────────────────────
        _emit('run', attempt=attempt, mode=plan.get('connection_mode'),
              payload=plan.get('payload') or 'module default')
        result = engine.run_plan(module, plan, environment)
        info = result.get('information_gained') or []

        # ── SHELL CHECK ────────────────────────────────────────────────────
        sid = _session_id_from_result(result)
        if not sid and result.get('session_unconfirmed') and session_wait > 0:
            # Console said opened but the list lagged — poll briefly.
            sid = _poll_for_session(engine, session_wait)

        check = None
        if sid:
            check = engine.confirm_session(sid)
            _emit('shell_check', attempt=attempt, sid=sid,
                  alive=bool(check.get('alive')), dead=bool(check.get('dead')),
                  output=(check.get('output') or '')[:2000])
            if check.get('alive'):
                # ── PERSIST → STOP ────────────────────────────────────────
                persist = engine.persist_session(sid)
                _emit('success', attempt=attempt, sid=sid,
                      session_type=persist.get('session_type'),
                      persisted=bool(persist.get('persisted')),
                      recon=(persist.get('recon') or check.get('output') or '')[:2000])
                return {'status': 'success', 'sid': sid, 'persist': persist,
                        'attempts': history, 'attempt_count': attempt}
        else:
            _emit('no_session', attempt=attempt)

        # ── GATHER INFORMATION → RE-ARM (next loop) ──────────────────────────
        gained = [i.get('message') for i in info]
        history.append({'attempt': attempt, 'plan': plan,
                        'information_gained': info,
                        'check': check, 'sid': sid})
        _emit('rearm', attempt=attempt, gained=gained,
              session_was=('alive' if (check and check.get('alive'))
                           else 'dead' if (check and check.get('dead'))
                           else 'none'))

    _emit('exhausted', reason='max_attempts', attempt=max_attempts)
    return {'status': 'exhausted', 'reason': 'max_attempts',
            'attempts': history, 'attempt_count': max_attempts}


class AutoChainRunner:
    """
    Thread-backed wrapper around run_auto_chain for the UI. The orchestrator runs
    in the background; the UI polls snapshot() for the streamed event log + final
    result. Only one chain runs at a time.
    """

    def __init__(self, engine):
        self._engine = engine
        self._lock = threading.Lock()
        self._thread = None
        self._running = False
        self._events: list[dict] = []
        self._result: dict | None = None
        self._target: dict | None = None

    def is_running(self) -> bool:
        with self._lock:
            return self._running

    def _sink(self, ev: dict) -> None:
        ev = dict(ev)
        ev['ts'] = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._events.append(ev)

    def start(self, module: str, environment: dict, max_attempts: int = 5) -> bool:
        with self._lock:
            if self._running:
                return False
            self._running = True
            self._events = []
            self._result = None
            self._target = {'module': module, 'rhost': environment.get('rhost', '')}

        def _worker():
            try:
                result = run_auto_chain(self._engine, module, environment,
                                        max_attempts=max_attempts,
                                        session_wait=20.0, emit=self._sink)
            except Exception as exc:
                self._sink({'phase': 'error', 'message': str(exc)})
                result = {'status': 'error', 'message': str(exc)}
            finally:
                with self._lock:
                    self._result = result
                    self._running = False

        self._thread = threading.Thread(target=_worker, daemon=True,
                                        name='h3x-auto-chain')
        self._thread.start()
        return True

    def snapshot(self) -> dict:
        with self._lock:
            return {
                'running': self._running,
                'target':  dict(self._target) if self._target else None,
                'events':  list(self._events),
                'result':  dict(self._result) if self._result else None,
            }


def _poll_for_session(engine, wait: float, interval: float = 1.0) -> str | None:
    """Poll list_sessions for a newly-registered session id, up to `wait` secs."""
    try:
        before = {str(s.get('id')) for s in engine.list_sessions()}
    except Exception:
        before = set()
    deadline = time.time() + wait
    while time.time() < deadline:
        time.sleep(interval)
        try:
            now = engine.list_sessions()
        except Exception:
            now = []
        fresh = [str(s.get('id')) for s in now if str(s.get('id')) not in before]
        if fresh:
            return fresh[-1]
    return None
