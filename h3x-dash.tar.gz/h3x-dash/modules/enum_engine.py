"""
H3x-Dash EnumEngine
Post-scan enumeration dispatcher. Triggered by open port data from NmapEngine.
Runs service-specific Kali tools in parallel threads per host, streams output
via SSE callback, and builds structured findings that enrich the CVE chain.

Tool install reference (Kali):
    sudo apt-get install -y nikto whatweb gobuster sslyze enum4linux-ng \
        smbmap netexec onesixtyone snmp dnsrecon ldap-utils ssh-audit
"""

import ftplib
import json
import re
import shutil
import socket
import subprocess
import threading
import urllib.request
from pathlib import Path

from config import H3xConfig
from modules.preflight import validate_ip

# ── Tool availability check ───────────────────────────────────────────────────

# Common Kali/Debian tool directories — checked explicitly when shutil.which()
# returns None. Under 'sudo', the secure_path in /etc/sudoers often strips
# directories that appear in the interactive shell PATH, causing tools to appear
# absent even when they're installed.
_KALI_PATHS = [
    '/usr/bin', '/usr/sbin',
    '/usr/local/bin', '/usr/local/sbin',
    '/bin', '/sbin',
    '/usr/games', '/usr/local/games',
]


def _which(tool: str) -> str | None:
    """
    Find a tool binary. Tries shutil.which() first (respects PATH), then falls
    back to an explicit walk of common Kali installation directories so that
    tools installed via apt are found even when sudo strips PATH.
    """
    import os as _os

    found = shutil.which(tool)
    if found:
        return found

    # Explicit fallback — covers the sudo secure_path stripping case
    for directory in _KALI_PATHS:
        candidate = _os.path.join(directory, tool)
        if _os.path.isfile(candidate) and _os.access(candidate, _os.X_OK):
            return candidate

    return None


# ── Port → tool trigger map ───────────────────────────────────────────────────
# Maps open port numbers to the list of tool IDs that should run against it.

PORT_TOOLS: dict[int, list[str]] = {
    21:    ['ftp_anon', 'searchsploit'],
    22:    ['ssh_audit', 'searchsploit'],
    25:    ['smtp_enum'],
    53:    ['dnsrecon'],
    80:    ['httpx', 'whatweb', 'nikto', 'gobuster', 'feroxbuster', 'nuclei'],
    110:   ['smtp_enum'],
    137:   ['nbtscan'],
    139:   ['nbtscan', 'enum4linux', 'smbmap'],
    161:   ['snmp_check'],
    389:   ['ldap_enum'],
    443:   ['httpx', 'sslyze', 'testssl', 'whatweb', 'nikto', 'gobuster_ssl',
            'feroxbuster', 'nuclei'],
    445:   ['enum4linux', 'smbmap', 'netexec', 'searchsploit'],
    636:   ['sslyze', 'testssl', 'ldap_enum'],
    1433:  ['searchsploit'],
    3306:  ['searchsploit'],
    3389:  ['rdp_check'],
    5432:  ['searchsploit'],
    5900:  ['vnc_check'],
    6379:  ['redis_check'],
    8080:  ['httpx', 'whatweb', 'nikto', 'gobuster', 'feroxbuster', 'nuclei'],
    8443:  ['httpx', 'sslyze', 'testssl', 'whatweb', 'nikto', 'gobuster_ssl',
            'feroxbuster', 'nuclei'],
    9200:  ['elastic_check', 'nuclei'],
    27017: ['mongo_check'],
}

# Service name triggers (supplement port-based triggers)
SERVICE_TOOLS: dict[str, list[str]] = {
    'http':          ['httpx', 'whatweb', 'nikto', 'gobuster', 'feroxbuster', 'nuclei'],
    'https':         ['httpx', 'sslyze', 'testssl', 'whatweb', 'nikto',
                      'gobuster_ssl', 'feroxbuster', 'nuclei'],
    'ssl/http':      ['httpx', 'sslyze', 'testssl', 'whatweb', 'nikto',
                      'gobuster_ssl', 'feroxbuster', 'nuclei'],
    'ftp':           ['ftp_anon', 'searchsploit'],
    'ssh':           ['ssh_audit', 'searchsploit'],
    'smtp':          ['smtp_enum'],
    'smb':           ['nbtscan', 'enum4linux', 'smbmap', 'netexec'],
    'microsoft-ds':  ['nbtscan', 'enum4linux', 'smbmap', 'netexec'],
    'netbios-ssn':   ['nbtscan', 'enum4linux', 'smbmap'],
    'snmp':          ['snmp_check'],
    'ldap':          ['ldap_enum'],
    'rdp':           ['rdp_check'],
    'ms-wbt-server': ['rdp_check'],
    'vnc':           ['vnc_check'],
    'redis':         ['redis_check'],
    'elasticsearch': ['elastic_check', 'nuclei'],
    'mongodb':       ['mongo_check'],
}

TOOL_LABELS: dict[str, str] = {
    'whatweb':      'WhatWeb',
    'nikto':        'Nikto',
    'gobuster':     'GoBuster',
    'gobuster_ssl': 'GoBuster (SSL)',
    'sslyze':       'SSLyze',
    'enum4linux':   'enum4linux-ng',
    'smbmap':       'smbmap',
    'netexec':      'NetExec',
    'snmp_check':   'onesixtyone + snmpwalk',
    'smtp_enum':    'smtp-user-enum',
    'ldap_enum':    'ldapsearch',
    'dnsrecon':     'dnsrecon',
    'ftp_anon':     'FTP anon check',
    'ssh_audit':    'ssh-audit',
    'rdp_check':    'rdp-sec-check (nmap NSE)',
    'vnc_check':    'VNC probe',
    'redis_check':  'Redis probe',
    'elastic_check':'Elasticsearch probe',
    'mongo_check':  'MongoDB probe',
    'searchsploit': 'searchsploit',
    'httpx':        'httpx (HTTP triage)',
    'nbtscan':      'nbtscan (NetBIOS)',
    'feroxbuster':  'feroxbuster (content discovery)',
    'nuclei':       'nuclei (template scan)',
    'testssl':      'testssl.sh (deep TLS)',
}

SEVERITY_ORDER = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3, 'INFO': 4}

# ── Sweep depth tiers ─────────────────────────────────────────────────────────
# A tool runs only when its tier <= the operator-selected sweep depth.
#   TIER 1 RECON    — fast, low-noise: service probes, HTTP triage, NetBIOS
#   TIER 2 STANDARD — the default working depth: nikto, gobuster, enum4linux,
#                     sslyze, snmp, ldap, etc. (preserves prior behaviour)
#   TIER 3 DEEP     — slow / loud / opt-in: nuclei, feroxbuster, testssl.sh
# Defaulting to STANDARD means existing behaviour is unchanged — the new
# Tier-3 tools never fire unless the operator explicitly asks for a deep sweep.
TIER_RECON, TIER_STANDARD, TIER_DEEP = 1, 2, 3

TOOL_TIERS: dict[str, int] = {
    # ── Tier 1 — Recon (fast, low-noise) ──────────────────────────────────────
    'httpx':         TIER_RECON,
    'nbtscan':       TIER_RECON,
    'ftp_anon':      TIER_RECON,
    'vnc_check':     TIER_RECON,
    'redis_check':   TIER_RECON,
    'elastic_check': TIER_RECON,
    'mongo_check':   TIER_RECON,
    'searchsploit':  TIER_RECON,
    # ── Tier 2 — Standard (default depth) ─────────────────────────────────────
    'whatweb':       TIER_STANDARD,
    'nikto':         TIER_STANDARD,
    'gobuster':      TIER_STANDARD,
    'gobuster_ssl':  TIER_STANDARD,
    'sslyze':        TIER_STANDARD,
    'enum4linux':    TIER_STANDARD,
    'smbmap':        TIER_STANDARD,
    'netexec':       TIER_STANDARD,
    'snmp_check':    TIER_STANDARD,
    'smtp_enum':     TIER_STANDARD,
    'ldap_enum':     TIER_STANDARD,
    'dnsrecon':      TIER_STANDARD,
    'ssh_audit':     TIER_STANDARD,
    'rdp_check':     TIER_STANDARD,
    # ── Tier 3 — Deep (slow / loud / opt-in) ──────────────────────────────────
    'nuclei':        TIER_DEEP,
    'feroxbuster':   TIER_DEEP,
    'testssl':       TIER_DEEP,
}

TIER_LABELS = {
    TIER_RECON:    'Recon',
    TIER_STANDARD: 'Standard',
    TIER_DEEP:     'Deep',
}


# ── State ─────────────────────────────────────────────────────────────────────

class EnumState:
    IDLE     = 'idle'
    RUNNING  = 'running'
    COMPLETE = 'complete'
    ERROR    = 'error'


# ── EnumEngine ────────────────────────────────────────────────────────────────

class EnumEngine:

    def __init__(self):
        self._state       = EnumState.IDLE
        self._findings    = {}   # {ip: [finding_dict, ...]}
        self._tool_status = {}   # {ip: {tool_id: 'pending'|'running'|'done'|'error'|'skip'}}
        self._lock        = threading.Lock()

    # ── Public API ────────────────────────────────────────────────────────────

    def start_enum(self, hosts: list, params: dict,
                   on_output=None, on_finding=None, on_complete=None) -> bool:
        with self._lock:
            if self._state == EnumState.RUNNING:
                return False
            self._state       = EnumState.RUNNING
            self._findings    = {}
            self._tool_status = {}

        threading.Thread(
            target  = self._run,
            args    = (hosts, params, on_output, on_finding, on_complete),
            daemon  = True,
            name    = 'h3x-enum',
        ).start()
        return True

    def get_status(self) -> dict:
        return {
            'state':         self._state,
            'tool_status':   self._tool_status,
            'finding_count': sum(len(v) for v in self._findings.values()),
        }

    def get_findings(self) -> dict:
        return self._findings

    def get_findings_flat(self) -> list:
        with self._lock:
            # Snapshot the dict and each list before iterating
            snapshot = {ip: list(lst) for ip, lst in self._findings.items()}
        flat = []
        for ip, findings in snapshot.items():
            for f in findings:
                flat.append({**f, 'host_ip': ip})
        return sorted(flat, key=lambda x: SEVERITY_ORDER.get(x.get('severity', 'INFO'), 4))

    def get_findings_for_host(self, ip: str) -> list:
        return self._findings.get(ip, [])

    def get_finding_count(self) -> int:
        return sum(len(v) for v in self._findings.values())

    @staticmethod
    def available_tools() -> dict[str, bool]:
        return {
            'whatweb':       bool(_which('whatweb')),
            'nikto':         bool(_which('nikto')),
            'gobuster':      bool(_which('gobuster')),
            'sslyze':        bool(_which('sslyze')),
            'enum4linux-ng': bool(_which('enum4linux-ng') or _which('enum4linux')),
            'smbmap':        bool(_which('smbmap')),
            'netexec':       bool(_which('netexec') or _which('nxc') or _which('crackmapexec')),
            'onesixtyone':   bool(_which('onesixtyone')),
            'snmpwalk':      bool(_which('snmpwalk')),
            'dnsrecon':      bool(_which('dnsrecon')),
            'ldapsearch':    bool(_which('ldapsearch')),
            'ssh-audit':     bool(_which('ssh-audit')),
            'searchsploit':  bool(_which('searchsploit')),
            'nmap':          bool(_which('nmap')),
            'httpx':         bool(_which('httpx') or _which('httpx-toolkit')),
            'nbtscan':       bool(_which('nbtscan')),
            'feroxbuster':   bool(_which('feroxbuster')),
            'nuclei':        bool(_which('nuclei')),
            'testssl.sh':    bool(_which('testssl') or _which('testssl.sh')),
        }

    # ── Orchestrator ──────────────────────────────────────────────────────────

    def _run(self, hosts, params, on_output, on_finding, on_complete):
        def emit(line):
            if on_output:
                on_output(line)

        # Cap concurrent host threads — avoids spawning 50+ subprocess trees on a /24
        _HOST_CONCURRENCY = 8
        _sem = threading.Semaphore(_HOST_CONCURRENCY)

        try:
            emit(f'[H3x-Dash] Enumeration started — {len(hosts)} host(s) queued '
                 f'(max {_HOST_CONCURRENCY} concurrent)')

            host_threads = []
            for host in hosts:
                ip = host.get('ip')
                if not ip:
                    continue
                with self._lock:
                    self._findings[ip]    = []
                    self._tool_status[ip] = {}

                def _target(h=host, s=_sem):
                    with s:
                        self._enumerate_host(h, params, on_output, on_finding)

                t = threading.Thread(
                    target = _target,
                    daemon = True,
                    name   = f'h3x-enum-{ip}',
                )
                host_threads.append(t)
                t.start()

            for t in host_threads:
                t.join()

            total = self.get_finding_count()
            with self._lock:
                self._state = EnumState.COMPLETE

            emit(f'[H3x-Dash] Enumeration complete — {total} finding(s) across {len(hosts)} host(s)')
            if on_complete:
                on_complete(self._findings)

        except Exception as exc:
            with self._lock:
                self._state = EnumState.ERROR
            emit(f'[ERROR] Enumeration crashed: {exc}')

    def _enumerate_host(self, host, params, on_output, on_finding):
        ip    = host.get('ip', '')
        ports = host.get('ports', [])

        # Validate IP before passing to any subprocess
        if not validate_ip(ip):
            if on_output:
                on_output(f'[SKIP] Invalid/unsafe IP rejected: {ip!r}')
            return

        def emit(line):
            if on_output:
                on_output(f'[{ip}] {line}')

        def finding(f):
            with self._lock:
                self._findings[ip].append(f)
            if on_finding:
                on_finding({**f, 'host_ip': ip})

        # Build tool dispatch table for this host
        # tool_id -> best context (port, service, version)
        dispatch: dict[str, dict] = {}

        for port_info in ports:
            port_num = port_info.get('port')
            service  = (port_info.get('service') or '').lower().strip()
            version  = (port_info.get('version') or '').strip()
            ctx      = {'port': port_num, 'service': service, 'version': version}

            for tool in PORT_TOOLS.get(port_num, []):
                dispatch.setdefault(tool, ctx)

            for svc_key, tool_list in SERVICE_TOOLS.items():
                if svc_key in service:
                    for tool in tool_list:
                        dispatch.setdefault(tool, ctx)

        if not dispatch:
            emit('No enumeration tools triggered — no recognised service ports')
            return

        # ── Filter by sweep depth tier ────────────────────────────────────────
        # A tool runs only if its tier <= the selected depth. Default STANDARD,
        # so Tier-3 tools (nuclei, feroxbuster, testssl) are strictly opt-in.
        try:
            tier = int(params.get('tier', TIER_STANDARD))
        except (TypeError, ValueError):
            tier = TIER_STANDARD
        tier = max(TIER_RECON, min(TIER_DEEP, tier))   # clamp to 1..3

        before = set(dispatch)
        dispatch = {tid: ctx for tid, ctx in dispatch.items()
                    if TOOL_TIERS.get(tid, TIER_STANDARD) <= tier}
        gated = before - set(dispatch)

        emit(f'Sweep depth: {TIER_LABELS.get(tier, tier)} (tier {tier})')
        if gated:
            emit(f'Gated by tier: {", ".join(sorted(TOOL_LABELS.get(t, t) for t in gated))}')
        if not dispatch:
            emit('All triggered tools are above the selected sweep depth — '
                 'raise the tier to enumerate this host')
            return

        emit(f'Tools: {", ".join(TOOL_LABELS.get(t, t) for t in dispatch)}')

        for tool_id, ctx in dispatch.items():
            with self._lock:
                self._tool_status[ip][tool_id] = 'running'

            emit(f'── {TOOL_LABELS.get(tool_id, tool_id)} ──')
            try:
                runner = getattr(self, f'_run_{tool_id}', None)
                if runner:
                    runner(ip, ctx, emit, finding, params)
                    status = 'done'
                else:
                    emit(f'[SKIP] No runner for {tool_id}')
                    status = 'skip'
            except Exception as exc:
                emit(f'[ERROR] {TOOL_LABELS.get(tool_id, tool_id)}: {exc}')
                status = 'error'

            with self._lock:
                self._tool_status[ip][tool_id] = status

    # ── Subprocess helper ─────────────────────────────────────────────────────

    def _run_cmd(self, cmd: list, emit, timeout: int = 120) -> tuple[int, list[str]]:
        """
        Run a command, stream stdout line by line via emit(), return (rc, lines).

        Uses a threading.Timer to kill the process after `timeout` seconds.
        This correctly handles the case where the process hangs — the for-loop
        over proc.stdout blocks until the process closes its stdout (i.e. exits
        or is killed), so proc.wait(timeout) would never fire if placed after it.
        """
        import re as _re
        _ansi = _re.compile(r'\x1b\[[0-9;]*[mGKHF]')

        lines: list[str] = []
        proc: subprocess.Popen | None = None
        _timed_out = threading.Event()

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                errors='replace',
            )

            def _kill():
                _timed_out.set()
                try:
                    proc.kill()
                except Exception:
                    pass

            timer = threading.Timer(timeout, _kill)
            timer.start()
            try:
                for raw in proc.stdout:
                    line = _ansi.sub('', raw.rstrip())
                    if line:
                        lines.append(line)
                        emit(line)
            finally:
                timer.cancel()

            proc.wait()
            if _timed_out.is_set():
                emit(f'[TIMEOUT] {cmd[0]} killed after {timeout}s')
                return -1, lines
            return proc.returncode, lines

        except FileNotFoundError:
            emit(f'[SKIP] {cmd[0]} not found')
            return -2, lines
        except Exception as exc:
            emit(f'[ERROR] {cmd[0]}: {exc}')
            return -3, lines
        finally:
            if proc and proc.poll() is None:
                try: proc.kill()
                except Exception: pass

    # ── Tool runners ──────────────────────────────────────────────────────────

    # ── WhatWeb ───────────────────────────────────────────────────────────────
    def _run_whatweb(self, ip, ctx, emit, finding, params):
        if not _which('whatweb'):
            emit('[SKIP] whatweb: sudo apt-get install whatweb')
            return
        port   = ctx['port']
        scheme = 'https' if port in (443, 8443) else 'http'
        url    = f'{scheme}://{ip}:{port}'
        tmp    = f'/tmp/h3x_whatweb_{ip}_{port}.json'
        emit(f'WhatWeb → {url}')
        self._run_cmd(['whatweb', '--log-json', tmp, '-a', '3', '--quiet', url], emit, 60)
        p = Path(tmp)
        try:
            if p.exists():
                try:
                    data = json.loads(p.read_text())
                    entries = data if isinstance(data, list) else [data]
                    for entry in entries:
                        for plugin, info in entry.get('plugins', {}).items():
                            ver = info.get('version', [])
                            finding({
                                'tool': 'whatweb', 'type': 'web_tech', 'severity': 'INFO',
                                'port': port,
                                'title': f'{plugin}{" " + ver[0] if ver else ""}',
                                'detail': f'Technology detected on {url}',
                            })
                except Exception:
                    pass
        finally:
            Path(tmp).unlink(missing_ok=True)

    # ── Nikto ─────────────────────────────────────────────────────────────────
    def _run_nikto(self, ip, ctx, emit, finding, params):
        if not _which('nikto'):
            emit('[SKIP] nikto: sudo apt-get install nikto')
            return
        port   = ctx['port']
        scheme = 'https' if port in (443, 8443) else 'http'
        emit(f'Nikto → {scheme}://{ip}:{port}')
        cmd = ['nikto', '-h', ip, '-p', str(port),
               '-Tuning', '1234567890abc', '-maxtime', '90s', '-nointeractive']
        if scheme == 'https':
            cmd.append('-ssl')
        _, lines = self._run_cmd(cmd, emit, 120)
        for line in lines:
            if line.startswith('+ ') and any(kw in line for kw in
                    ['OSVDB', 'CVE', 'allows', 'vulner', 'disclose', 'expose',
                     'default', 'install', 'admin', 'backup', 'config']):
                cve_m = re.search(r'CVE-[\d-]+', line)
                cve   = cve_m.group() if cve_m else None
                finding({
                    'tool': 'nikto', 'type': 'web_vuln',
                    'severity': 'HIGH' if cve else 'MEDIUM',
                    'port': port, 'cve': cve,
                    'title': line.strip().lstrip('+ '),
                    'detail': line.strip(),
                })

    # ── GoBuster ──────────────────────────────────────────────────────────────
    def _run_gobuster(self, ip, ctx, emit, finding, params):
        self._gobuster_impl(ip, ctx, emit, finding, ssl=False)

    def _run_gobuster_ssl(self, ip, ctx, emit, finding, params):
        self._gobuster_impl(ip, ctx, emit, finding, ssl=True)

    def _gobuster_impl(self, ip, ctx, emit, finding, ssl=False):
        if not _which('gobuster'):
            emit('[SKIP] gobuster: sudo apt-get install gobuster')
            return
        port      = ctx['port']
        wordlist  = '/usr/share/wordlists/dirb/common.txt'
        if not Path(wordlist).exists():
            emit('[SKIP] dirb wordlist missing: sudo apt-get install dirb')
            return
        scheme = 'https' if ssl else 'http'
        url    = f'{scheme}://{ip}:{port}'
        emit(f'GoBuster → {url}')
        cmd = ['gobuster', 'dir', '-u', url, '-w', wordlist,
               '-q', '-t', '20', '--timeout', '5s']
        if ssl:
            cmd.append('-k')
        _, lines = self._run_cmd(cmd, emit, 120)
        for line in lines:
            sc_m = re.search(r'\(Status: (\d+)\)', line)
            sc   = int(sc_m.group(1)) if sc_m else 0
            if sc in (200, 204, 301, 302, 401, 403):
                finding({
                    'tool': 'gobuster', 'type': 'web_dir',
                    'severity': 'HIGH' if sc in (200, 301, 302) else 'MEDIUM',
                    'port': port,
                    'title': line.strip(),
                    'detail': f'HTTP {sc} — {line.strip()}',
                })

    # ── SSLyze ────────────────────────────────────────────────────────────────
    def _run_sslyze(self, ip, ctx, emit, finding, params):
        if not _which('sslyze'):
            emit('[SKIP] sslyze: sudo apt-get install sslyze')
            return
        port = ctx['port']
        tmp  = f'/tmp/h3x_sslyze_{ip}_{port}.json'
        emit(f'SSLyze → {ip}:{port}')
        self._run_cmd(['sslyze', f'{ip}:{port}', f'--json_out={tmp}'], emit, 90)
        p = Path(tmp)
        try:
            if p.exists():
                try:
                    data = json.loads(p.read_text())
                    for srv in data.get('server_scan_results', []):
                        r = srv.get('scan_result', {})
                        hb = r.get('heartbleed', {}).get('result', {})
                        if hb.get('is_vulnerable_to_heartbleed'):
                            finding({'tool':'sslyze','type':'ssl_vuln','severity':'CRITICAL',
                                     'port':port,'cve':'CVE-2014-0160',
                                     'title':'Heartbleed (CVE-2014-0160)',
                                     'detail':'Server is vulnerable to Heartbleed memory disclosure'})
                        if 'VULNERABLE' in str(r.get('robot',{}).get('result',{}).get('robot_result','')):
                            finding({'tool':'sslyze','type':'ssl_vuln','severity':'HIGH',
                                     'port':port,'title':'ROBOT Attack',
                                     'detail':'Bleichenbacher oracle detected — RSA decryption possible'})
                        if r.get('tls_1_0_cipher_suites',{}).get('result',{}).get('accepted_cipher_suites'):
                            finding({'tool':'sslyze','type':'ssl_vuln','severity':'MEDIUM',
                                     'port':port,'title':'TLS 1.0 Supported',
                                     'detail':'Legacy TLS 1.0 enabled — POODLE / BEAST risk'})
                        if r.get('tls_1_1_cipher_suites',{}).get('result',{}).get('accepted_cipher_suites'):
                            finding({'tool':'sslyze','type':'ssl_vuln','severity':'LOW',
                                     'port':port,'title':'TLS 1.1 Supported',
                                     'detail':'Legacy TLS 1.1 enabled — consider disabling'})
                except Exception:
                    pass
        finally:
            Path(tmp).unlink(missing_ok=True)

    # ── enum4linux-ng ─────────────────────────────────────────────────────────
    def _run_enum4linux(self, ip, ctx, emit, finding, params):
        tool = _which('enum4linux-ng') or _which('enum4linux')
        if not tool:
            emit('[SKIP] enum4linux-ng: sudo apt-get install enum4linux-ng')
            return
        emit(f'enum4linux-ng → {ip}')
        tmp = f'/tmp/h3x_e4l_{ip}'
        if 'ng' in tool:
            self._run_cmd([tool, '-A', ip, '-oJ', tmp], emit, 180)
            jp = Path(tmp + '.json')
            try:
                if jp.exists():
                    try:
                        data = json.loads(jp.read_text())
                        for uid, info in data.get('users', {}).items():
                            uname = info.get('username', str(uid))
                            finding({'tool':'enum4linux','type':'user','severity':'HIGH',
                                     'port':445,'title':f'User: {uname}',
                                     'detail':f'RID {uid} — {info.get("name","")}',
                                     'username': uname})
                        for share, info in data.get('shares', {}).items():
                            access = info.get('access', 'UNKNOWN')
                            sev = ('CRITICAL' if 'WRITE' in str(access)
                                   else 'HIGH' if 'READ' in str(access) else 'INFO')
                            finding({'tool':'enum4linux','type':'smb_share','severity':sev,
                                     'port':445,'title':f'Share: \\\\{ip}\\{share} [{access}]',
                                     'detail':str(info)})
                        dom = data.get('domain', {})
                        if dom:
                            finding({'tool':'enum4linux','type':'domain_info','severity':'INFO',
                                     'port':445,'title':f'Domain: {dom.get("domain","")}',
                                     'detail':str(dom)})
                    except Exception:
                        pass
            finally:
                Path(tmp + '.json').unlink(missing_ok=True)
        else:
            self._run_cmd([tool, '-a', ip], emit, 180)

    # ── smbmap ────────────────────────────────────────────────────────────────
    def _run_smbmap(self, ip, ctx, emit, finding, params):
        if not _which('smbmap'):
            emit('[SKIP] smbmap: sudo apt-get install smbmap')
            return
        emit(f'smbmap → {ip}')
        _, lines = self._run_cmd(['smbmap', '-H', ip], emit, 60)
        for line in lines:
            if any(kw in line for kw in ['READ', 'WRITE', 'NO ACCESS']):
                sev = ('CRITICAL' if 'WRITE' in line
                       else 'HIGH' if 'READ' in line else 'INFO')
                finding({'tool':'smbmap','type':'smb_share','severity':sev,
                         'port':445,'title':line.strip(),'detail':line.strip()})

    # ── NetExec ───────────────────────────────────────────────────────────────
    def _run_netexec(self, ip, ctx, emit, finding, params):
        tool = _which('netexec') or _which('nxc') or _which('crackmapexec')
        if not tool:
            emit('[SKIP] netexec: sudo apt-get install netexec')
            return
        emit(f'NetExec SMB → {ip}')
        _, lines = self._run_cmd([tool, 'smb', ip], emit, 60)
        for line in lines:
            if 'SMBv1' in line and 'True' in line:
                finding({'tool':'netexec','type':'protocol_vuln','severity':'CRITICAL',
                         'port':445,'title':'SMBv1 Enabled — EternalBlue may be applicable',
                         'detail':line.strip(),
                         'msf_module':'auxiliary/scanner/smb/smb_ms17_010'})
            if 'signing' in line.lower() and 'False' in line:
                finding({'tool':'netexec','type':'protocol_vuln','severity':'HIGH',
                         'port':445,'title':'SMB Signing Disabled — relay attacks possible',
                         'detail':line.strip()})

    # ── SNMP ──────────────────────────────────────────────────────────────────
    def _run_snmp_check(self, ip, ctx, emit, finding, params):
        if not _which('onesixtyone'):
            emit('[SKIP] onesixtyone: sudo apt-get install onesixtyone')
            return
        emit(f'SNMP community strings → {ip}')
        _, lines = self._run_cmd(['onesixtyone', ip], emit, 30)
        communities = []
        for line in lines:
            m = re.search(r'\[(.+?)\]', line)
            if m:
                community = m.group(1)
                communities.append(community)
                finding({'tool':'snmp','type':'snmp_community','severity':'HIGH',
                         'port':161,'title':f'SNMP Community String: {community}',
                         'detail':line.strip()})
        if communities and _which('snmpwalk'):
            emit(f'snmpwalk -v2c -c {communities[0]} {ip} system')
            self._run_cmd(
                ['snmpwalk', '-v2c', '-c', communities[0], ip, '-t', '5', 'system'],
                emit, 60
            )

    # ── SMTP user enumeration ─────────────────────────────────────────────────
    def _run_smtp_enum(self, ip, ctx, emit, finding, params):
        port = ctx.get('port', 25)
        emit(f'SMTP user enum → {ip}:{port}')
        tool = _which('smtp-user-enum')
        if not tool:
            emit('[SKIP] smtp-user-enum not found — try: sudo apt-get install smtp-user-enum')
            return
        wordlist = '/usr/share/wordlists/metasploit/unix_users.txt'
        if not Path(wordlist).exists():
            wordlist = '/usr/share/wordlists/dirb/others/names.txt'
        if not Path(wordlist).exists():
            emit('[SKIP] No suitable username wordlist found')
            return
        _, lines = self._run_cmd(
            [tool, '-M', 'VRFY', '-U', wordlist, '-t', ip, '-p', str(port)],
            emit, 90
        )
        for line in lines:
            if 'exists' in line.lower():
                finding({'tool':'smtp_enum','type':'user','severity':'MEDIUM',
                         'port':port,'title':line.strip(),'detail':line.strip()})

    # ── LDAP ─────────────────────────────────────────────────────────────────
    def _run_ldap_enum(self, ip, ctx, emit, finding, params):
        if not _which('ldapsearch'):
            emit('[SKIP] ldapsearch: sudo apt-get install ldap-utils')
            return
        port = ctx.get('port', 389)
        emit(f'LDAP anonymous bind → {ip}:{port}')
        _, lines = self._run_cmd(
            ['ldapsearch', '-x', '-H', f'ldap://{ip}:{port}',
             '-b', '', '-s', 'base', 'namingContexts'],
            emit, 30
        )
        for line in lines:
            if any(kw in line for kw in ['namingContexts', 'defaultNamingContext', 'dc=']):
                finding({'tool':'ldap_enum','type':'ldap_info','severity':'HIGH',
                         'port':port,'title':f'LDAP Anon Bind: {line.strip()}',
                         'detail':'Anonymous LDAP bind successful — domain naming context exposed'})

    # ── dnsrecon ──────────────────────────────────────────────────────────────
    def _run_dnsrecon(self, ip, ctx, emit, finding, params):
        if not _which('dnsrecon'):
            emit('[SKIP] dnsrecon: sudo apt-get install dnsrecon')
            return
        emit(f'dnsrecon → {ip}')
        _, lines = self._run_cmd(
            ['dnsrecon', '-d', ip, '-t', 'std,axfr', '--lifetime', '5'],
            emit, 120
        )
        for line in lines:
            if 'Zone Transfer' in line and 'success' in line.lower():
                finding({'tool':'dnsrecon','type':'dns_axfr','severity':'CRITICAL',
                         'port':53,'title':'DNS Zone Transfer Allowed',
                         'detail':line.strip()})
            elif re.search(r'\b(A|MX|NS|SOA|TXT)\b', line) and ip not in line:
                finding({'tool':'dnsrecon','type':'dns_record','severity':'INFO',
                         'port':53,'title':line.strip(),'detail':line.strip()})

    # ── FTP anonymous login ───────────────────────────────────────────────────
    def _run_ftp_anon(self, ip, ctx, emit, finding, params):
        port = ctx.get('port', 21)
        emit(f'FTP anonymous login → {ip}:{port}')
        try:
            ftp = ftplib.FTP(timeout=10)
            ftp.connect(ip, port)
            ftp.login('anonymous', 'h3xdash@pentest.local')
            try:
                files = ftp.nlst()
            except Exception:
                files = []
            ftp.quit()
            finding({'tool':'ftp_anon','type':'anon_access','severity':'HIGH',
                     'port':port,
                     'title':f'FTP Anonymous Login Allowed — {len(files)} item(s) in root',
                     'detail':f'Files: {", ".join(files[:10])}'})
            emit(f'[+] Anonymous FTP login SUCCESS — {len(files)} item(s) listed')
        except ftplib.error_perm:
            emit('[-] Anonymous FTP login denied')
        except Exception as exc:
            emit(f'[-] FTP probe failed: {exc}')

    # ── ssh-audit ─────────────────────────────────────────────────────────────
    def _run_ssh_audit(self, ip, ctx, emit, finding, params):
        if not _which('ssh-audit'):
            emit('[SKIP] ssh-audit: sudo apt-get install ssh-audit')
            return
        port = ctx.get('port', 22)
        emit(f'ssh-audit → {ip}:{port}')
        _, lines = self._run_cmd(['ssh-audit', '-p', str(port), ip], emit, 60)
        for line in lines:
            if '-- [fail]' in line:
                finding({'tool':'ssh_audit','type':'ssh_config','severity':'HIGH',
                         'port':port,'title':line.strip(),'detail':line.strip()})
            elif '-- [warn]' in line:
                finding({'tool':'ssh_audit','type':'ssh_config','severity':'MEDIUM',
                         'port':port,'title':line.strip(),'detail':line.strip()})

    # ── RDP security check ────────────────────────────────────────────────────
    def _run_rdp_check(self, ip, ctx, emit, finding, params):
        port = ctx.get('port', 3389)
        emit(f'RDP NSE → {ip}:{port}')
        _, lines = self._run_cmd(
            ['nmap', '-p', str(port), '--script', 'rdp-enum-encryption',
             ip, '-Pn', '--open'],
            emit, 60
        )
        for line in lines:
            if 'Classic RDP' in line or 'RDP Security Layer' in line:
                finding({'tool':'rdp_check','type':'rdp_config','severity':'HIGH',
                         'port':port,
                         'title':'RDP: Classic/Legacy Security Layer Detected',
                         'detail':line.strip()})
            elif 'NLA' in line or 'CredSSP' in line:
                finding({'tool':'rdp_check','type':'rdp_config','severity':'INFO',
                         'port':port,'title':f'RDP: {line.strip()}','detail':line.strip()})

    # ── VNC probe ─────────────────────────────────────────────────────────────
    def _run_vnc_check(self, ip, ctx, emit, finding, params):
        port = ctx.get('port', 5900)
        emit(f'VNC NSE → {ip}:{port}')
        _, lines = self._run_cmd(
            ['nmap', '-p', str(port), '--script', 'vnc-info,vnc-auth-bypass',
             ip, '-Pn'],
            emit, 60
        )
        for line in lines:
            if any(kw in line for kw in ['Authentication disabled', 'None', 'No auth']):
                finding({'tool':'vnc_check','type':'vuln','severity':'CRITICAL',
                         'port':port,'title':'VNC: No Authentication Required',
                         'detail':line.strip(),
                         'msf_module':'auxiliary/scanner/vnc/vnc_none_auth'})

    # ── Redis probe ───────────────────────────────────────────────────────────
    def _run_redis_check(self, ip, ctx, emit, finding, params):
        port = ctx.get('port', 6379)
        emit(f'Redis probe → {ip}:{port}')
        try:
            s = socket.create_connection((ip, port), timeout=5)
            s.send(b'PING\r\n')
            resp = s.recv(64).decode('utf-8', errors='replace')
            s.close()
            if '+PONG' in resp:
                finding({'tool':'redis_check','type':'vuln','severity':'CRITICAL',
                         'port':port,
                         'title':'Redis: Unauthenticated Access (PING → PONG)',
                         'detail':'Redis answered PING without auth — RCE via replication possible',
                         'msf_module':'exploit/linux/redis/redis_replication_cmd_exec'})
                emit('[+] Redis UNAUTHENTICATED — PONG received')
            else:
                emit(f'[-] Redis response: {resp[:40]}')
        except Exception as exc:
            emit(f'[-] Redis probe: {exc}')

    # ── Elasticsearch probe ───────────────────────────────────────────────────
    def _run_elastic_check(self, ip, ctx, emit, finding, params):
        port = ctx.get('port', 9200)
        emit(f'Elasticsearch probe → {ip}:{port}')
        try:
            resp = urllib.request.urlopen(f'http://{ip}:{port}/', timeout=5)
            data = json.loads(resp.read())
            ver  = data.get('version', {}).get('number', 'unknown')
            finding({'tool':'elastic_check','type':'vuln','severity':'CRITICAL',
                     'port':port,
                     'title':f'Elasticsearch Open (unauthenticated) — v{ver}',
                     'detail':'No authentication required — cluster data accessible'})
            emit(f'[+] Elasticsearch OPEN — version {ver}')
        except Exception as exc:
            emit(f'[-] Elasticsearch probe: {exc}')

    # ── MongoDB probe ─────────────────────────────────────────────────────────
    def _run_mongo_check(self, ip, ctx, emit, finding, params):
        port = ctx.get('port', 27017)
        emit(f'MongoDB probe → {ip}:{port}')
        try:
            s = socket.create_connection((ip, port), timeout=5)
            s.close()
            finding({'tool':'mongo_check','type':'info','severity':'HIGH',
                     'port':port,'title':'MongoDB: Port Reachable — Verify Auth',
                     'detail':'Port 27017 open — confirm whether auth is required'})
            emit('[*] MongoDB port open — manual auth check recommended')
        except Exception as exc:
            emit(f'[-] MongoDB probe: {exc}')

    # ── searchsploit ──────────────────────────────────────────────────────────
    def _run_searchsploit(self, ip, ctx, emit, finding, params):
        if not _which('searchsploit'):
            emit('[SKIP] searchsploit not found (part of exploitdb)')
            return
        service = ctx.get('service', '').strip()
        version = ctx.get('version', '').strip()
        if not service:
            return
        query = f'{service} {version}'.strip()
        emit(f'searchsploit → "{query}"')
        _, lines = self._run_cmd(
            ['searchsploit', '--disable-colour', '-w', query],
            emit, 30
        )
        for line in lines:
            if '|' in line and '------' not in line and 'Exploit Title' not in line:
                parts = [p.strip() for p in line.split('|')]
                if len(parts) >= 2 and parts[0]:
                    title = parts[0]
                    url   = parts[-1]
                    sev   = ('CRITICAL' if 'Metasploit' in title or 'Remote' in title
                             else 'HIGH')
                    finding({'tool':'searchsploit','type':'exploit_ref',
                             'severity':sev,'port':ctx.get('port'),
                             'title':title,'detail':url,
                             'service':service,'version':version})

    # ══════════════════════════════════════════════════════════════════════════
    #  TIER-1 / TIER-3 ROBUSTNESS RUNNERS
    # ══════════════════════════════════════════════════════════════════════════

    # ── httpx — fast HTTP triage (Tier 1) ─────────────────────────────────────
    def _run_httpx(self, ip, ctx, emit, finding, params):
        """
        ProjectDiscovery httpx — fast fingerprint of an HTTP service:
        title, status code, web server, detected technologies. Runs first so
        the operator can triage many web hosts before the heavy web tools fire.
        On Kali the binary is 'httpx-toolkit' (renamed to avoid the python httpx).
        """
        tool = _which('httpx-toolkit') or _which('httpx')
        if not tool:
            emit('[SKIP] httpx: sudo apt-get install httpx-toolkit')
            return
        port   = ctx['port']
        scheme = 'https' if port in (443, 8443) else 'http'
        url    = f'{scheme}://{ip}:{port}'
        emit(f'httpx → {url}')
        cmd = [tool, '-u', url,
               '-title', '-status-code', '-web-server', '-tech-detect',
               '-content-length', '-follow-redirects',
               '-no-color', '-silent', '-timeout', '10']
        rc, lines = self._run_cmd(cmd, emit, 45)
        got = False
        for line in lines:
            text = line.strip()
            # httpx -silent emits one result line per URL, always starting with
            # the scheme. Anything else (banners, [WRN]/[INF], stray stderr) is
            # not a result and must not become a finding.
            if not text.lower().startswith(('http://', 'https://')):
                continue
            got = True
            finding({
                'tool': 'httpx', 'type': 'web_fingerprint', 'severity': 'INFO',
                'port': port,
                'title': 'HTTP service fingerprint',
                'detail': text,
            })
        if not got:
            emit('httpx: no HTTP response on this port')

    # ── nbtscan — NetBIOS name enumeration (Tier 1) ───────────────────────────
    def _run_nbtscan(self, ip, ctx, emit, finding, params):
        """
        nbtscan — queries the NetBIOS name service (137/UDP) for the host's
        NetBIOS name, workgroup/domain, logged-in user and MAC address.
        Fast and unauthenticated — useful early signal on Windows hosts.
        """
        if not _which('nbtscan'):
            emit('[SKIP] nbtscan: sudo apt-get install nbtscan')
            return
        emit(f'nbtscan → {ip}')
        rc, lines = self._run_cmd(['nbtscan', '-v', '-s', ':', ip], emit, 30)
        got = False
        for line in lines:
            text = line.strip()
            # Verbose colon-separated format: IP:NAME:<00>:U:...
            if text.startswith(ip) and ':' in text:
                got = True
                parts = [p.strip() for p in text.split(':')]
                detail = ' '.join(p for p in parts[1:] if p)
                finding({
                    'tool': 'nbtscan', 'type': 'netbios', 'severity': 'INFO',
                    'port': 139,
                    'title': 'NetBIOS name record',
                    'detail': detail or text,
                })
        if not got:
            emit('nbtscan: no NetBIOS response (host may not run SMB/NetBIOS)')

    # ── feroxbuster — recursive content discovery (Tier 3) ────────────────────
    def _run_feroxbuster(self, ip, ctx, emit, finding, params):
        """
        feroxbuster — fast recursive directory/file brute-force. Tier 3:
        slow and noisy. Recursion depth capped at 2 and concurrent recursive
        scans capped so it stays bounded. Prefers a SecLists wordlist, falls
        back to the dirb common list.
        """
        tool = _which('feroxbuster')
        if not tool:
            emit('[SKIP] feroxbuster: sudo apt-get install feroxbuster')
            return
        wordlist = next((w for w in (
            '/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt',
            '/usr/share/seclists/Discovery/Web-Content/common.txt',
            '/usr/share/wordlists/dirb/common.txt',
        ) if Path(w).exists()), None)
        if not wordlist:
            emit('[SKIP] feroxbuster: no wordlist — sudo apt-get install seclists')
            return
        port   = ctx['port']
        scheme = 'https' if port in (443, 8443) else 'http'
        url    = f'{scheme}://{ip}:{port}'
        emit(f'feroxbuster → {url} (depth 2, wordlist: {Path(wordlist).name})')
        # NOTE: use -q (quiet) NOT --silent. --silent emits URL-only lines;
        # -q keeps the result rows (status/method/size columns) we parse below.
        # --scan-limit bounds concurrent recursive scans; -d bounds depth.
        cmd = [tool, '-u', url, '-w', wordlist,
               '-d', '2', '-t', '30', '-x', 'php,txt,html,bak',
               '-k', '-q', '--scan-limit', '4', '--no-state']
        rc, lines = self._run_cmd(cmd, emit, 240)
        _keep = {'200', '204', '301', '302', '307', '401', '403'}
        seen  = set()
        for line in lines:
            text = line.strip()
            # feroxbuster -q rows: "<status> GET <Nl> <Nw> <Nc> <url>"
            # Parse status and URL independently — column count varies.
            sm = re.match(r'^(\d{3})\b', text)
            um = re.search(r'(https?://\S+)', text)
            if not sm or not um:
                continue
            status    = sm.group(1)
            found_url = um.group(1).split()[0].rstrip('/')
            if status not in _keep or found_url in seen:
                continue
            seen.add(found_url)
            sev = 'MEDIUM' if status in ('401', '403') else 'LOW'
            finding({
                'tool': 'feroxbuster', 'type': 'content_discovery',
                'severity': sev, 'port': port,
                'title': f'[{status}] {found_url}',
                'detail': f'Discovered path — HTTP {status}',
            })

    # ── nuclei — template-based vulnerability scan (Tier 3) ───────────────────
    def _run_nuclei(self, ip, ctx, emit, finding, params):
        """
        nuclei — community-template vulnerability scanner. Tier 3.
        DoS and intrusive templates are explicitly excluded; rate-limited to
        50 req/s for purple-team friendliness. JSON-lines output is parsed
        directly into findings with nuclei's own severity classification.
        """
        if not _which('nuclei'):
            emit('[SKIP] nuclei: sudo apt-get install nuclei')
            return
        port   = ctx['port']
        scheme = 'https' if port in (443, 8443) else 'http'
        url    = f'{scheme}://{ip}:{port}'
        emit(f'nuclei → {url}  (excluding dos/intrusive, rate-limit 50)')
        cmd = ['nuclei', '-u', url,
               '-severity', 'low,medium,high,critical',
               '-exclude-tags', 'dos,intrusive',
               '-rate-limit', '50', '-timeout', '8', '-retries', '1',
               '-no-color', '-silent', '-jsonl']
        rc, lines = self._run_cmd(cmd, emit, 300)
        _sev_map = {'critical': 'CRITICAL', 'high': 'HIGH', 'medium': 'MEDIUM',
                    'low': 'LOW', 'info': 'INFO', 'unknown': 'INFO'}
        hits = 0
        for line in lines:
            text = line.strip()
            if not text.startswith('{'):
                continue
            try:
                data = json.loads(text)
            except Exception:
                continue
            info     = data.get('info', {})
            sev      = _sev_map.get((info.get('severity') or 'info').lower(), 'INFO')
            name     = info.get('name', data.get('template-id', 'nuclei finding'))
            matched  = data.get('matched-at', url)
            classif  = info.get('classification', {}) or {}
            # cve-id is normally a list, but tolerate a bare string or None.
            cve_raw  = classif.get('cve-id')
            if isinstance(cve_raw, str):
                cve = cve_raw.upper() or None
            elif isinstance(cve_raw, list) and cve_raw:
                cve = str(cve_raw[0]).upper()
            else:
                cve = None
            hits += 1
            finding({
                'tool': 'nuclei', 'type': 'template_vuln', 'severity': sev,
                'port': port, 'cve': cve,
                'title': name,
                'detail': f'{matched}  [template: {data.get("template-id","?")}]',
            })
        if hits == 0:
            emit('nuclei: no template matches (templates may need '
                 '`nuclei -update-templates`)')

    # ── testssl.sh — deep TLS / cipher audit (Tier 3) ─────────────────────────
    def _run_testssl(self, ip, ctx, emit, finding, params):
        """
        testssl.sh — thorough TLS audit: protocol support, cipher strength,
        and named vulnerabilities (Heartbleed, ROBOT, etc.). Tier 3 — slower
        than SSLyze. Uses --jsonfile so findings are parsed from testssl's own
        severity classification rather than scraped from plain text.
        """
        tool = _which('testssl') or _which('testssl.sh')
        if not tool:
            emit('[SKIP] testssl.sh: sudo apt-get install testssl.sh')
            return
        port = ctx['port']
        tmp  = f'/tmp/h3x_testssl_{ip}_{port}.json'
        # testssl refuses to overwrite an existing JSON file — clear any stale one.
        Path(tmp).unlink(missing_ok=True)
        emit(f'testssl.sh → {ip}:{port}  (--fast, JSON out)')
        cmd = [tool, '--quiet', '--color', '0', '--fast',
               '--severity', 'LOW', '--warnings', 'off',
               '--jsonfile', tmp, f'{ip}:{port}']
        self._run_cmd(cmd, emit, 300)
        _sev_map = {'CRITICAL': 'CRITICAL', 'HIGH': 'HIGH', 'MEDIUM': 'MEDIUM',
                    'LOW': 'LOW', 'WARN': 'LOW'}
        p = Path(tmp)
        try:
            if p.exists():
                try:
                    data    = json.loads(p.read_text() or '[]')
                    entries = data if isinstance(data, list) else [data]
                    for e in entries:
                        raw = str(e.get('severity', 'INFO')).upper()
                        sev = _sev_map.get(raw)
                        if not sev:          # OK / INFO / DEBUG — skip
                            continue
                        fid   = e.get('id', 'tls')
                        fnd   = str(e.get('finding', '')).strip()
                        # testssl records CVEs in a dedicated 'cve' field
                        # (space-separated if several); fall back to the
                        # finding text only if that field is absent.
                        cve_src = str(e.get('cve', '') or '')
                        cve_m   = (re.search(r'CVE-[\d-]+', cve_src)
                                   or re.search(r'CVE-[\d-]+', fnd))
                        finding({
                            'tool': 'testssl', 'type': 'tls_vuln', 'severity': sev,
                            'port': port,
                            'cve': cve_m.group() if cve_m else None,
                            'title': f'{fid}: {fnd[:100]}' if fnd else fid,
                            'detail': fnd or fid,
                        })
                except Exception as exc:
                    emit(f'testssl: could not parse JSON output ({exc})')
            else:
                emit('testssl: no JSON output produced')
        finally:
            Path(tmp).unlink(missing_ok=True)
