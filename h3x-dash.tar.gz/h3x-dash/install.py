#!/usr/bin/env python3
"""
H3x-Dash — Installer & Pre-flight Validator
Kali GNU/Linux 2026.1 (Rolling)

Validates every dependency across the full pipeline:
    SCAN  →  ENUMERATE  →  EXPLOIT  →  LOOT

Offers to install missing apt packages, then optionally launches H3x-Dash.

Usage:
    sudo python3 install.py

Authorized use only. See SECURITY.md.
"""

import os
import shutil
import socket
import subprocess
import sys
from pathlib import Path

# ── SPECTR palette ────────────────────────────────────────────────────────────
def _c(*codes):
    return f"\033[{';'.join(str(x) for x in codes)}m" if sys.stdout.isatty() else ""

RST  = _c(0);   BOLD = _c(1);   DIM = _c(2)
CYN  = _c(96);  GRN  = _c(92);  RED = _c(91)
YLW  = _c(93);  MGT  = _c(95);  WHT = _c(97)

ROOT     = Path(__file__).resolve().parent
PASS, WARN, FAIL = "pass", "warn", "fail"

ICON = {PASS: f"{GRN}✓{RST}", WARN: f"{YLW}⚠{RST}", FAIL: f"{RED}✗{RST}"}


# ── Result container ──────────────────────────────────────────────────────────
class Check:
    __slots__ = ("name", "status", "message", "fix", "apt_pkg", "critical",
                  "install_spec")

    def __init__(self, name, status, message, fix="", apt_pkg=None,
                  critical=True, install_spec=None):
        self.name         = name
        self.status       = status
        self.message      = message
        self.fix          = fix
        self.apt_pkg      = apt_pkg          # back-compat for old callsites
        self.critical     = critical
        # install_spec: dict with {method: 'apt'|'pipx'|'binary', ...}
        # Drives dispatch in install_missing(). Falls back to apt_pkg if absent.
        self.install_spec = install_spec


# ── Helpers ───────────────────────────────────────────────────────────────────
_KALI_PATHS = ['/usr/bin', '/usr/sbin', '/usr/local/bin', '/usr/local/sbin',
               '/bin', '/sbin', '/usr/games']


def which(tool):
    """Locate a binary — PATH first, then explicit Kali dirs (sudo-safe)."""
    found = shutil.which(tool)
    if found:
        return found
    for d in _KALI_PATHS:
        cand = os.path.join(d, tool)
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    return None


def port_open(host, port, timeout=2.0):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def banner():
    print(f"""{CYN}{BOLD}
  ██╗  ██╗██████╗ ██╗  ██╗      ██████╗  █████╗ ███████╗██╗  ██╗
  ██║  ██║╚════██╗╚██╗██╔╝      ██╔══██╗██╔══██╗██╔════╝██║  ██║
  ███████║ █████╔╝ ╚███╔╝ █████╗██║  ██║███████║███████╗███████║
  ██╔══██║ ╚═══██╗ ██╔██╗ ╚════╝██║  ██║██╔══██║╚════██║██╔══██║
  ██║  ██║██████╔╝██╔╝ ██╗      ██████╔╝██║  ██║███████║██║  ██║
  ╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝{RST}
  {MGT}// INSTALLER & PRE-FLIGHT VALIDATOR // KALI 2026.1 //{RST}
  {DIM}// AUTHORIZED USE ONLY //{RST}
""")


def section(title):
    print(f"\n{CYN}{BOLD}── {title} {'─' * (58 - len(title))}{RST}")


# ══════════════════════════════════════════════════════════════════════════════
#  SYSTEM CHECKS
# ══════════════════════════════════════════════════════════════════════════════

def check_os():
    """
    H3x-Dash targets Kali rolling and Parrot Security (both Debian-derived,
    same apt package names for our enum/scan/exploit tool set).
    """
    try:
        data = Path('/etc/os-release').read_text()
        id_line  = next((l for l in data.splitlines()
                         if l.startswith('ID=')), '')
        os_id    = id_line.split('=', 1)[1].strip().strip('"').lower()
        version  = ''
        codename = ''
        for line in data.splitlines():
            if line.startswith('VERSION='):
                version = line.split('=', 1)[1].strip().strip('"')
            elif line.startswith('VERSION_CODENAME='):
                codename = line.split('=', 1)[1].strip().strip('"')

        if os_id == 'kali':
            return Check('Operating system', PASS,
                         f'Kali GNU/Linux {version or "(rolling)"}')
        if os_id == 'parrot':
            label = version or codename or '(rolling)'
            return Check('Operating system', PASS,
                         f'Parrot OS {label}  (apt names match Kali)')

        # Other Debian-derived → warn but don't fail
        name = 'Unknown'
        for line in data.splitlines():
            if line.startswith('PRETTY_NAME='):
                name = line.split('=', 1)[1].strip().strip('"')
        return Check('Operating system', WARN,
                     f'{name} \u2014 H3x-Dash targets Kali / Parrot; '
                     'apt package names may differ', critical=False)
    except Exception:
        return Check('Operating system', WARN,
                     'Could not read /etc/os-release', critical=False)


def check_python():
    v = sys.version_info
    if v >= (3, 10):
        return Check('Python version', PASS,
                     f'Python {v.major}.{v.minor}.{v.micro}')
    return Check('Python version', FAIL,
                 f'Python {v.major}.{v.minor} — H3x-Dash requires 3.10+',
                 fix='sudo apt-get install python3', apt_pkg='python3')


def check_root():
    if hasattr(os, 'geteuid') and os.geteuid() == 0:
        return Check('Privileges', PASS, 'Running as root — SYN scans enabled')
    return Check('Privileges', FAIL,
                 'Not running as root — nmap SYN scans and msfrpcd will fail',
                 fix='Re-run with: sudo python3 install.py')


def check_disk():
    try:
        st = shutil.disk_usage(ROOT)
        free_mb = st.free // (1024 * 1024)
        if free_mb >= 500:
            return Check('Disk space', PASS, f'{free_mb:,} MB free')
        if free_mb >= 200:
            return Check('Disk space', WARN,
                         f'Only {free_mb} MB free — 500 MB recommended',
                         critical=False)
        return Check('Disk space', FAIL, f'Only {free_mb} MB free — need 200 MB min')
    except Exception as e:
        return Check('Disk space', WARN, f'Could not check: {e}', critical=False)


# ══════════════════════════════════════════════════════════════════════════════
#  SCAN CHAIN
# ══════════════════════════════════════════════════════════════════════════════

def check_nmap():
    path = which('nmap')
    if not path:
        return Check('nmap', FAIL, 'nmap not found',
                     fix='sudo apt-get install nmap', apt_pkg='nmap')
    try:
        out = subprocess.check_output([path, '--version'], text=True,
                                      stderr=subprocess.DEVNULL, timeout=5)
        ver = out.splitlines()[0]
        return Check('nmap', PASS, f'{ver} at {path}')
    except Exception:
        return Check('nmap', WARN, f'Found at {path} but version check failed',
                     critical=False)


def check_configurabulator():
    cfg = ROOT / 'Nmap-Configurabulator.py'
    if not cfg.is_file():
        return Check('Nmap Configurabulator', FAIL,
                     'Nmap-Configurabulator.py missing from project root',
                     fix='Download from github.com/Null-H3x/nmap-configurobulator')
    try:
        import ast
        ast.parse(cfg.read_text())
        lines = len(cfg.read_text().splitlines())
        return Check('Nmap Configurabulator', PASS,
                     f'Present and valid ({lines} lines)')
    except SyntaxError as e:
        return Check('Nmap Configurabulator', FAIL,
                     f'File present but has a syntax error: {e}')


# ══════════════════════════════════════════════════════════════════════════════
#  ENUMERATION CHAIN
# ══════════════════════════════════════════════════════════════════════════════

# Tool → install spec.
#   method='apt'    → standard apt-get install (still the default for most)
#   method='pipx'   → pipx install (Python tools no longer in apt repos)
#   method='binary' → wget+chmod+mv to /usr/local/bin (single-file Go binaries)
#
# Package names with apt are identical on Kali rolling and Parrot Security.
ENUM_TOOLS = {
    # ── Tier 2 — Standard depth ───────────────────────────────────────────────
    'nikto':            {'method': 'apt',  'pkg': 'nikto'},
    'whatweb':          {'method': 'apt',  'pkg': 'whatweb'},
    'gobuster':         {'method': 'apt',  'pkg': 'gobuster'},
    'sslyze':           {'method': 'pipx', 'pkg': 'sslyze'},          # left apt
    'enum4linux-ng':    {'method': 'apt',  'pkg': 'enum4linux-ng'},
    'smbmap':           {'method': 'apt',  'pkg': 'smbmap'},
    'netexec':          {'method': 'apt',  'pkg': 'netexec'},
    'onesixtyone':      {'method': 'apt',  'pkg': 'onesixtyone'},
    'snmpwalk':         {'method': 'apt',  'pkg': 'snmp'},
    'dnsrecon':         {'method': 'apt',  'pkg': 'dnsrecon'},
    'ldapsearch':       {'method': 'apt',  'pkg': 'ldap-utils'},
    'ssh-audit':        {'method': 'apt',  'pkg': 'ssh-audit'},
    'searchsploit':     {'method': 'apt',  'pkg': 'exploitdb'},
    # ── Tier 1 — Recon depth ──────────────────────────────────────────────────
    'httpx':            {'method': 'apt',  'pkg': 'httpx-toolkit'},
    'nbtscan':          {'method': 'apt',  'pkg': 'nbtscan'},
    # ── Tier 3 — Deep sweep ───────────────────────────────────────────────────
    'feroxbuster':      {'method': 'apt',  'pkg': 'feroxbuster'},
    'nuclei':           {'method': 'apt',  'pkg': 'nuclei'},
    'testssl':          {'method': 'apt',  'pkg': 'testssl.sh'},
    # ── Chain-paying-off additions ────────────────────────────────────────────
    'wpscan':           {'method': 'apt',  'pkg': 'wpscan'},
    'droopescan':       {'method': 'pipx', 'pkg': 'droopescan'},      # PyPI only
    'kerbrute':         {'method': 'binary',                          # GitHub release
                          'url_template': 'https://github.com/ropnop/kerbrute/releases/'
                                          'download/v1.0.3/kerbrute_linux_{arch}',
                          'dest': '/usr/local/bin/kerbrute'},
    'ldapdomaindump':   {'method': 'apt',  'pkg': 'ldapdomaindump'},
    'wafw00f':          {'method': 'apt',  'pkg': 'wafw00f'},
    'ffuf':             {'method': 'apt',  'pkg': 'ffuf'},
    'dnsenum':          {'method': 'apt',  'pkg': 'dnsenum'},
    'sslscan':          {'method': 'apt',  'pkg': 'sslscan'},
    'smbclient':        {'method': 'apt',  'pkg': 'smbclient'},
    'rpcclient':        {'method': 'apt',  'pkg': 'samba-common-bin'},
}

# Apt-available alternatives surfaced to the operator when an install fails or
# they skip it. We don't auto-install these — just point at them as a fallback.
ENUM_FALLBACKS = {
    'droopescan': 'wpscan, joomscan, nuclei (CMS templates) cover most of this',
    'sslyze':     'testssl.sh is in apt and is arguably more comprehensive',
    'kerbrute':   'netexec --asreproast / impacket-GetNPUsers cover the AS-REP path',
}

# Binary aliases — any of these satisfies the tool
ENUM_ALIASES = {
    'netexec':       ['netexec', 'nxc', 'crackmapexec'],
    'enum4linux-ng': ['enum4linux-ng', 'enum4linux'],
    'httpx':         ['httpx', 'httpx-toolkit'],
    'testssl':       ['testssl', 'testssl.sh'],
}


# ── Architecture detection for binary downloads ──────────────────────────────

def detect_arch() -> str:
    """Map platform.machine() to the architecture string used in release URLs."""
    import platform
    m = platform.machine().lower()
    if m in ('x86_64', 'amd64'):    return 'amd64'
    if m in ('aarch64', 'arm64'):   return 'arm64'
    if m in ('i386', 'i486', 'i586', 'i686'):  return '386'
    return 'amd64'    # safest default for modern boxes


def check_seclists():
    """SecLists wordlists — feroxbuster and deep content discovery need them."""
    paths = [
        '/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt',
        '/usr/share/seclists/Discovery/Web-Content/common.txt',
    ]
    if any(Path(p).is_file() for p in paths):
        return Check('SecLists wordlists', PASS,
                     'SecLists present — feroxbuster content discovery ready',
                     critical=False)
    if Path('/usr/share/wordlists/dirb/common.txt').is_file():
        return Check('SecLists wordlists', WARN,
                     'SecLists missing — feroxbuster will fall back to dirb '
                     'common.txt (smaller, less coverage)',
                     fix='sudo apt-get install seclists',
                     apt_pkg='seclists', critical=False)
    return Check('SecLists wordlists', WARN,
                 'No content-discovery wordlist found — feroxbuster Tier-3 '
                 'sweeps will be skipped',
                 fix='sudo apt-get install seclists',
                 apt_pkg='seclists', critical=False)


def check_enum_tools():
    checks = []
    for tool, spec in ENUM_TOOLS.items():
        candidates = ENUM_ALIASES.get(tool, [tool])
        found = next((which(c) for c in candidates if which(c)), None)
        method = spec.get('method', 'apt')
        pkg    = spec.get('pkg', tool)

        if found:
            checks.append(Check(tool, PASS, found,
                                 apt_pkg=pkg if method == 'apt' else None,
                                 critical=False, install_spec=spec))
            continue

        # Build a fix hint that matches the install method
        if method == 'pipx':
            fix = f'pipx install {pkg}'
        elif method == 'binary':
            fix = (f'wget {spec["url_template"].format(arch=detect_arch())} '
                   f'&& chmod +x kerbrute_linux_{detect_arch()} '
                   f'&& sudo mv kerbrute_linux_{detect_arch()} {spec["dest"]}')
        else:
            fix = f'sudo apt-get install {pkg}'

        fallback_note = ENUM_FALLBACKS.get(tool, '')
        msg = f'{tool} not found — that tool will be skipped'
        if fallback_note:
            msg += f' (alternatives: {fallback_note})'

        checks.append(Check(tool, WARN, msg, fix=fix,
                             apt_pkg=pkg if method == 'apt' else None,
                             critical=False, install_spec=spec))
    return checks


# ══════════════════════════════════════════════════════════════════════════════
#  EXPLOIT CHAIN
# ══════════════════════════════════════════════════════════════════════════════

def check_metasploit():
    msf_dir = Path('/usr/share/metasploit-framework')
    msfconsole = which('msfconsole')
    if msf_dir.is_dir() or msfconsole:
        loc = str(msf_dir) if msf_dir.is_dir() else msfconsole
        return Check('Metasploit Framework', PASS, f'Found — {loc}')
    return Check('Metasploit Framework', FAIL,
                 'Metasploit Framework not found',
                 fix='sudo apt-get install metasploit-framework',
                 apt_pkg='metasploit-framework')


def check_msfrpcd():
    path = which('msfrpcd')
    if path:
        running = port_open('127.0.0.1', 55553)
        extra = ' — already listening on :55553' if running else ''
        return Check('msfrpcd', PASS, f'Found at {path}{extra}')
    return Check('msfrpcd', FAIL,
                 'msfrpcd not found — exploit chain cannot connect',
                 fix='sudo apt-get install metasploit-framework',
                 apt_pkg='metasploit-framework')


def check_pymetasploit3():
    try:
        import pymetasploit3  # noqa: F401
        return Check('pymetasploit3', PASS, 'pymetasploit3 importable')
    except ImportError:
        return Check('pymetasploit3', FAIL,
                     'pymetasploit3 not installed — MSF RPC unavailable',
                     fix='sudo apt-get install python3-pymetasploit3',
                     apt_pkg='python3-pymetasploit3')


# ══════════════════════════════════════════════════════════════════════════════
#  WEB UI
# ══════════════════════════════════════════════════════════════════════════════

def check_flask():
    try:
        import flask  # noqa: F401
        try:
            import importlib.metadata as _im
            ver = _im.version('flask')
        except Exception:
            ver = 'installed'
        return Check('Flask', PASS, f'Flask {ver}')
    except ImportError:
        return Check('Flask', FAIL, 'Flask not installed',
                     fix='sudo apt-get install python3-flask',
                     apt_pkg='python3-flask')


def check_project_files():
    checks = []
    required = {
        'h3x-dash.py':       'Main application',
        'config.py':         'Configuration',
        'modules':           'Backend engines (dir)',
        'templates':         'HTML templates (dir)',
        'static':            'Client JS/CSS (dir)',
    }
    for name, desc in required.items():
        p = ROOT / name
        ok = p.exists()
        checks.append(Check(name, PASS if ok else FAIL,
                            desc if ok else f'{desc} — MISSING from project'))
    return checks


def check_output_dirs():
    ok = []
    for d in ('scans', 'reports', 'loot'):
        p = ROOT / d
        try:
            p.mkdir(exist_ok=True)
            test = p / '.h3x_write_test'
            test.write_text('ok')
            test.unlink()
            ok.append(d)
        except Exception as e:
            return Check('Output directories', FAIL,
                         f'{d}/ not writable: {e}')
    return Check('Output directories', PASS,
                 f'{len(ok)} directories writable: {", ".join(ok)}/')


# ══════════════════════════════════════════════════════════════════════════════
#  RUNNER
# ══════════════════════════════════════════════════════════════════════════════

def run_section(title, checks):
    """Print a section's checks; return the list."""
    section(title)
    for c in checks:
        line = f"  {ICON[c.status]} {WHT}{c.name:<22}{RST} {c.message}"
        print(line)
        if c.status == FAIL and c.fix:
            print(f"      {DIM}fix: {c.fix}{RST}")
        elif c.status == WARN and c.fix:
            print(f"      {DIM}fix: {c.fix}{RST}")
    return checks


def _install_apt_batch(pkgs):
    """Single apt-get install for all apt packages — fastest."""
    if not pkgs:
        return True
    print(f"\n{CYN}── apt-get install ({len(pkgs)} packages) ──{RST}")
    cmd = ['apt-get', 'install', '-y'] + sorted(set(pkgs))
    print(f"{DIM}  sudo {' '.join(cmd)}{RST}")
    try:
        subprocess.run(['apt-get', 'update'], check=False, timeout=120)
        result = subprocess.run(cmd, check=False, timeout=600)
        if result.returncode == 0:
            print(f"{GRN}  ✓ apt packages installed{RST}")
            return True
        print(f"{RED}  ✗ apt-get exited with code {result.returncode}{RST}")
        return False
    except Exception as e:
        print(f"{RED}  ✗ apt install failed: {e}{RST}")
        return False


def _ensure_pipx():
    """Make sure pipx is available + PATH is configured."""
    if which('pipx'):
        return True
    print(f"\n{CYN}── installing pipx (prerequisite for Python tools) ──{RST}")
    try:
        subprocess.run(['apt-get', 'install', '-y', 'pipx'],
                        check=False, timeout=300)
        # ensurepath updates user shell config so ~/.local/bin is on PATH
        # for new shells. Current process keeps running until exec, so we
        # also stamp the path manually below to find pipx-installed binaries.
        subprocess.run(['pipx', 'ensurepath'], check=False, timeout=60)
        if which('pipx'):
            print(f"{GRN}  ✓ pipx installed — restart shell after install completes{RST}")
            return True
        print(f"{RED}  ✗ pipx not on PATH after install — manual intervention needed{RST}")
        return False
    except Exception as e:
        print(f"{RED}  ✗ pipx install failed: {e}{RST}")
        return False


def _install_pipx_pkgs(pkgs):
    """pipx-install each Python tool. pipx isolates each into its own venv."""
    if not pkgs:
        return True
    if not _ensure_pipx():
        print(f"{YLW}  ⚠ skipping pipx tools — install pipx first{RST}")
        return False
    print(f"\n{CYN}── pipx install ({len(pkgs)} Python tools) ──{RST}")
    # pipx runs as the invoking user, not root — sudo prefix would isolate the
    # install in root's home which the operator can't reach. Use SUDO_USER if
    # available (we were re-entered via sudo), else current user.
    real_user = os.environ.get('SUDO_USER') or os.environ.get('USER')
    all_ok = True
    for pkg in sorted(set(pkgs)):
        try:
            if real_user and real_user != 'root' and os.geteuid() == 0:
                # Drop privileges so pipx installs into the real user's home
                cmd = ['sudo', '-u', real_user, '-H', 'pipx', 'install', pkg]
            else:
                cmd = ['pipx', 'install', pkg]
            print(f"{DIM}  {' '.join(cmd)}{RST}")
            result = subprocess.run(cmd, check=False, timeout=300)
            if result.returncode == 0:
                print(f"{GRN}  ✓ {pkg}{RST}")
            else:
                print(f"{YLW}  ⚠ {pkg} install returned {result.returncode}{RST}")
                all_ok = False
        except Exception as e:
            print(f"{RED}  ✗ {pkg} install failed: {e}{RST}")
            all_ok = False
    return all_ok


def _install_binary(name, url, dest):
    """Download a single-file binary, chmod +x, move into /usr/local/bin."""
    import urllib.request
    print(f"\n{CYN}── binary install: {name} ──{RST}")
    print(f"{DIM}  url:  {url}{RST}")
    print(f"{DIM}  dest: {dest}{RST}")
    tmp = Path('/tmp') / Path(dest).name
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'H3x-Dash/installer'})
        with urllib.request.urlopen(req, timeout=60) as resp:
            tmp.write_bytes(resp.read())
        tmp.chmod(0o755)
        # mv requires root if dest is /usr/local/bin
        result = subprocess.run(['mv', str(tmp), dest],
                                  check=False, timeout=30)
        if result.returncode == 0:
            print(f"{GRN}  ✓ {name} installed at {dest}{RST}")
            return True
        print(f"{RED}  ✗ mv to {dest} failed (rc={result.returncode}) — "
              f"try: sudo mv {tmp} {dest}{RST}")
        return False
    except Exception as e:
        print(f"{RED}  ✗ {name} download failed: {e}{RST}")
        return False


def install_missing(checks):
    """
    Dispatch missing tools to the right installer by method.

    Groups by install method, then runs each group:
      - apt    : one batched apt-get install for speed
      - pipx   : per-tool pipx install (each gets its own venv)
      - binary : wget + chmod + mv per tool
    """
    apt_pkgs, pipx_pkgs, binary_specs = [], [], []

    for c in checks:
        if not isinstance(c, Check) or c.status == PASS:
            continue
        spec = c.install_spec or {}
        method = spec.get('method')
        if method == 'pipx':
            pipx_pkgs.append(spec.get('pkg', c.name))
        elif method == 'binary':
            arch = detect_arch()
            url  = spec.get('url_template', '').format(arch=arch)
            dest = spec.get('dest', f'/usr/local/bin/{c.name}')
            if url and dest:
                binary_specs.append((c.name, url, dest))
        else:
            # Default: apt. Use apt_pkg if Check carried one, else spec['pkg'],
            # else fall back to the tool name itself.
            pkg = c.apt_pkg or spec.get('pkg')
            if pkg:
                apt_pkgs.append(pkg)

    if not (apt_pkgs or pipx_pkgs or binary_specs):
        return False

    print(f"\n{YLW}{BOLD}Install plan:{RST}")
    if apt_pkgs:    print(f"  {len(apt_pkgs)} apt package(s): {', '.join(sorted(set(apt_pkgs)))}")
    if pipx_pkgs:   print(f"  {len(pipx_pkgs)} pipx package(s): {', '.join(sorted(set(pipx_pkgs)))}")
    if binary_specs:
        print(f"  {len(binary_specs)} binary download(s): "
              f"{', '.join(s[0] for s in binary_specs)}")

    try:
        ans = input(f"\n{CYN}Install these now? [y/N]{RST} ").strip().lower()
    except EOFError:
        ans = 'n'
    if ans != 'y':
        print(f"{DIM}Skipped — install manually before launching.{RST}")
        return False

    ok = True
    if apt_pkgs:    ok &= _install_apt_batch(apt_pkgs)
    if pipx_pkgs:   ok &= _install_pipx_pkgs(pipx_pkgs)
    for name, url, dest in binary_specs:
        ok &= _install_binary(name, url, dest)

    if ok:
        print(f"\n{GRN}{BOLD}All installs completed.{RST}")
    else:
        print(f"\n{YLW}Some installs had issues — re-run install.py to verify.{RST}")
    return ok


def launch_h3x_dash():
    """Exec h3x-dash.py, replacing this process."""
    target = ROOT / 'h3x-dash.py'
    if not target.is_file():
        print(f"{RED}Cannot launch — h3x-dash.py not found.{RST}")
        return
    print(f"\n{GRN}{BOLD}Launching H3x-Dash...{RST}")
    print(f"{DIM}  Dashboard will be at http://127.0.0.1:5000{RST}\n")
    os.chdir(ROOT)
    os.execvp(sys.executable, [sys.executable, str(target)])


def main():
    banner()

    all_checks = []

    all_checks += run_section('SYSTEM', [
        check_os(), check_python(), check_root(), check_disk(),
    ])
    all_checks += run_section('SCAN CHAIN', [
        check_nmap(), check_configurabulator(),
    ])
    all_checks += run_section('ENUMERATION CHAIN',
                              check_enum_tools() + [check_seclists()])
    all_checks += run_section('EXPLOIT CHAIN', [
        check_metasploit(), check_msfrpcd(), check_pymetasploit3(),
    ])
    all_checks += run_section('WEB UI', [
        check_flask(), *check_project_files(), check_output_dirs(),
    ])

    # ── Tally ────────────────────────────────────────────────────────────────
    n_pass = sum(1 for c in all_checks if c.status == PASS)
    n_warn = sum(1 for c in all_checks if c.status == WARN)
    n_fail = sum(1 for c in all_checks if c.status == FAIL)
    crit_fails = [c for c in all_checks if c.status == FAIL and c.critical]

    section('SUMMARY')
    print(f"  {GRN}{n_pass} passed{RST}   "
          f"{YLW}{n_warn} warnings{RST}   "
          f"{RED}{n_fail} failed{RST}")

    # ── Offer install for anything fixable ───────────────────────────────────
    # Old API took apt_pkg strings; new API takes Check objects so each can
    # be dispatched by its install_spec.method (apt / pipx / binary).
    fixable = [c for c in all_checks
                if c.status in (FAIL, WARN)
                and ((c.install_spec and c.install_spec.get('method'))
                     or c.apt_pkg)]
    if fixable:
        installed = install_missing(fixable)
        if installed:
            print(f"\n{CYN}Re-run 'sudo python3 install.py' to "
                  f"re-validate.{RST}")
            return

    # ── Verdict ──────────────────────────────────────────────────────────────
    print()
    if crit_fails:
        print(f"{RED}{BOLD}✗ NOT READY{RST} — "
              f"{len(crit_fails)} critical dependency check(s) failed:")
        for c in crit_fails:
            print(f"  {RED}•{RST} {c.name}: {c.message}")
        print(f"\n{DIM}Resolve the items above, then re-run this installer.{RST}")
        return

    if n_warn:
        print(f"{GRN}{BOLD}✓ READY{RST} — core pipeline validated.")
        print(f"{YLW}  {n_warn} optional tool(s) missing — those enumeration "
              f"modules will be skipped at runtime.{RST}")
    else:
        print(f"{GRN}{BOLD}✓ ALL SYSTEMS GO{RST} — "
              f"every dependency in the scan → enumerate → exploit "
              f"chain is present.")

    # ── Offer to launch ──────────────────────────────────────────────────────
    print()
    try:
        ans = input(f"{CYN}{BOLD}Run H3x-Dash now? [y/N]{RST} ").strip().lower()
    except EOFError:
        ans = 'n'
    if ans == 'y':
        launch_h3x_dash()
    else:
        print(f"\n{DIM}Launch it any time with:{RST} "
              f"{WHT}sudo python3 h3x-dash.py{RST}\n")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{DIM}Cancelled.{RST}")
        sys.exit(130)
