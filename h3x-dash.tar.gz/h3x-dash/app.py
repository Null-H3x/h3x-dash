#!/usr/bin/env python3
"""
H3x-Dash — Automated Penetration Framework
Flask application core: routes, SSE streaming, API endpoints.
"""

import json
import queue
import threading
import uuid
from flask import Flask, render_template, request, jsonify, Response, stream_with_context, send_file
from pathlib import Path

from config import H3xConfig
from modules.nmap_engine import NmapEngine, PORT_PROFILES, TIMING_DESC, SCRIPT_PROFILES, SCRIPT_DESC
from modules.msf_engine import MsfEngine
from modules.cve_chain import CveChain
from modules.loot import LootManager

# ── App init ──────────────────────────────────────────────────────────────────

app = Flask(__name__)
app.secret_key = H3xConfig.SECRET_KEY
H3xConfig.init_dirs()

# ── Global engine instances ───────────────────────────────────────────────────

scan_engine  = NmapEngine()
msf_engine   = MsfEngine()
cve_chain    = CveChain()
loot_manager = LootManager()

# ── MSF auto-connect on startup ───────────────────────────────────────────────
# Spawns a background thread that retries every 10s until msfrpcd answers.
# Override host/port/pass via environment variables (see config.py).

msf_engine.start_auto_connect(
    host     = H3xConfig.MSF_HOST,
    port     = H3xConfig.MSF_PORT,
    password = H3xConfig.MSF_PASS,
    ssl      = H3xConfig.MSF_SSL,
)

# ── SSE queue registry ────────────────────────────────────────────────────────

_sse_queues: dict[str, queue.Queue] = {}
_sse_lock = threading.Lock()

def _get_queue(client_id: str) -> queue.Queue:
    with _sse_lock:
        if client_id not in _sse_queues:
            _sse_queues[client_id] = queue.Queue(maxsize=500)
        return _sse_queues[client_id]

def _drop_queue(client_id: str):
    with _sse_lock:
        _sse_queues.pop(client_id, None)


# ─────────────────────────────────────────────────────────────────────────────
#  PAGE ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/')
def dashboard():
    stats = {
        'hosts':    scan_engine.get_host_count(),
        'vulns':    scan_engine.get_vuln_count(),
        'sessions': msf_engine.get_session_count(),
        'scans':    scan_engine.get_scan_count(),
    }
    recent   = scan_engine.get_recent_activity()
    msf_conn = msf_engine.is_connected()
    return render_template('dashboard.html', stats=stats, recent=recent, msf_conn=msf_conn)


@app.route('/scan')
def scan():
    return render_template('scan.html',
        port_profiles=PORT_PROFILES,
        timing_desc=TIMING_DESC,
        script_profiles=SCRIPT_PROFILES,
        script_desc=SCRIPT_DESC,
    )


@app.route('/exploit')
def exploit():
    hosts = scan_engine.get_hosts_with_ports()
    msf_conn = msf_engine.is_connected()
    return render_template('exploit.html', hosts=hosts, msf_conn=msf_conn)


@app.route('/loot')
def loot():
    reports  = loot_manager.list_reports()
    sessions = msf_engine.list_sessions()
    return render_template('loot.html', reports=reports, sessions=sessions)


# ─────────────────────────────────────────────────────────────────────────────
#  SCAN API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/scan/start', methods=['POST'])
def api_scan_start():
    data      = request.json or {}
    client_id = data.get('client_id') or str(uuid.uuid4())
    q         = _get_queue(client_id)

    def on_output(line: str):
        try:
            q.put_nowait({'type': 'output', 'data': line})
        except queue.Full:
            pass

    def on_complete(hosts, meta):
        try:
            q.put_nowait({'type': 'complete', 'host_count': len(hosts), 'meta': meta})
        except queue.Full:
            pass

    started = scan_engine.start_scan(data, on_output=on_output, on_complete=on_complete)
    if not started:
        return jsonify({'status': 'error', 'message': 'Scan already running'}), 409

    return jsonify({'status': 'started', 'client_id': client_id})


@app.route('/api/scan/stop', methods=['POST'])
def api_scan_stop():
    scan_engine.stop_scan()
    return jsonify({'status': 'stopped'})


@app.route('/api/scan/status')
def api_scan_status():
    return jsonify(scan_engine.get_status())


@app.route('/api/scan/results')
def api_scan_results():
    return jsonify(scan_engine.get_results())


@app.route('/api/scan/history')
def api_scan_history():
    return jsonify({
        'history': scan_engine.get_recent_activity(),
        'stats': {
            'hosts':    scan_engine.get_host_count(),
            'vulns':    scan_engine.get_vuln_count(),
            'sessions': msf_engine.get_session_count(),
            'scans':    scan_engine.get_scan_count(),
        }
    })


@app.route('/api/scan/stream')
def api_scan_stream():
    client_id = request.args.get('client_id', 'default')
    q         = _get_queue(client_id)

    def generate():
        try:
            while True:
                try:
                    event = q.get(timeout=25)
                    yield f"data: {json.dumps(event)}\n\n"
                    if event.get('type') in ('complete', 'error'):
                        break
                except queue.Empty:
                    yield f"data: {json.dumps({'type': 'heartbeat'})}\n\n"
        finally:
            _drop_queue(client_id)

    return Response(
        stream_with_context(generate()),
        mimetype='text/event-stream',
        headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'},
    )


# ─────────────────────────────────────────────────────────────────────────────
#  CVE CHAIN API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/cve/suggest', methods=['POST'])
def api_cve_suggest():
    data  = request.json or {}
    ip    = data.get('ip')
    hosts = scan_engine.get_hosts_with_ports()
    host  = next((h for h in hosts if h.get('ip') == ip), None)
    if not host:
        return jsonify({'suggestions': []})
    suggestions = cve_chain.suggest(host, host.get('ports', []))
    return jsonify({'suggestions': suggestions})


@app.route('/api/cve/all')
def api_cve_all():
    hosts = scan_engine.get_hosts_with_ports()
    results = {}
    for host in hosts:
        ip = host.get('ip')
        results[ip] = cve_chain.suggest(host, host.get('ports', []))
    return jsonify(results)


# ─────────────────────────────────────────────────────────────────────────────
#  METASPLOIT API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/msf/connect', methods=['POST'])
def api_msf_connect():
    data   = request.json or {}
    result = msf_engine.connect(
        host     = data.get('host',     H3xConfig.MSF_HOST),
        port     = int(data.get('port', H3xConfig.MSF_PORT)),
        password = data.get('password', H3xConfig.MSF_PASS),
        ssl      = data.get('ssl',      H3xConfig.MSF_SSL),
    )
    return jsonify(result)


@app.route('/api/msf/disconnect', methods=['POST'])
def api_msf_disconnect():
    msf_engine.disconnect()
    return jsonify({'status': 'disconnected'})


@app.route('/api/msf/status')
def api_msf_status():
    return jsonify({
        'connected':  msf_engine.is_connected(),
        'version':    msf_engine.get_version(),
        'sessions':   msf_engine.get_session_count(),
        'last_error': msf_engine.get_last_error(),
    })


@app.route('/api/msf/search', methods=['POST'])
def api_msf_search():
    data    = request.json or {}
    modules = msf_engine.search(data.get('query', ''))
    return jsonify({'modules': modules})


@app.route('/api/msf/run', methods=['POST'])
def api_msf_run():
    data   = request.json or {}
    result = msf_engine.run_exploit(
        module  = data.get('module'),
        options = data.get('options', {}),
        payload = data.get('payload'),
    )
    return jsonify(result)


@app.route('/api/msf/sessions')
def api_msf_sessions():
    return jsonify({'sessions': msf_engine.list_sessions()})


@app.route('/api/msf/session/cmd', methods=['POST'])
def api_msf_session_cmd():
    data   = request.json or {}
    result = msf_engine.session_command(
        session_id = str(data.get('session_id')),
        command    = data.get('command', ''),
    )
    return jsonify(result)


# ─────────────────────────────────────────────────────────────────────────────
#  LOOT API
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/loot/generate', methods=['POST'])
def api_loot_generate():
    data   = request.json or {}
    report = loot_manager.generate_report(
        scan_results = scan_engine.get_results(),
        sessions     = msf_engine.list_sessions(),
        fmt          = data.get('format', 'html'),
    )
    return jsonify(report)


@app.route('/api/loot/reports')
def api_loot_list():
    return jsonify({'reports': loot_manager.list_reports()})


@app.route('/api/loot/download/<filename>')
def api_loot_download(filename):
    report_dir = H3xConfig.REPORT_DIR
    safe_path  = (report_dir / filename).resolve()
    if not str(safe_path).startswith(str(report_dir.resolve())):
        return jsonify({'error': 'Invalid path'}), 400
    if not safe_path.exists():
        return jsonify({'error': 'File not found'}), 404
    return send_file(safe_path, as_attachment=True)


# ─────────────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print("""
  ██╗  ██╗██████╗ ██╗  ██╗      ██████╗  █████╗ ███████╗██╗  ██╗
  ██║  ██║╚════██╗╚██╗██╔╝      ██╔══██╗██╔══██╗██╔════╝██║  ██║
  ███████║ █████╔╝ ╚███╔╝ █████╗██║  ██║███████║███████╗███████║
  ██╔══██║ ╚═══██╗ ██╔██╗ ╚════╝██║  ██║██╔══██║╚════██║██╔══██║
  ██║  ██║██████╔╝██╔╝ ██╗      ██████╔╝██║  ██║███████║██║  ██║
  ╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
  // AUTOMATED PENETRATION FRAMEWORK // AUTHORIZED USE ONLY //
    """)
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
